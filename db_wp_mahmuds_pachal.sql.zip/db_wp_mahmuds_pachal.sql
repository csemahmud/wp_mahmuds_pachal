-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2016 at 08:17 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_wp_mahmuds_pachal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_activity`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `component` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `action` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `primary_link` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `date_recorded` datetime NOT NULL,
  `hide_sitewide` tinyint(1) DEFAULT '0',
  `mptt_left` int(11) NOT NULL DEFAULT '0',
  `mptt_right` int(11) NOT NULL DEFAULT '0',
  `is_spam` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_recorded` (`date_recorded`),
  KEY `user_id` (`user_id`),
  KEY `item_id` (`item_id`),
  KEY `secondary_item_id` (`secondary_item_id`),
  KEY `component` (`component`),
  KEY `type` (`type`),
  KEY `mptt_left` (`mptt_left`),
  KEY `mptt_right` (`mptt_right`),
  KEY `hide_sitewide` (`hide_sitewide`),
  KEY `is_spam` (`is_spam`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_bp_activity`
--

INSERT INTO `tbl_bp_activity` (`id`, `user_id`, `component`, `type`, `action`, `content`, `primary_link`, `item_id`, `secondary_item_id`, `date_recorded`, `hide_sitewide`, `mptt_left`, `mptt_right`, `is_spam`) VALUES
(1, 1, 'members', 'last_activity', '', '', '', 0, NULL, '2016-12-02 19:26:10', 0, 0, 0, 0),
(2, 2, 'members', 'last_activity', '', '', '', 0, NULL, '2016-12-02 19:43:46', 0, 0, 0, 0),
(3, 3, 'members', 'last_activity', '', '', '', 0, NULL, '2016-12-01 20:15:19', 0, 0, 0, 0),
(4, 3, 'blogs', 'new_blog_post', '<a href="http://localhost:81/wp_mahmuds_pachal/members/author/" title="author@gmail.com">author@gmail.com</a> wrote a new post, <a href="http://localhost:81/wp_mahmuds_pachal/?p=114">ডক্টর স্ট্রেঞ্জের ‘স্ট্রেঞ্জ’ সাফল্য!</a>', '\r\n\r\nপ্রথম সপ্তাহেই মারভেলের ছবি ডক্টর স্ট্রেঞ্জ যুক্তরাষ্ট্রেরবক্স অফিসে সাড়ে আট কোটি ডলারেরও বেশি আয় করেছে। নয় অঙ্কের যুগে এ সাফল্য কম মনে হতে পারে, কিন্তু এই নভেম্বরে মুক্তি পাওয়া ছবির জন্য এ সাফল্য বেশ ব [&hellip;] <img src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/a85e33a58106a8db419e7cb8145c4696-Untitled-17-300x264.jpg"/>', 'http://localhost:81/wp_mahmuds_pachal/?p=114', 1, 114, '2016-12-01 19:13:45', 0, 0, 0, 0),
(5, 2, 'blogs', 'new_blog_post', '<a href="http://localhost:81/wp_mahmuds_pachal/members/contributor/" title="Contributor">Contributor</a> wrote a new post, <a href="http://localhost:81/wp_mahmuds_pachal/?p=97">নাসার নতুন ‘চমক’ কি এলিয়েন?</a>', '\r\n\r\nমার্কিন মহাকাশ গবেষণা সংস্থা নাসার বিজ্ঞানীরা শিগগিরই নতুন একটি ‘চমক’ হাজির করতে যাচ্ছেন। এমন আভাস দিয়ে বলা হচ্ছে, এ চমক হতে পারে আমাদের এই সৌরজগতে এলিয়েন বা ভিনগ্রহের প্রাণীর গতিবিধি আবিষ্কারের তথ্য।\r\nবৃহ [&hellip;] <img src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/e44e8b9dd2fad481529192093124067f-nasa-europa-300x187.jpg"/>', 'http://localhost:81/wp_mahmuds_pachal/?p=97', 1, 97, '2016-12-01 19:18:59', 0, 1, 4, 0),
(6, 4, 'members', 'last_activity', '', '', '', 0, NULL, '2016-12-02 06:40:37', 0, 0, 0, 0),
(7, 4, 'blogs', 'new_blog_post', '<a href="http://localhost:81/wp_mahmuds_pachal/members/editor/" title="Editor">Editor</a> wrote a new post, <a href="http://localhost:81/wp_mahmuds_pachal/?p=117">আলিয়ার সঙ্গে জুটি বাঁধতে শাহরুখের শর্ত...</a>', '\r\n\r\nশুক্রবার মুক্তি পেয়েছে শাহরুখ খান ও আলিয়া ভাট অভিনীত ডিয়ার জিন্দেগি। মাত্র পাঁচ দিনেই অল্প বাজেটে তৈরি এ ছবি আয় করেছে প্রায় ৫০ কোটি রুপি। শাহরুখ আর আলিয়া যে বলিউডের বক্স অফিস মাত করতে যাচ্ছেন, তা আগেই [&hellip;] <img src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/753ae8936f3768920a6b6fa235603507-7-278x300.jpg"/>', 'http://localhost:81/wp_mahmuds_pachal/?p=117', 1, 117, '2016-12-01 19:27:57', 0, 0, 0, 0),
(8, 1, 'blogs', 'new_blog_post', '<a href="http://localhost:81/wp_mahmuds_pachal/members/cse-mahmud/" title="cse.mahmud">cse.mahmud</a> wrote a new post, <a href="http://localhost:81/wp_mahmuds_pachal/?p=120">সেরা ১০ এন্ড্রয়েড HD গেমস [ফ্রী ডাউনলোড]</a>', '২০১২-১৩ সালের এন্ড্রয়েড সেরা ১০টি এন্ড্রয়েড এইচডি গেমস নিয়ে সাজান হয়েছে এ পোস্ট টি। এ থেকে জানতে পারবেন কোন গেম কি ধরনের, কে বানিয়েছে, মূল্য কত, কিভাবে কোথা থেকে কিনবেন এবং সবচেয়ে গুরুত্বপূর্ণ ফ্রী ডাউনলোড লিঙ্ক [&hellip;] <img src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/modern-combat-4-zero-hour-screen1-300x146.jpg"/>', 'http://localhost:81/wp_mahmuds_pachal/?p=120', 1, 120, '2016-12-01 19:56:59', 0, 1, 4, 0),
(9, 5, 'members', 'new_member', '<a href="http://localhost:81/wp_mahmuds_pachal/members/subscriber1/" title="Subscriber">Subscriber</a> became a registered member', '', 'http://localhost:81/wp_mahmuds_pachal/members/cse-mahmud/', 0, 0, '2016-12-01 20:27:01', 0, 0, 0, 0),
(10, 5, 'members', 'last_activity', '', '', '', 0, NULL, '2016-12-02 20:13:36', 0, 0, 0, 0),
(11, 5, 'activity', 'activity_comment', '<a href="http://localhost:81/wp_mahmuds_pachal/members/subscriber1/" title="Subscriber">Subscriber</a> posted a new activity comment', 'চমৎকার   post   .   ধন্যবাদ   ।', 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/%e0%a6%b8%e0%a7%87%e0%a6%b0%e0%a6%be-%e0%a7%a7%e0%a7%a6-%e0%a6%8f%e0%a6%a8%e0%a7%8d%e0%a6%a1%e0%a7%8d%e0%a6%b0%e0%a6%af%e0%a6%bc%e0%a7%87%e0%a6%a1-hd-%e0%a6%97%e0%a7%87%e0%a6%ae%e0%a6%b8-%e0%a6%ab/#comment-2', 8, 8, '2016-12-01 20:35:09', 0, 2, 3, 0),
(12, 1, 'blogs', 'new_blog_post', '<a href="http://localhost:81/wp_mahmuds_pachal/members/cse-mahmud/" title="cse.mahmud">cse.mahmud</a> wrote a new post, <a href="http://localhost:81/wp_mahmuds_pachal/?p=130">ক্যাটরিনার ঔদার্য</a>', '\r\n\r\nমোহিত সুরির হাফ গার্লফ্রেন্ড ছবির প্রধান অভিনেত্রী শ্রদ্ধা কাপুর। কিন্তু এই চরিত্রের জন্য নির্মাতা প্রথমে প্রস্তাব দিয়েছিলেন ক্যাটরিনা কাইফকে। ছবির গল্প বেশ পছন্দও হয়েছিল ক্যাটের। কিন্তু তিনিই নাকি মোহিতকে [&hellip;] <img src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/af77dc73f31995b457dc2e457ba3fb33-4-193x300.jpg"/>', 'http://localhost:81/wp_mahmuds_pachal/?p=130', 1, 130, '2016-12-02 06:22:13', 0, 1, 4, 0),
(13, 5, 'activity', 'activity_comment', '<a href="http://localhost:81/wp_mahmuds_pachal/members/subscriber1/" title="Subscriber">Subscriber</a> posted a new activity comment', 'আমি ক্যাটরিনা কাইফকে ভালোবাসি ।', 'http://localhost:81/wp_mahmuds_pachal/2016/12/02/%e0%a6%95%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%9f%e0%a6%b0%e0%a6%bf%e0%a6%a8%e0%a6%be%e0%a6%b0-%e0%a6%94%e0%a6%a6%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%af/#comment-3', 12, 12, '2016-12-02 06:28:34', 0, 2, 3, 0),
(14, 5, 'activity', 'activity_comment', '<a href="http://localhost:81/wp_mahmuds_pachal/members/subscriber1/" title="Subscriber">Subscriber</a> posted a new activity comment', 'Really Interesting.', 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/%e0%a6%a8%e0%a6%be%e0%a6%b8%e0%a6%be%e0%a6%b0-%e0%a6%a8%e0%a6%a4%e0%a7%81%e0%a6%a8-%e0%a6%9a%e0%a6%ae%e0%a6%95-%e0%a6%95%e0%a6%bf-%e0%a6%8f%e0%a6%b2%e0%a6%bf%e0%a7%9f%e0%a7%87/#comment-4', 5, 5, '2016-12-02 18:26:05', 0, 2, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_activity_meta`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_activity_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `activity_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `activity_id` (`activity_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `tbl_bp_activity_meta`
--

INSERT INTO `tbl_bp_activity_meta` (`id`, `activity_id`, `meta_key`, `meta_value`) VALUES
(1, 4, 'post_title', 'ডক্টর স্ট্রেঞ্জের ‘স্ট্রেঞ্জ’ সাফল্য!'),
(2, 4, 'post_url', 'http://localhost:81/wp_mahmuds_pachal/?p=114'),
(3, 5, 'post_title', 'নাসার নতুন ‘চমক’ কি এলিয়েন?'),
(4, 5, 'post_url', 'http://localhost:81/wp_mahmuds_pachal/?p=97'),
(5, 7, 'post_title', 'আলিয়ার সঙ্গে জুটি বাঁধতে শাহরুখের শর্ত...'),
(6, 7, 'post_url', 'http://localhost:81/wp_mahmuds_pachal/?p=117'),
(7, 8, 'post_title', 'সেরা ১০ এন্ড্রয়েড HD গেমস [ফ্রী ডাউনলোড]'),
(8, 8, 'post_url', 'http://localhost:81/wp_mahmuds_pachal/?p=120'),
(9, 11, 'bp_blogs_post_comment_id', '2'),
(10, 11, 'post_title', 'সেরা ১০ এন্ড্রয়েড HD গেমস [ফ্রী ডাউনলোড]'),
(11, 11, 'post_url', 'http://localhost:81/wp_mahmuds_pachal/?p=120'),
(12, 12, 'post_title', 'ক্যাটরিনার ঔদার্য'),
(13, 12, 'post_url', 'http://localhost:81/wp_mahmuds_pachal/?p=130'),
(14, 13, 'bp_blogs_post_comment_id', '3'),
(15, 13, 'post_title', 'ক্যাটরিনার ঔদার্য'),
(16, 13, 'post_url', 'http://localhost:81/wp_mahmuds_pachal/?p=130'),
(17, 14, 'bp_blogs_post_comment_id', '4'),
(18, 14, 'post_title', 'নাসার নতুন ‘চমক’ কি এলিয়েন?'),
(19, 14, 'post_url', 'http://localhost:81/wp_mahmuds_pachal/?p=97');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_friends`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_friends` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `initiator_user_id` bigint(20) NOT NULL,
  `friend_user_id` bigint(20) NOT NULL,
  `is_confirmed` tinyint(1) DEFAULT '0',
  `is_limited` tinyint(1) DEFAULT '0',
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `initiator_user_id` (`initiator_user_id`),
  KEY `friend_user_id` (`friend_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_groups`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `creator_id` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'public',
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `enable_forum` tinyint(1) NOT NULL DEFAULT '1',
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `creator_id` (`creator_id`),
  KEY `status` (`status`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_groups_groupmeta`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_groups_groupmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_groups_members`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_groups_members` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `inviter_id` bigint(20) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `is_mod` tinyint(1) NOT NULL DEFAULT '0',
  `user_title` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_modified` datetime NOT NULL,
  `comments` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `invite_sent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `is_admin` (`is_admin`),
  KEY `is_mod` (`is_mod`),
  KEY `user_id` (`user_id`),
  KEY `inviter_id` (`inviter_id`),
  KEY `is_confirmed` (`is_confirmed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_messages_messages`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_messages_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `thread_id` bigint(20) NOT NULL,
  `sender_id` bigint(20) NOT NULL,
  `subject` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_sent` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `thread_id` (`thread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_messages_meta`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_messages_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `message_id` (`message_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_messages_notices`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_messages_notices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_sent` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_messages_recipients`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_messages_recipients` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `thread_id` bigint(20) NOT NULL,
  `unread_count` int(10) NOT NULL DEFAULT '0',
  `sender_only` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `thread_id` (`thread_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `sender_only` (`sender_only`),
  KEY `unread_count` (`unread_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_notifications`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `component_name` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `component_action` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_notified` datetime NOT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `secondary_item_id` (`secondary_item_id`),
  KEY `user_id` (`user_id`),
  KEY `is_new` (`is_new`),
  KEY `component_name` (`component_name`),
  KEY `component_action` (`component_action`),
  KEY `useritem` (`user_id`,`is_new`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_bp_notifications`
--

INSERT INTO `tbl_bp_notifications` (`id`, `user_id`, `item_id`, `secondary_item_id`, `component_name`, `component_action`, `date_notified`, `is_new`) VALUES
(1, 1, 11, 5, 'activity', 'update_reply', '2016-12-01 20:32:05', 1),
(2, 1, 13, 5, 'activity', 'update_reply', '2016-12-02 06:26:58', 1),
(3, 2, 14, 5, 'activity', 'update_reply', '2016-12-02 18:23:53', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_notifications_meta`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_notifications_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `notification_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `notification_id` (`notification_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_user_blogs`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_user_blogs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `blog_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_bp_user_blogs`
--

INSERT INTO `tbl_bp_user_blogs` (`id`, `user_id`, `blog_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_user_blogs_blogmeta`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_user_blogs_blogmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_bp_user_blogs_blogmeta`
--

INSERT INTO `tbl_bp_user_blogs_blogmeta` (`id`, `blog_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'url', 'http://localhost:81/wp_mahmuds_pachal'),
(2, 1, 'name', 'M@hmud&#039;s Pachal'),
(3, 1, 'description', 'Welcome to my Blog!'),
(4, 1, 'last_activity', '2016-12-02 18:43:10'),
(5, 1, 'close_comments_for_old_posts', ''),
(6, 1, 'close_comments_days_old', '14'),
(7, 1, 'thread_comments_depth', '5');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_xprofile_data`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_xprofile_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_bp_xprofile_data`
--

INSERT INTO `tbl_bp_xprofile_data` (`id`, `field_id`, `user_id`, `value`, `last_updated`) VALUES
(1, 1, 1, 'cse.mahmud', '2016-12-02 18:38:30'),
(2, 1, 2, 'Contributor', '2016-12-02 18:37:31'),
(3, 1, 3, 'Author', '2016-12-02 18:43:10'),
(4, 1, 4, 'Editor', '2016-12-02 18:39:37'),
(5, 1, 5, 'Subscriber', '2016-12-02 18:40:12'),
(6, 1, 6, 'Subscriber', '2016-12-01 20:25:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_xprofile_fields`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_xprofile_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL,
  `type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_default_option` tinyint(1) NOT NULL DEFAULT '0',
  `field_order` bigint(20) NOT NULL DEFAULT '0',
  `option_order` bigint(20) NOT NULL DEFAULT '0',
  `order_by` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `can_delete` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `parent_id` (`parent_id`),
  KEY `field_order` (`field_order`),
  KEY `can_delete` (`can_delete`),
  KEY `is_required` (`is_required`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_bp_xprofile_fields`
--

INSERT INTO `tbl_bp_xprofile_fields` (`id`, `group_id`, `parent_id`, `type`, `name`, `description`, `is_required`, `is_default_option`, `field_order`, `option_order`, `order_by`, `can_delete`) VALUES
(1, 1, 0, 'textbox', 'Name', '', 1, 0, 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_xprofile_groups`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_xprofile_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `group_order` bigint(20) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `can_delete` (`can_delete`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_bp_xprofile_groups`
--

INSERT INTO `tbl_bp_xprofile_groups` (`id`, `name`, `description`, `group_order`, `can_delete`) VALUES
(1, 'Base', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bp_xprofile_meta`
--

CREATE TABLE IF NOT EXISTS `tbl_bp_xprofile_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) NOT NULL,
  `object_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_commentmeta`
--

CREATE TABLE IF NOT EXISTS `tbl_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tbl_commentmeta`
--

INSERT INTO `tbl_commentmeta` (`meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 2, 'akismet_error', '1480624325'),
(2, 2, 'akismet_history', 'a:4:{s:4:"time";d:1480624325.8138859272003173828125;s:5:"event";s:11:"check-error";s:4:"user";s:11:"subscriber1";s:4:"meta";a:1:{s:8:"response";b:0;}}'),
(3, 2, 'akismet_as_submitted', 'a:13:{s:14:"comment_author";s:10:"Subscriber";s:20:"comment_author_email";s:21:"subscriber1@gmail.com";s:18:"comment_author_url";s:0:"";s:15:"comment_content";s:59:"চমৎকার   post   .   ধন্যবাদ   ।";s:12:"comment_type";s:0:"";s:7:"user_ID";i:5;s:7:"user_id";i:5;s:7:"user_ip";s:3:"::1";s:10:"user_agent";s:108:"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.10 Safari/537.36";s:4:"blog";s:37:"http://localhost:81/wp_mahmuds_pachal";s:9:"blog_lang";s:5:"en_US";s:12:"blog_charset";s:5:"UTF-8";s:9:"permalink";s:246:"http://localhost:81/wp_mahmuds_pachal/2016/12/01/%e0%a6%b8%e0%a7%87%e0%a6%b0%e0%a6%be-%e0%a7%a7%e0%a7%a6-%e0%a6%8f%e0%a6%a8%e0%a7%8d%e0%a6%a1%e0%a7%8d%e0%a6%b0%e0%a6%af%e0%a6%bc%e0%a7%87%e0%a6%a1-hd-%e0%a6%97%e0%a7%87%e0%a6%ae%e0%a6%b8-%e0%a6%ab/";}'),
(5, 2, 'bp_activity_comment_id', '11'),
(6, 2, 'akismet_history', 'a:3:{s:4:"time";d:1480624511.2233779430389404296875;s:5:"event";s:15:"status-approved";s:4:"user";s:10:"cse.mahmud";}'),
(8, 3, 'akismet_error', '1480660018'),
(9, 3, 'akismet_history', 'a:4:{s:4:"time";d:1480660019.0077540874481201171875;s:5:"event";s:11:"check-error";s:4:"user";s:11:"subscriber1";s:4:"meta";a:1:{s:8:"response";s:7:"invalid";}}'),
(10, 3, 'akismet_as_submitted', 'a:13:{s:14:"comment_author";s:10:"Subscriber";s:20:"comment_author_email";s:21:"subscriber1@gmail.com";s:18:"comment_author_url";s:0:"";s:15:"comment_content";s:85:"আমি ক্যাটরিনা কাইফকে ভালোবাসি ।";s:12:"comment_type";s:0:"";s:7:"user_ID";i:5;s:7:"user_id";i:5;s:7:"user_ip";s:3:"::1";s:10:"user_agent";s:108:"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.10 Safari/537.36";s:4:"blog";s:37:"http://localhost:81/wp_mahmuds_pachal";s:9:"blog_lang";s:5:"en_US";s:12:"blog_charset";s:5:"UTF-8";s:9:"permalink";s:195:"http://localhost:81/wp_mahmuds_pachal/2016/12/02/%e0%a6%95%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%9f%e0%a6%b0%e0%a6%bf%e0%a6%a8%e0%a6%be%e0%a6%b0-%e0%a6%94%e0%a6%a6%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%af/";}'),
(11, 3, 'akismet_delayed_moderation_email', '1'),
(12, 3, 'bp_activity_comment_id', '13'),
(13, 3, 'akismet_history', 'a:3:{s:4:"time";d:1480660116.10225391387939453125;s:5:"event";s:15:"status-approved";s:4:"user";s:10:"cse.mahmud";}'),
(15, 4, 'akismet_error', '1480703033'),
(16, 4, 'akismet_history', 'a:4:{s:4:"time";d:1480703034.153418064117431640625;s:5:"event";s:11:"check-error";s:4:"user";s:11:"subscriber1";s:4:"meta";a:1:{s:8:"response";b:0;}}'),
(17, 4, 'akismet_as_submitted', 'a:13:{s:14:"comment_author";s:10:"Subscriber";s:20:"comment_author_email";s:21:"subscriber1@gmail.com";s:18:"comment_author_url";s:0:"";s:15:"comment_content";s:19:"Really Interesting.";s:12:"comment_type";s:0:"";s:7:"user_ID";i:5;s:7:"user_id";i:5;s:7:"user_ip";s:3:"::1";s:10:"user_agent";s:68:"Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko";s:4:"blog";s:37:"http://localhost:81/wp_mahmuds_pachal";s:9:"blog_lang";s:5:"en_US";s:12:"blog_charset";s:5:"UTF-8";s:9:"permalink";s:225:"http://localhost:81/wp_mahmuds_pachal/2016/12/01/%e0%a6%a8%e0%a6%be%e0%a6%b8%e0%a6%be%e0%a6%b0-%e0%a6%a8%e0%a6%a4%e0%a7%81%e0%a6%a8-%e0%a6%9a%e0%a6%ae%e0%a6%95-%e0%a6%95%e0%a6%bf-%e0%a6%8f%e0%a6%b2%e0%a6%bf%e0%a7%9f%e0%a7%87/";}'),
(18, 4, 'akismet_delayed_moderation_email', '1'),
(19, 4, 'bp_activity_comment_id', '14'),
(20, 4, 'akismet_history', 'a:3:{s:4:"time";d:1480703169.9300329685211181640625;s:5:"event";s:15:"status-approved";s:4:"user";s:10:"cse.mahmud";}');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--

CREATE TABLE IF NOT EXISTS `tbl_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_comments`
--

INSERT INTO `tbl_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2016-12-01 05:51:41', '2016-12-01 05:51:41', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0),
(2, 120, 'Subscriber', 'subscriber1@gmail.com', '', '::1', '2016-12-01 14:32:05', '2016-12-01 20:32:05', 'চমৎকার   post   .   ধন্যবাদ   ।', 0, '1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.10 Safari/537.36', '', 0, 5),
(3, 130, 'Subscriber', 'subscriber1@gmail.com', '', '::1', '2016-12-02 00:26:58', '2016-12-02 06:26:58', 'আমি ক্যাটরিনা কাইফকে ভালোবাসি ।', 0, '1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.10 Safari/537.36', '', 0, 5),
(4, 97, 'Subscriber', 'subscriber1@gmail.com', '', '::1', '2016-12-02 12:23:53', '2016-12-02 18:23:53', 'Really Interesting.', 0, '1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_huge_itslider_images`
--

CREATE TABLE IF NOT EXISTS `tbl_huge_itslider_images` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `slider_id` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `image_url` text COLLATE utf8mb4_unicode_520_ci,
  `sl_url` text COLLATE utf8mb4_unicode_520_ci,
  `sl_type` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_target` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sl_stitle` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sl_sdesc` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sl_postlink` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ordering` int(11) NOT NULL,
  `published` tinyint(4) unsigned DEFAULT NULL,
  `published_in_sl_width` tinyint(4) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_huge_itslider_images`
--

INSERT INTO `tbl_huge_itslider_images` (`id`, `name`, `slider_id`, `description`, `image_url`, `sl_url`, `sl_type`, `link_target`, `sl_stitle`, `sl_sdesc`, `sl_postlink`, `ordering`, `published`, `published_in_sl_width`) VALUES
(5, '', '1', '', 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13872769_1109900412388857_897054101226765220_n.jpg', '', '', '', '', '', '', 0, 2, 1),
(6, '', '1', '', 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13767410_1109900399055525_2705110579242990808_o.jpg', '', '', '', '', '', '', 0, 2, 1),
(7, '', '1', '', 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13697997_1109900402388858_7743577443761806408_o.jpg', '', '', '', '', '', '', 0, 2, 1),
(8, '', '1', '', 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13680665_1109900405722191_2777831404448902692_n.jpg', '', '', '', '', '', '', 0, 2, 1),
(9, '', '1', '', 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13662028_1109900409055524_5232681174920285749_o.jpg', '', '', '', '', '', '', 0, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_huge_itslider_params`
--

CREATE TABLE IF NOT EXISTS `tbl_huge_itslider_params` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=133 ;

--
-- Dumping data for table `tbl_huge_itslider_params`
--

INSERT INTO `tbl_huge_itslider_params` (`id`, `name`, `title`, `description`, `value`) VALUES
(89, 'slider_crop_image', 'Slider crop image', 'Slider crop image', 'resize'),
(90, 'slider_title_color', 'Slider title color', 'Slider title color', '000000'),
(91, 'slider_title_font_size', 'Slider title font size', 'Slider title font size', '13'),
(92, 'slider_description_color', 'Slider description color', 'Slider description color', 'ffffff'),
(93, 'slider_description_font_size', 'Slider description font size', 'Slider description font size', '13'),
(94, 'slider_title_position', 'Slider title position', 'Slider title position', 'right-top'),
(95, 'slider_description_position', 'Slider description position', 'Slider description position', 'right-bottom'),
(96, 'slider_title_border_size', 'Slider Title border size', 'Slider Title border size', '0'),
(97, 'slider_title_border_color', 'Slider title border color', 'Slider title border color', 'ffffff'),
(98, 'slider_title_border_radius', 'Slider title border radius', 'Slider title border radius', '4'),
(99, 'slider_description_border_size', 'Slider description border size', 'Slider description border size', '0'),
(100, 'slider_description_border_color', 'Slider description border color', 'Slider description border color', 'ffffff'),
(101, 'slider_description_border_radius', 'Slider description border radius', 'Slider description border radius', '0'),
(102, 'slider_slideshow_border_size', 'Slider border size', 'Slider border size', '0'),
(103, 'slider_slideshow_border_color', 'Slider border color', 'Slider border color', 'ffffff'),
(104, 'slider_slideshow_border_radius', 'Slider border radius', 'Slider border radius', '0'),
(105, 'slider_navigation_type', 'Slider navigation type', 'Slider navigation type', '1'),
(106, 'slider_navigation_position', 'Slider navigation position', 'Slider navigation position', 'bottom'),
(107, 'slider_title_background_color', 'Slider title background color', 'Slider title background color', 'ffffff'),
(108, 'slider_description_background_color', 'Slider description background color', 'Slider description background color', '000000'),
(109, 'slider_title_transparent', 'Slider title has background', 'Slider title has background', 'on'),
(110, 'slider_description_transparent', 'Slider description has background', 'Slider description has background', 'on'),
(111, 'slider_slider_background_color', 'Slider slider background color', 'Slider slider background color', 'ffffff'),
(112, 'slider_dots_position', 'slider dots position', 'slider dots position', 'top'),
(113, 'slider_active_dot_color', 'slider active dot color', '', 'ffffff'),
(114, 'slider_dots_color', 'slider dots color', '', '000000'),
(115, 'slider_description_width', 'Slider description width', 'Slider description width', '70'),
(116, 'slider_description_height', 'Slider description height', 'Slider description height', '50'),
(117, 'slider_description_background_transparency', 'slider description background transparency', 'slider description background transparency', '70'),
(118, 'slider_description_text_align', 'description text-align', 'description text-align', 'justify'),
(119, 'slider_title_width', 'slider title width', 'slider title width', '30'),
(120, 'slider_title_height', 'slider title height', 'slider title height', '50'),
(121, 'slider_title_background_transparency', 'slider title background transparency', 'slider title background transparency', '70'),
(122, 'slider_title_text_align', 'title text-align', 'title text-align', 'right'),
(123, 'slider_title_has_margin', 'title has margin', 'title has margin', 'on'),
(124, 'slider_description_has_margin', 'description has margin', 'description has margin', 'on'),
(125, 'slider_show_arrows', 'Slider show left right arrows', 'Slider show left right arrows', 'on'),
(126, 'loading_icon_type', 'Slider loading icon type', 'Slider loading icon type', '1'),
(127, 'slider_thumb_count_slides', 'Slide thumbs count', 'Slide thumbs count', '3'),
(128, 'slider_dots_position_new', 'Slide Dots Position', 'Slide Dots Position', 'dotstop'),
(129, 'slider_thumb_back_color', 'Thumbnail Background Color', 'Thumbnail Background Color', 'FFFFFF'),
(130, 'slider_thumb_passive_color', 'Passive Thumbnail Color', 'Passive Thumbnail Color', 'FFFFFF'),
(131, 'slider_thumb_passive_color_trans', 'Passive Thumbnail Color Transparency', 'Passive Thumbnail Color Transparency', '50'),
(132, 'slider_thumb_height', 'Slider Thumb Height', 'Slider Thumb Height', '100');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_huge_itslider_sliders`
--

CREATE TABLE IF NOT EXISTS `tbl_huge_itslider_sliders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sl_height` int(11) unsigned DEFAULT NULL,
  `sl_width` int(11) unsigned DEFAULT NULL,
  `pause_on_hover` text COLLATE utf8mb4_unicode_520_ci,
  `slider_list_effects_s` text COLLATE utf8mb4_unicode_520_ci,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `param` text COLLATE utf8mb4_unicode_520_ci,
  `sl_position` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ordering` int(11) NOT NULL,
  `published` text COLLATE utf8mb4_unicode_520_ci,
  `sl_loading_icon` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `show_thumb` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'dotstop',
  `video_autoplay` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'off',
  `random_images` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'off',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_huge_itslider_sliders`
--

INSERT INTO `tbl_huge_itslider_sliders` (`id`, `name`, `sl_height`, `sl_width`, `pause_on_hover`, `slider_list_effects_s`, `description`, `param`, `sl_position`, `ordering`, `published`, `sl_loading_icon`, `show_thumb`, `video_autoplay`, `random_images`) VALUES
(1, 'My First Slider', 300, 300, 'on', 'random', '4000', '1000', 'center', 1, '300', 'off', 'dotstop', 'off', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_links`
--

CREATE TABLE IF NOT EXISTS `tbl_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ngg_album`
--

CREATE TABLE IF NOT EXISTS `tbl_ngg_album` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `previewpic` bigint(20) NOT NULL DEFAULT '0',
  `albumdesc` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `sortorder` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pageid` bigint(20) NOT NULL DEFAULT '0',
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `extras_post_id_key` (`extras_post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ngg_gallery`
--

CREATE TABLE IF NOT EXISTS `tbl_ngg_gallery` (
  `gid` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `title` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `galdesc` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `pageid` bigint(20) NOT NULL DEFAULT '0',
  `previewpic` bigint(20) NOT NULL DEFAULT '0',
  `author` bigint(20) NOT NULL DEFAULT '0',
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  KEY `extras_post_id_key` (`extras_post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_ngg_gallery`
--

INSERT INTO `tbl_ngg_gallery` (`gid`, `name`, `slug`, `path`, `title`, `galdesc`, `pageid`, `previewpic`, `author`, `extras_post_id`) VALUES
(1, 'my_images', 'my_images', '\\wp-content\\gallery\\my_images', 'my_images', NULL, 0, 1, 1, 58);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ngg_pictures`
--

CREATE TABLE IF NOT EXISTS `tbl_ngg_pictures` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT,
  `image_slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) NOT NULL DEFAULT '0',
  `galleryid` bigint(20) NOT NULL DEFAULT '0',
  `filename` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `alttext` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `imagedate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `exclude` tinyint(4) DEFAULT '0',
  `sortorder` bigint(20) NOT NULL DEFAULT '0',
  `meta_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  `updated_at` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `extras_post_id_key` (`extras_post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_ngg_pictures`
--

INSERT INTO `tbl_ngg_pictures` (`pid`, `image_slug`, `post_id`, `galleryid`, `filename`, `description`, `alttext`, `imagedate`, `exclude`, `sortorder`, `meta_data`, `extras_post_id`, `updated_at`) VALUES
(1, '13662028_1109900409055524_5232681174920285749_o', 0, 1, '13662028_1109900409055524_5232681174920285749_o.jpg', '', '13662028_1109900409055524_5232681174920285749_o', '2016-12-01 06:39:49', 0, 0, 'eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiIxMzY2MjAyOF8xMTA5OTAwNDA5MDU1NTI0XzUyMzI2ODExNzQ5MjAyODU3NDlfby5qcGciLCJ3aWR0aCI6MTE1MiwiaGVpZ2h0IjoxMTUyLCJnZW5lcmF0ZWQiOiIwLjY2MTY3MDAwIDE0ODA1NzQzODkifSwid2lkdGgiOjExNTIsImhlaWdodCI6MTE1MiwiZnVsbCI6eyJ3aWR0aCI6MTE1MiwiaGVpZ2h0IjoxMTUyfSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic18xMzY2MjAyOF8xMTA5OTAwNDA5MDU1NTI0XzUyMzI2ODExNzQ5MjAyODU3NDlfby5qcGciLCJnZW5lcmF0ZWQiOiIwLjQxNjcyMzAwIDE0ODA1NzQzOTAifSwiYXBlcnR1cmUiOmZhbHNlLCJjcmVkaXQiOmZhbHNlLCJjYW1lcmEiOmZhbHNlLCJjYXB0aW9uIjpmYWxzZSwiY3JlYXRlZF90aW1lc3RhbXAiOmZhbHNlLCJjb3B5cmlnaHQiOmZhbHNlLCJmb2NhbF9sZW5ndGgiOmZhbHNlLCJpc28iOmZhbHNlLCJzaHV0dGVyX3NwZWVkIjpmYWxzZSwiZmxhc2giOmZhbHNlLCJ0aXRsZSI6ZmFsc2UsImtleXdvcmRzIjpmYWxzZSwic2F2ZWQiOnRydWV9', 57, 1480574390),
(2, '13680665_1109900405722191_2777831404448902692_n', 0, 1, '13680665_1109900405722191_2777831404448902692_n.jpg', '', '13680665_1109900405722191_2777831404448902692_n', '2016-12-01 06:39:55', 0, 0, 'eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiIxMzY4MDY2NV8xMTA5OTAwNDA1NzIyMTkxXzI3Nzc4MzE0MDQ0NDg5MDI2OTJfbi5qcGciLCJ3aWR0aCI6NTQwLCJoZWlnaHQiOjU0MCwiZ2VuZXJhdGVkIjoiMC45NDgwOTIwMCAxNDgwNTc0Mzk1In0sIndpZHRoIjo1NDAsImhlaWdodCI6NTQwLCJmdWxsIjp7IndpZHRoIjo1NDAsImhlaWdodCI6NTQwfSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic18xMzY4MDY2NV8xMTA5OTAwNDA1NzIyMTkxXzI3Nzc4MzE0MDQ0NDg5MDI2OTJfbi5qcGciLCJnZW5lcmF0ZWQiOiIwLjMxNDIwMzAwIDE0ODA1NzQzOTcifSwiYXBlcnR1cmUiOmZhbHNlLCJjcmVkaXQiOmZhbHNlLCJjYW1lcmEiOmZhbHNlLCJjYXB0aW9uIjpmYWxzZSwiY3JlYXRlZF90aW1lc3RhbXAiOmZhbHNlLCJjb3B5cmlnaHQiOmZhbHNlLCJmb2NhbF9sZW5ndGgiOmZhbHNlLCJpc28iOmZhbHNlLCJzaHV0dGVyX3NwZWVkIjpmYWxzZSwiZmxhc2giOmZhbHNlLCJ0aXRsZSI6ZmFsc2UsImtleXdvcmRzIjpmYWxzZSwic2F2ZWQiOnRydWV9', 60, 1480574397),
(3, '13697997_1109900402388858_7743577443761806408_o', 0, 1, '13697997_1109900402388858_7743577443761806408_o.jpg', '', '13697997_1109900402388858_7743577443761806408_o', '2016-12-01 06:40:02', 0, 0, 'eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiIxMzY5Nzk5N18xMTA5OTAwNDAyMzg4ODU4Xzc3NDM1Nzc0NDM3NjE4MDY0MDhfby5qcGciLCJ3aWR0aCI6MTIwMCwiaGVpZ2h0IjoxMjAwLCJnZW5lcmF0ZWQiOiIwLjAyNjY4NzAwIDE0ODA1NzQ0MDIifSwid2lkdGgiOjEyMDAsImhlaWdodCI6MTIwMCwiZnVsbCI6eyJ3aWR0aCI6MTIwMCwiaGVpZ2h0IjoxMjAwfSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic18xMzY5Nzk5N18xMTA5OTAwNDAyMzg4ODU4Xzc3NDM1Nzc0NDM3NjE4MDY0MDhfby5qcGciLCJnZW5lcmF0ZWQiOiIwLjg0NTU3ODAwIDE0ODA1NzQ0MDMifSwiYXBlcnR1cmUiOmZhbHNlLCJjcmVkaXQiOmZhbHNlLCJjYW1lcmEiOmZhbHNlLCJjYXB0aW9uIjpmYWxzZSwiY3JlYXRlZF90aW1lc3RhbXAiOmZhbHNlLCJjb3B5cmlnaHQiOmZhbHNlLCJmb2NhbF9sZW5ndGgiOmZhbHNlLCJpc28iOmZhbHNlLCJzaHV0dGVyX3NwZWVkIjpmYWxzZSwiZmxhc2giOmZhbHNlLCJ0aXRsZSI6ZmFsc2UsImtleXdvcmRzIjpmYWxzZSwic2F2ZWQiOnRydWV9', 62, 1480574403),
(4, '13767410_1109900399055525_2705110579242990808_o', 0, 1, '13767410_1109900399055525_2705110579242990808_o.jpg', '', '13767410_1109900399055525_2705110579242990808_o', '2016-12-01 06:40:10', 0, 0, 'eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiIxMzc2NzQxMF8xMTA5OTAwMzk5MDU1NTI1XzI3MDUxMTA1NzkyNDI5OTA4MDhfby5qcGciLCJ3aWR0aCI6MTE1MiwiaGVpZ2h0IjoxMTUyLCJnZW5lcmF0ZWQiOiIwLjI0MjQyNzAwIDE0ODA1NzQ0MTAifSwid2lkdGgiOjExNTIsImhlaWdodCI6MTE1MiwiZnVsbCI6eyJ3aWR0aCI6MTE1MiwiaGVpZ2h0IjoxMTUyfSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic18xMzc2NzQxMF8xMTA5OTAwMzk5MDU1NTI1XzI3MDUxMTA1NzkyNDI5OTA4MDhfby5qcGciLCJnZW5lcmF0ZWQiOiIwLjQxNTIwOTAwIDE0ODA1NzQ0MTEifSwiYXBlcnR1cmUiOmZhbHNlLCJjcmVkaXQiOmZhbHNlLCJjYW1lcmEiOmZhbHNlLCJjYXB0aW9uIjpmYWxzZSwiY3JlYXRlZF90aW1lc3RhbXAiOmZhbHNlLCJjb3B5cmlnaHQiOmZhbHNlLCJmb2NhbF9sZW5ndGgiOmZhbHNlLCJpc28iOmZhbHNlLCJzaHV0dGVyX3NwZWVkIjpmYWxzZSwiZmxhc2giOmZhbHNlLCJ0aXRsZSI6ZmFsc2UsImtleXdvcmRzIjpmYWxzZSwic2F2ZWQiOnRydWV9', 64, 1480574411),
(5, '13872769_1109900412388857_897054101226765220_n', 0, 1, '13872769_1109900412388857_897054101226765220_n.jpg', '', '13872769_1109900412388857_897054101226765220_n', '2016-12-01 06:40:14', 0, 0, 'eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiIxMzg3Mjc2OV8xMTA5OTAwNDEyMzg4ODU3Xzg5NzA1NDEwMTIyNjc2NTIyMF9uLmpwZyIsIndpZHRoIjo0ODAsImhlaWdodCI6NDgwLCJnZW5lcmF0ZWQiOiIwLjI0OTIxODAwIDE0ODA1NzQ0MTQifSwid2lkdGgiOjQ4MCwiaGVpZ2h0Ijo0ODAsImZ1bGwiOnsid2lkdGgiOjQ4MCwiaGVpZ2h0Ijo0ODB9LCJ0aHVtYm5haWwiOnsid2lkdGgiOjI0MCwiaGVpZ2h0IjoxNjAsImZpbGVuYW1lIjoidGh1bWJzXzEzODcyNzY5XzExMDk5MDA0MTIzODg4NTdfODk3MDU0MTAxMjI2NzY1MjIwX24uanBnIiwiZ2VuZXJhdGVkIjoiMC41NTczOTYwMCAxNDgwNTc0NDE0In0sImFwZXJ0dXJlIjpmYWxzZSwiY3JlZGl0IjpmYWxzZSwiY2FtZXJhIjpmYWxzZSwiY2FwdGlvbiI6ZmFsc2UsImNyZWF0ZWRfdGltZXN0YW1wIjpmYWxzZSwiY29weXJpZ2h0IjpmYWxzZSwiZm9jYWxfbGVuZ3RoIjpmYWxzZSwiaXNvIjpmYWxzZSwic2h1dHRlcl9zcGVlZCI6ZmFsc2UsImZsYXNoIjpmYWxzZSwidGl0bGUiOmZhbHNlLCJrZXl3b3JkcyI6ZmFsc2UsInNhdmVkIjp0cnVlfQ==', 66, 1480574414);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_options`
--

CREATE TABLE IF NOT EXISTS `tbl_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1211 ;

--
-- Dumping data for table `tbl_options`
--

INSERT INTO `tbl_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:81/wp_mahmuds_pachal', 'yes'),
(2, 'home', 'http://localhost:81/wp_mahmuds_pachal', 'yes'),
(3, 'blogname', 'M@hmud&#039;s Pachal', 'yes'),
(4, 'blogdescription', 'Welcome to my Blog!', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'cse.mahmudul@gmail.com', 'yes'),
(7, 'start_of_week', '0', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '1', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '1', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:318:{s:36:"event/([^/]+)/(\\d{4}-\\d{2}-\\d{2})/?$";s:54:"index.php?ecwd_event=$matches[1]&eventDate=$matches[2]";s:20:"event/([^/]+)/all/?$";s:70:"index.php?post_type=ecwd_event&ecwd_event=$matches[1]&eventDisplay=all";s:17:"events/page/(\\d+)";s:66:"index.php?post_type=ecwd_event&eventDisplay=list&paged=$matches[1]";s:34:"events/(feed|rdf|rss|rss2|atom)/?$";s:65:"index.php?post_type=ecwd_event&eventDisplay=list&feed=$matches[1]";s:21:"events/(\\d{4}-\\d{2})$";s:71:"index.php?post_type=ecwd_event&eventDisplay=month&eventDate=$matches[1]";s:29:"events/(\\d{4}-\\d{2}-\\d{2})/?$";s:69:"index.php?post_type=ecwd_event&eventDisplay=day&eventDate=$matches[1]";s:14:"events/feed/?$";s:58:"index.php?post_type=ecwd_eventeventDisplay=list&&feed=rss2";s:9:"events/?$";s:51:"index.php?post_type=ecwd_event&eventDisplay=default";s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:8:"login/?$";s:24:"index.php?pagename=login";s:8:"event/?$";s:30:"index.php?post_type=ecwd_event";s:38:"event/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?post_type=ecwd_event&feed=$matches[1]";s:33:"event/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?post_type=ecwd_event&feed=$matches[1]";s:25:"event/page/([0-9]{1,})/?$";s:48:"index.php?post_type=ecwd_event&paged=$matches[1]";s:12:"organizer/?$";s:34:"index.php?post_type=ecwd_organizer";s:42:"organizer/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?post_type=ecwd_organizer&feed=$matches[1]";s:37:"organizer/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?post_type=ecwd_organizer&feed=$matches[1]";s:29:"organizer/page/([0-9]{1,})/?$";s:52:"index.php?post_type=ecwd_organizer&paged=$matches[1]";s:8:"venue/?$";s:30:"index.php?post_type=ecwd_venue";s:38:"venue/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?post_type=ecwd_venue&feed=$matches[1]";s:33:"venue/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?post_type=ecwd_venue&feed=$matches[1]";s:25:"venue/page/([0-9]{1,})/?$";s:48:"index.php?post_type=ecwd_venue&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"event_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?ecwd_event_category=$matches[1]&feed=$matches[2]";s:50:"event_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?ecwd_event_category=$matches[1]&feed=$matches[2]";s:31:"event_category/([^/]+)/embed/?$";s:52:"index.php?ecwd_event_category=$matches[1]&embed=true";s:43:"event_category/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?ecwd_event_category=$matches[1]&paged=$matches[2]";s:25:"event_category/([^/]+)/?$";s:41:"index.php?ecwd_event_category=$matches[1]";s:50:"event_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?ecwd_event_tag=$matches[1]&feed=$matches[2]";s:45:"event_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?ecwd_event_tag=$matches[1]&feed=$matches[2]";s:26:"event_tag/([^/]+)/embed/?$";s:47:"index.php?ecwd_event_tag=$matches[1]&embed=true";s:38:"event_tag/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?ecwd_event_tag=$matches[1]&paged=$matches[2]";s:20:"event_tag/([^/]+)/?$";s:36:"index.php?ecwd_event_tag=$matches[1]";s:48:"ngg_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?ngg_tag=$matches[1]&feed=$matches[2]";s:43:"ngg_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?ngg_tag=$matches[1]&feed=$matches[2]";s:24:"ngg_tag/([^/]+)/embed/?$";s:40:"index.php?ngg_tag=$matches[1]&embed=true";s:36:"ngg_tag/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?ngg_tag=$matches[1]&paged=$matches[2]";s:18:"ngg_tag/([^/]+)/?$";s:29:"index.php?ngg_tag=$matches[1]";s:55:"bp_member_type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?bp_member_type=$matches[1]&feed=$matches[2]";s:50:"bp_member_type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?bp_member_type=$matches[1]&feed=$matches[2]";s:31:"bp_member_type/([^/]+)/embed/?$";s:47:"index.php?bp_member_type=$matches[1]&embed=true";s:43:"bp_member_type/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?bp_member_type=$matches[1]&paged=$matches[2]";s:25:"bp_member_type/([^/]+)/?$";s:36:"index.php?bp_member_type=$matches[1]";s:54:"bp_group_type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?bp_group_type=$matches[1]&feed=$matches[2]";s:49:"bp_group_type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?bp_group_type=$matches[1]&feed=$matches[2]";s:30:"bp_group_type/([^/]+)/embed/?$";s:46:"index.php?bp_group_type=$matches[1]&embed=true";s:42:"bp_group_type/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?bp_group_type=$matches[1]&paged=$matches[2]";s:24:"bp_group_type/([^/]+)/?$";s:35:"index.php?bp_group_type=$matches[1]";s:37:"ngg_album/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"ngg_album/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"ngg_album/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"ngg_album/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"ngg_album/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"ngg_album/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"ngg_album/([^/]+)/embed/?$";s:42:"index.php?ngg_album=$matches[1]&embed=true";s:30:"ngg_album/([^/]+)/trackback/?$";s:36:"index.php?ngg_album=$matches[1]&tb=1";s:38:"ngg_album/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?ngg_album=$matches[1]&paged=$matches[2]";s:45:"ngg_album/([^/]+)/comment-page-([0-9]{1,})/?$";s:49:"index.php?ngg_album=$matches[1]&cpage=$matches[2]";s:34:"ngg_album/([^/]+)(?:/([0-9]+))?/?$";s:48:"index.php?ngg_album=$matches[1]&page=$matches[2]";s:26:"ngg_album/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"ngg_album/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"ngg_album/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"ngg_album/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"ngg_album/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"ngg_album/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:39:"ngg_gallery/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"ngg_gallery/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"ngg_gallery/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"ngg_gallery/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"ngg_gallery/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"ngg_gallery/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:28:"ngg_gallery/([^/]+)/embed/?$";s:44:"index.php?ngg_gallery=$matches[1]&embed=true";s:32:"ngg_gallery/([^/]+)/trackback/?$";s:38:"index.php?ngg_gallery=$matches[1]&tb=1";s:40:"ngg_gallery/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?ngg_gallery=$matches[1]&paged=$matches[2]";s:47:"ngg_gallery/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?ngg_gallery=$matches[1]&cpage=$matches[2]";s:36:"ngg_gallery/([^/]+)(?:/([0-9]+))?/?$";s:50:"index.php?ngg_gallery=$matches[1]&page=$matches[2]";s:28:"ngg_gallery/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"ngg_gallery/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"ngg_gallery/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"ngg_gallery/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"ngg_gallery/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"ngg_gallery/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:40:"ngg_pictures/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"ngg_pictures/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"ngg_pictures/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"ngg_pictures/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"ngg_pictures/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"ngg_pictures/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"ngg_pictures/([^/]+)/embed/?$";s:45:"index.php?ngg_pictures=$matches[1]&embed=true";s:33:"ngg_pictures/([^/]+)/trackback/?$";s:39:"index.php?ngg_pictures=$matches[1]&tb=1";s:41:"ngg_pictures/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?ngg_pictures=$matches[1]&paged=$matches[2]";s:48:"ngg_pictures/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?ngg_pictures=$matches[1]&cpage=$matches[2]";s:37:"ngg_pictures/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?ngg_pictures=$matches[1]&page=$matches[2]";s:29:"ngg_pictures/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"ngg_pictures/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"ngg_pictures/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"ngg_pictures/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"ngg_pictures/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"ngg_pictures/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:44:"lightbox_library/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:54:"lightbox_library/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:74:"lightbox_library/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"lightbox_library/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"lightbox_library/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:50:"lightbox_library/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"lightbox_library/([^/]+)/embed/?$";s:49:"index.php?lightbox_library=$matches[1]&embed=true";s:37:"lightbox_library/([^/]+)/trackback/?$";s:43:"index.php?lightbox_library=$matches[1]&tb=1";s:45:"lightbox_library/([^/]+)/page/?([0-9]{1,})/?$";s:56:"index.php?lightbox_library=$matches[1]&paged=$matches[2]";s:52:"lightbox_library/([^/]+)/comment-page-([0-9]{1,})/?$";s:56:"index.php?lightbox_library=$matches[1]&cpage=$matches[2]";s:41:"lightbox_library/([^/]+)(?:/([0-9]+))?/?$";s:55:"index.php?lightbox_library=$matches[1]&page=$matches[2]";s:33:"lightbox_library/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"lightbox_library/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"lightbox_library/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"lightbox_library/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"lightbox_library/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"lightbox_library/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:41:"ecwd_calendar/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:51:"ecwd_calendar/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:71:"ecwd_calendar/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"ecwd_calendar/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"ecwd_calendar/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:47:"ecwd_calendar/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:30:"ecwd_calendar/([^/]+)/embed/?$";s:46:"index.php?ecwd_calendar=$matches[1]&embed=true";s:34:"ecwd_calendar/([^/]+)/trackback/?$";s:40:"index.php?ecwd_calendar=$matches[1]&tb=1";s:42:"ecwd_calendar/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?ecwd_calendar=$matches[1]&paged=$matches[2]";s:49:"ecwd_calendar/([^/]+)/comment-page-([0-9]{1,})/?$";s:53:"index.php?ecwd_calendar=$matches[1]&cpage=$matches[2]";s:38:"ecwd_calendar/([^/]+)(?:/([0-9]+))?/?$";s:52:"index.php?ecwd_calendar=$matches[1]&page=$matches[2]";s:30:"ecwd_calendar/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:40:"ecwd_calendar/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:60:"ecwd_calendar/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"ecwd_calendar/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"ecwd_calendar/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:36:"ecwd_calendar/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"event/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"event/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"event/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"event/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"event/([^/]+)/embed/?$";s:43:"index.php?ecwd_event=$matches[1]&embed=true";s:26:"event/([^/]+)/trackback/?$";s:37:"index.php?ecwd_event=$matches[1]&tb=1";s:46:"event/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?ecwd_event=$matches[1]&feed=$matches[2]";s:41:"event/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?ecwd_event=$matches[1]&feed=$matches[2]";s:34:"event/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?ecwd_event=$matches[1]&paged=$matches[2]";s:41:"event/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?ecwd_event=$matches[1]&cpage=$matches[2]";s:30:"event/([^/]+)(?:/([0-9]+))?/?$";s:49:"index.php?ecwd_event=$matches[1]&page=$matches[2]";s:22:"event/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"event/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"event/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"event/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:35:"organizer/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"organizer/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"organizer/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"organizer/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"organizer/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"organizer/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"organizer/(.+?)/embed/?$";s:47:"index.php?ecwd_organizer=$matches[1]&embed=true";s:28:"organizer/(.+?)/trackback/?$";s:41:"index.php?ecwd_organizer=$matches[1]&tb=1";s:48:"organizer/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?ecwd_organizer=$matches[1]&feed=$matches[2]";s:43:"organizer/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?ecwd_organizer=$matches[1]&feed=$matches[2]";s:36:"organizer/(.+?)/page/?([0-9]{1,})/?$";s:54:"index.php?ecwd_organizer=$matches[1]&paged=$matches[2]";s:43:"organizer/(.+?)/comment-page-([0-9]{1,})/?$";s:54:"index.php?ecwd_organizer=$matches[1]&cpage=$matches[2]";s:32:"organizer/(.+?)(?:/([0-9]+))?/?$";s:53:"index.php?ecwd_organizer=$matches[1]&page=$matches[2]";s:31:"venue/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"venue/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"venue/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"venue/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"venue/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"venue/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:20:"venue/(.+?)/embed/?$";s:43:"index.php?ecwd_venue=$matches[1]&embed=true";s:24:"venue/(.+?)/trackback/?$";s:37:"index.php?ecwd_venue=$matches[1]&tb=1";s:44:"venue/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?ecwd_venue=$matches[1]&feed=$matches[2]";s:39:"venue/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?ecwd_venue=$matches[1]&feed=$matches[2]";s:32:"venue/(.+?)/page/?([0-9]{1,})/?$";s:50:"index.php?ecwd_venue=$matches[1]&paged=$matches[2]";s:39:"venue/(.+?)/comment-page-([0-9]{1,})/?$";s:50:"index.php?ecwd_venue=$matches[1]&cpage=$matches[2]";s:28:"venue/(.+?)(?:/([0-9]+))?/?$";s:49:"index.php?ecwd_venue=$matches[1]&page=$matches[2]";s:45:"displayed_gallery/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"displayed_gallery/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"displayed_gallery/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"displayed_gallery/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"displayed_gallery/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"displayed_gallery/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"displayed_gallery/([^/]+)/embed/?$";s:50:"index.php?displayed_gallery=$matches[1]&embed=true";s:38:"displayed_gallery/([^/]+)/trackback/?$";s:44:"index.php?displayed_gallery=$matches[1]&tb=1";s:46:"displayed_gallery/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?displayed_gallery=$matches[1]&paged=$matches[2]";s:53:"displayed_gallery/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?displayed_gallery=$matches[1]&cpage=$matches[2]";s:42:"displayed_gallery/([^/]+)(?:/([0-9]+))?/?$";s:56:"index.php?displayed_gallery=$matches[1]&page=$matches[2]";s:34:"displayed_gallery/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"displayed_gallery/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"displayed_gallery/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"displayed_gallery/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"displayed_gallery/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"displayed_gallery/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:40:"display_type/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"display_type/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"display_type/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"display_type/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"display_type/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"display_type/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"display_type/([^/]+)/embed/?$";s:45:"index.php?display_type=$matches[1]&embed=true";s:33:"display_type/([^/]+)/trackback/?$";s:39:"index.php?display_type=$matches[1]&tb=1";s:41:"display_type/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?display_type=$matches[1]&paged=$matches[2]";s:48:"display_type/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?display_type=$matches[1]&cpage=$matches[2]";s:37:"display_type/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?display_type=$matches[1]&page=$matches[2]";s:29:"display_type/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"display_type/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"display_type/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"display_type/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"display_type/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"display_type/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:46:"gal_display_source/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:56:"gal_display_source/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:76:"gal_display_source/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:71:"gal_display_source/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:71:"gal_display_source/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:52:"gal_display_source/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:35:"gal_display_source/([^/]+)/embed/?$";s:51:"index.php?gal_display_source=$matches[1]&embed=true";s:39:"gal_display_source/([^/]+)/trackback/?$";s:45:"index.php?gal_display_source=$matches[1]&tb=1";s:47:"gal_display_source/([^/]+)/page/?([0-9]{1,})/?$";s:58:"index.php?gal_display_source=$matches[1]&paged=$matches[2]";s:54:"gal_display_source/([^/]+)/comment-page-([0-9]{1,})/?$";s:58:"index.php?gal_display_source=$matches[1]&cpage=$matches[2]";s:43:"gal_display_source/([^/]+)(?:/([0-9]+))?/?$";s:57:"index.php?gal_display_source=$matches[1]&page=$matches[2]";s:35:"gal_display_source/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"gal_display_source/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"gal_display_source/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"gal_display_source/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"gal_display_source/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"gal_display_source/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=76&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:12:{i:0;s:19:"akismet/akismet.php";i:1;s:43:"all-in-one-seo-pack/all_in_one_seo_pack.php";i:2;s:46:"archives-calendar-widget/archives-calendar.php";i:3;s:24:"buddypress/bp-loader.php";i:4;s:26:"event-calendar-wd/ecwd.php";i:5;s:9:"hello.php";i:6;s:29:"nextgen-gallery/nggallery.php";i:7;s:47:"sewn-in-template-log-in/sewn-template-login.php";i:8;s:23:"slider-image/slider.php";i:9;s:65:"subscribe-to-comments-reloaded/subscribe-to-comments-reloaded.php";i:10;s:33:"w3-total-cache/w3-total-cache.php";i:11;s:24:"wordpress-seo/wp-seo.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '-6', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'blue-scenery', 'yes'),
(41, 'stylesheet', 'blue-scenery', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '1', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '37965', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:2:{s:26:"event-calendar-wd/ecwd.php";a:2:{i:0;s:10:"ECWD_Admin";i:1;s:9:"uninstall";}s:46:"archives-calendar-widget/archives-calendar.php";s:26:"archivesCalendar_uninstall";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '2', 'yes'),
(84, 'page_on_front', '76', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '5', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '37965', 'yes'),
(92, 'tbl_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:73:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;s:16:"aiosp_manage_seo";b:1;s:24:"NextGEN Gallery overview";b:1;s:19:"NextGEN Use TinyMCE";b:1;s:21:"NextGEN Upload images";b:1;s:22:"NextGEN Manage gallery";b:1;s:19:"NextGEN Manage tags";b:1;s:29:"NextGEN Manage others gallery";b:1;s:18:"NextGEN Edit album";b:1;s:20:"NextGEN Change style";b:1;s:22:"NextGEN Change options";b:1;s:24:"NextGEN Attach Interface";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:4:{i:0;s:13:"ecwd_widget-2";i:1;s:10:"archives-2";i:2;s:6:"meta-2";i:3;s:17:"recent-comments-2";}s:19:"primary-widget-area";a:8:{i:0;s:8:"search-2";i:1;s:22:"bp_core_login_widget-2";i:2;s:12:"categories-2";i:3;s:22:"hugeit_slider_widget-2";i:4;s:14:"recent-posts-2";i:5;s:19:"archives_calendar-2";i:6;s:28:"bp_core_whos_online_widget-2";i:7;s:24:"bp_core_members_widget-2";}s:13:"array_version";i:3;}', 'yes'),
(99, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'cron', 'a:9:{i:1480706268;a:1:{s:29:"akismet_schedule_cron_recheck";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1480706311;a:1:{s:29:"ngg_delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"ngg_custom";s:4:"args";a:0:{}s:8:"interval";i:900;}}}i:1480709253;a:1:{s:30:"_cron_subscribe_reloaded_purge";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1480710725;a:1:{s:24:"akismet_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1480744303;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1480744329;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1480748437;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1480785228;a:1:{s:28:"fs_data_sync_nextgen-gallery";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(107, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.6.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.6.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.6.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.6.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.6.1";s:7:"version";s:5:"4.6.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.4";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1480702642;s:15:"version_checked";s:5:"4.6.1";s:12:"translations";a:0:{}}', 'no'),
(117, 'can_compress_scripts', '1', 'no'),
(118, '_site_transient_timeout_wporg_theme_feature_list', '1480582377', 'no'),
(119, '_site_transient_wporg_theme_feature_list', 'a:3:{s:6:"Layout";a:7:{i:0;s:11:"grid-layout";i:1;s:10:"one-column";i:2;s:11:"two-columns";i:3;s:13:"three-columns";i:4;s:12:"four-columns";i:5;s:12:"left-sidebar";i:6;s:13:"right-sidebar";}s:8:"Features";a:20:{i:0;s:19:"accessibility-ready";i:1;s:10:"buddypress";i:2;s:17:"custom-background";i:3;s:13:"custom-colors";i:4;s:13:"custom-header";i:5;s:11:"custom-menu";i:6;s:12:"editor-style";i:7;s:21:"featured-image-header";i:8;s:15:"featured-images";i:9;s:15:"flexible-header";i:10;s:14:"footer-widgets";i:11;s:20:"front-page-post-form";i:12;s:19:"full-width-template";i:13;s:12:"microformats";i:14;s:12:"post-formats";i:15;s:20:"rtl-language-support";i:16;s:11:"sticky-post";i:17;s:13:"theme-options";i:18;s:17:"threaded-comments";i:19;s:17:"translation-ready";}s:7:"Subject";a:9:{i:0;s:4:"blog";i:1;s:10:"e-commerce";i:2;s:9:"education";i:3;s:13:"entertainment";i:4;s:14:"food-and-drink";i:5;s:7:"holiday";i:6;s:4:"news";i:7;s:11:"photography";i:8;s:9:"portfolio";}}', 'no'),
(121, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1480702642;s:7:"checked";a:3:{s:12:"blue-scenery";s:3:"1.6";s:14:"twentyfourteen";s:3:"1.8";s:13:"twentysixteen";s:3:"1.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'no'),
(122, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1480572026;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(123, 'current_theme', 'Blue Scenery', 'yes'),
(124, 'theme_mods_blue-scenery', 'a:7:{i:0;b:0;s:30:"blue_scenery_recent_post_slide";s:1:"1";s:27:"blue_scenery_slider_image_1";s:87:"http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/fb_MHKDhoom3_image.jpg";s:27:"blue_scenery_slider_image_2";s:104:"http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Follow-your-herat-chase-your-dreams.png";s:27:"blue_scenery_slider_image_3";s:75:"http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/100167.gif";s:27:"blue_scenery_slider_image_4";s:106:"http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/1468618_1378334399081666_1667513437_n.jpg";s:18:"nav_menu_locations";a:1:{s:11:"header-menu";i:2;}}', 'yes'),
(125, 'theme_switched', '', 'yes'),
(128, 'nav_menu_options', 'a:1:{s:8:"auto_add";a:1:{i:0;i:2;}}', 'yes'),
(133, 'bp-deactivated-components', 'a:0:{}', 'yes'),
(134, 'bb-config-location', 'G:\\XAMPP_Software\\htdocs\\wp_mahmuds_pachal/bb-config.php', 'yes'),
(135, 'bp-xprofile-base-group-name', 'Base', 'yes'),
(136, 'bp-xprofile-fullname-field-name', 'Name', 'yes'),
(137, 'bp-blogs-first-install', '', 'yes'),
(138, 'bp-disable-profile-sync', '0', 'yes'),
(139, 'hide-loggedout-adminbar', '0', 'yes'),
(140, 'bp-disable-avatar-uploads', '0', 'yes'),
(141, 'bp-disable-cover-image-uploads', '0', 'yes'),
(142, 'bp-disable-group-avatar-uploads', '1', 'yes'),
(143, 'bp-disable-group-cover-image-uploads', '1', 'yes'),
(144, 'bp-disable-account-deletion', '0', 'yes'),
(145, 'bp-disable-blogforum-comments', '0', 'yes'),
(146, '_bp_theme_package_id', 'legacy', 'yes'),
(147, 'bp-emails-unsubscribe-salt', 'UWs4JFQhPXl+WH51cGljOj5hbittIVhwYnIhb1VgVn1yWHVOOXt1bD50RkNuXyZVZVJ8YGkpVXBuLXBecmd2Nw==', 'yes'),
(148, 'bp_restrict_group_creation', '1', 'yes'),
(149, '_bp_enable_akismet', '1', 'yes'),
(150, '_bp_enable_heartbeat_refresh', '1', 'yes'),
(151, '_bp_force_buddybar', '', 'yes'),
(152, '_bp_retain_bp_default', '', 'yes'),
(153, '_bp_ignore_deprecated_code', '1', 'yes'),
(154, 'widget_bp_core_login_widget', 'a:3:{i:1;a:0:{}i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(155, 'widget_bp_core_members_widget', 'a:2:{i:2;a:4:{s:5:"title";s:7:"Members";s:11:"max_members";s:1:"5";s:14:"member_default";s:6:"active";s:10:"link_title";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(156, 'widget_bp_core_whos_online_widget', 'a:2:{i:2;a:2:{s:5:"title";s:12:"Who''s Online";s:11:"max_members";s:2:"15";}s:12:"_multiwidget";i:1;}', 'yes'),
(157, 'widget_bp_core_recently_active_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(158, 'widget_bp_groups_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(159, 'widget_bp_messages_sitewide_notices_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(164, 'recently_activated', 'a:0:{}', 'yes');
INSERT INTO `tbl_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(165, 'bp-active-components', 'a:9:{s:8:"xprofile";s:1:"1";s:8:"settings";s:1:"1";s:7:"friends";s:1:"1";s:8:"messages";s:1:"1";s:8:"activity";s:1:"1";s:13:"notifications";s:1:"1";s:6:"groups";s:1:"1";s:5:"blogs";s:1:"1";s:7:"members";s:1:"1";}', 'yes'),
(167, 'bp-pages', 'a:5:{s:8:"activity";i:10;s:7:"members";i:11;s:6:"groups";i:46;s:8:"register";i:72;s:8:"activate";i:74;}', 'yes'),
(169, '_bp_db_version', '11105', 'yes'),
(171, 'bp_disable_blogforum_comments', '1', 'yes'),
(172, 'widget_bp_core_friends_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(177, 'wpseo', 'a:21:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:3:"3.9";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";b:0;s:16:"environment_type";s:0:"";s:20:"enable_setting_pages";b:0;s:21:"enable_admin_bar_menu";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1480573366;}', 'yes'),
(178, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(179, 'wpseo_titles', 'a:56:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:23:"content-analysis-active";b:1;s:23:"keyword-analysis-active";b:1;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(180, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"7e2f3f03eb07d9463556a2d6ce6e6ea8";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(181, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(182, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(183, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(184, 'wpseo_flush_rewrite', '1', 'yes'),
(185, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(188, 'w3tc_state', '{"common.install":1480573476}', 'no'),
(196, 'aioseop_options', 'a:85:{s:16:"aiosp_home_title";N;s:22:"aiosp_home_description";s:0:"";s:20:"aiosp_togglekeywords";i:1;s:19:"aiosp_home_keywords";N;s:26:"aiosp_use_static_home_info";i:0;s:9:"aiosp_can";i:1;s:30:"aiosp_no_paged_canonical_links";i:0;s:31:"aiosp_customize_canonical_links";i:0;s:20:"aiosp_rewrite_titles";i:1;s:20:"aiosp_force_rewrites";i:1;s:24:"aiosp_use_original_title";i:0;s:16:"aiosp_cap_titles";i:1;s:28:"aiosp_home_page_title_format";s:12:"%page_title%";s:23:"aiosp_page_title_format";s:27:"%page_title% | %blog_title%";s:23:"aiosp_post_title_format";s:27:"%post_title% | %blog_title%";s:27:"aiosp_category_title_format";s:31:"%category_title% | %blog_title%";s:26:"aiosp_archive_title_format";s:30:"%archive_title% | %blog_title%";s:23:"aiosp_date_title_format";s:21:"%date% | %blog_title%";s:25:"aiosp_author_title_format";s:23:"%author% | %blog_title%";s:22:"aiosp_tag_title_format";s:20:"%tag% | %blog_title%";s:25:"aiosp_search_title_format";s:23:"%search% | %blog_title%";s:24:"aiosp_description_format";s:13:"%description%";s:22:"aiosp_404_title_format";s:33:"Nothing found for %request_words%";s:18:"aiosp_paged_format";s:14:" - Part %page%";s:17:"aiosp_enablecpost";s:2:"on";s:17:"aiosp_cpostactive";a:2:{i:0;s:4:"post";i:1;s:4:"page";}s:19:"aiosp_cpostadvanced";i:0;s:18:"aiosp_cpostnoindex";a:0:{}s:19:"aiosp_cpostnofollow";a:0:{}s:16:"aiosp_cpostnoodp";a:0:{}s:17:"aiosp_cpostnoydir";a:0:{}s:17:"aiosp_cposttitles";i:0;s:21:"aiosp_posttypecolumns";a:2:{i:0;s:4:"post";i:1;s:4:"page";}s:19:"aiosp_google_verify";s:0:"";s:17:"aiosp_bing_verify";s:0:"";s:22:"aiosp_pinterest_verify";s:0:"";s:22:"aiosp_google_publisher";s:0:"";s:28:"aiosp_google_disable_profile";i:0;s:29:"aiosp_google_sitelinks_search";N;s:26:"aiosp_google_set_site_name";N;s:30:"aiosp_google_specify_site_name";N;s:28:"aiosp_google_author_advanced";i:0;s:28:"aiosp_google_author_location";a:1:{i:0;s:3:"all";}s:29:"aiosp_google_enable_publisher";s:2:"on";s:30:"aiosp_google_specify_publisher";N;s:25:"aiosp_google_analytics_id";N;s:25:"aiosp_ga_advanced_options";s:2:"on";s:15:"aiosp_ga_domain";N;s:21:"aiosp_ga_multi_domain";i:0;s:21:"aiosp_ga_addl_domains";N;s:21:"aiosp_ga_anonymize_ip";N;s:28:"aiosp_ga_display_advertising";N;s:22:"aiosp_ga_exclude_users";N;s:29:"aiosp_ga_track_outbound_links";i:0;s:25:"aiosp_ga_link_attribution";i:0;s:27:"aiosp_ga_enhanced_ecommerce";i:0;s:20:"aiosp_use_categories";i:0;s:26:"aiosp_use_tags_as_keywords";i:1;s:32:"aiosp_dynamic_postspage_keywords";i:1;s:22:"aiosp_category_noindex";i:1;s:26:"aiosp_archive_date_noindex";i:1;s:28:"aiosp_archive_author_noindex";i:1;s:18:"aiosp_tags_noindex";i:0;s:20:"aiosp_search_noindex";i:0;s:17:"aiosp_404_noindex";i:0;s:17:"aiosp_tax_noindex";a:0:{}s:23:"aiosp_paginated_noindex";i:0;s:24:"aiosp_paginated_nofollow";i:0;s:11:"aiosp_noodp";i:0;s:12:"aiosp_noydir";i:0;s:18:"aiosp_skip_excerpt";i:0;s:27:"aiosp_generate_descriptions";i:0;s:20:"aiosp_run_shortcodes";i:0;s:33:"aiosp_hide_paginated_descriptions";i:0;s:32:"aiosp_dont_truncate_descriptions";i:0;s:19:"aiosp_schema_markup";i:1;s:20:"aiosp_unprotect_meta";i:0;s:33:"aiosp_redirect_attachement_parent";i:0;s:14:"aiosp_ex_pages";s:0:"";s:20:"aiosp_post_meta_tags";s:0:"";s:20:"aiosp_page_meta_tags";s:0:"";s:21:"aiosp_front_meta_tags";s:0:"";s:20:"aiosp_home_meta_tags";s:0:"";s:12:"aiosp_do_log";N;s:19:"last_active_version";s:6:"2.3.11";}', 'yes'),
(208, 'wpseo-gsc-refresh_token', '1/4FZcj88hwd_pBSYl_8zPkqurUUVocqbz--aYF6BC9nY', 'yes'),
(209, 'wpseo-gsc-access_token', 'a:5:{s:13:"refresh_token";s:45:"1/4FZcj88hwd_pBSYl_8zPkqurUUVocqbz--aYF6BC9nY";s:12:"access_token";s:71:"ya29.Ci-nA9OgkX8tWtkET2Z6C_3Ujsm_37xwxR0RsFcAkrFlYXkZyq9Lk0JdrZ7xvH0MoQ";s:7:"expires";i:1480577393;s:10:"expires_in";i:3600;s:7:"created";i:1480573793;}', 'yes'),
(212, 'ngg_run_freemius', '1', 'yes'),
(213, 'fs_active_plugins', 'O:8:"stdClass":2:{s:7:"plugins";a:1:{s:24:"nextgen-gallery/freemius";O:8:"stdClass":3:{s:7:"version";s:5:"1.2.1";s:9:"timestamp";i:1480573963;s:11:"plugin_path";s:9:"hello.php";}}s:6:"newest";O:8:"stdClass":5:{s:11:"plugin_path";s:9:"hello.php";s:8:"sdk_path";s:24:"nextgen-gallery/freemius";s:7:"version";s:5:"1.2.1";s:13:"in_activation";b:0;s:9:"timestamp";i:1480573963;}}', 'yes'),
(214, 'fs_debug_mode', '', 'yes'),
(215, 'fs_accounts', 'a:11:{s:11:"plugin_data";a:1:{s:15:"nextgen-gallery";a:19:{s:16:"plugin_main_file";O:8:"stdClass":1:{s:4:"path";s:91:"G:/XAMPP_Software/htdocs/wp_mahmuds_pachal/wp-content/plugins/nextgen-gallery/nggallery.php";}s:17:"install_timestamp";i:1480573963;s:16:"sdk_last_version";N;s:11:"sdk_version";s:5:"1.2.1";s:16:"sdk_upgrade_mode";b:1;s:18:"sdk_downgrade_mode";b:0;s:19:"plugin_last_version";N;s:14:"plugin_version";s:6:"2.1.60";s:19:"plugin_upgrade_mode";b:1;s:21:"plugin_downgrade_mode";b:0;s:21:"is_plugin_new_install";b:1;s:17:"connectivity_test";a:6:{s:12:"is_connected";b:1;s:4:"host";s:12:"localhost:81";s:9:"server_ip";s:3:"::1";s:9:"is_active";b:1;s:9:"timestamp";i:1480573963;s:7:"version";s:6:"2.1.60";}s:17:"was_plugin_loaded";b:1;s:15:"prev_is_premium";b:0;s:14:"has_trial_plan";b:1;s:22:"install_sync_timestamp";i:1480702642;s:20:"activation_timestamp";i:1480577142;s:9:"sync_cron";O:8:"stdClass":4:{s:7:"version";s:6:"2.1.60";s:11:"sdk_version";s:5:"1.2.1";s:9:"timestamp";i:1480577150;s:2:"on";b:1;}s:14:"sync_timestamp";i:1480702636;}}s:13:"file_slug_map";a:1:{s:29:"nextgen-gallery/nggallery.php";s:15:"nextgen-gallery";}s:7:"plugins";a:1:{s:15:"nextgen-gallery";O:9:"FS_Plugin":15:{s:16:"parent_plugin_id";N;s:5:"title";s:15:"NextGEN Gallery";s:4:"slug";s:15:"nextgen-gallery";s:4:"file";s:29:"nextgen-gallery/nggallery.php";s:7:"version";s:6:"2.1.60";s:11:"auto_update";N;s:4:"info";N;s:10:"is_premium";b:0;s:7:"is_live";b:1;s:10:"public_key";s:32:"pk_009356711cd548837f074e1ef60a4";s:10:"secret_key";N;s:2:"id";s:3:"266";s:7:"updated";N;s:7:"created";N;s:22:"\0FS_Entity\0_is_updated";b:0;}}s:9:"unique_id";s:32:"ff890e2094f7b8a016970ed4e79a3313";s:13:"admin_notices";a:1:{s:15:"nextgen-gallery";a:1:{s:19:"activation_complete";a:8:{s:7:"message";s:61:"<b>NextGEN Gallery</b> activation was successfully completed.";s:5:"title";s:0:"";s:4:"type";s:7:"success";s:6:"sticky";b:1;s:2:"id";s:19:"activation_complete";s:3:"all";b:0;s:4:"slug";s:15:"nextgen-gallery";s:6:"plugin";s:15:"NextGEN Gallery";}}}s:5:"plans";a:1:{s:15:"nextgen-gallery";a:1:{i:0;O:14:"FS_Plugin_Plan":21:{s:9:"plugin_id";s:4:"MjY2";s:4:"name";s:8:"ZnJlZQ==";s:5:"title";s:8:"RnJlZQ==";s:11:"description";N;s:17:"is_free_localhost";s:4:"MQ==";s:17:"is_block_features";s:4:"MQ==";s:12:"license_type";s:4:"MA==";s:16:"is_https_support";s:0:"";s:12:"trial_period";N;s:23:"is_require_subscription";s:0:"";s:10:"support_kb";N;s:13:"support_forum";N;s:13:"support_email";N;s:13:"support_phone";N;s:13:"support_skype";N;s:18:"is_success_manager";s:0:"";s:11:"is_featured";s:0:"";s:2:"id";s:4:"Mzc0";s:7:"updated";N;s:7:"created";s:28:"MjAxNi0wNC0yNCAxNToyNzo0Nw==";s:22:"\0FS_Entity\0_is_updated";b:0;}}}s:5:"sites";a:1:{s:15:"nextgen-gallery";O:7:"FS_Site":22:{s:4:"slug";s:15:"nextgen-gallery";s:7:"site_id";s:7:"1202483";s:9:"plugin_id";s:3:"266";s:7:"user_id";s:6:"232105";s:5:"title";s:0:"";s:3:"url";s:37:"http://localhost:81/wp_mahmuds_pachal";s:7:"version";s:6:"2.1.60";s:8:"language";s:5:"en-US";s:7:"charset";s:5:"UTF-8";s:16:"platform_version";s:5:"4.6.1";s:28:"programming_language_version";N;s:4:"plan";O:14:"FS_Plugin_Plan":21:{s:9:"plugin_id";s:4:"MjY2";s:4:"name";s:8:"ZnJlZQ==";s:5:"title";s:8:"RnJlZQ==";s:11:"description";N;s:17:"is_free_localhost";s:4:"MQ==";s:17:"is_block_features";s:4:"MQ==";s:12:"license_type";s:4:"MA==";s:16:"is_https_support";s:0:"";s:12:"trial_period";N;s:23:"is_require_subscription";s:0:"";s:10:"support_kb";N;s:13:"support_forum";N;s:13:"support_email";N;s:13:"support_phone";N;s:13:"support_skype";N;s:18:"is_success_manager";s:0:"";s:11:"is_featured";s:0:"";s:2:"id";s:4:"Mzc0";s:7:"updated";N;s:7:"created";s:28:"MjAxNi0wNC0yNCAxNToyNzo0Nw==";s:22:"\0FS_Entity\0_is_updated";b:0;}s:10:"license_id";N;s:13:"trial_plan_id";N;s:10:"trial_ends";N;s:10:"is_premium";b:0;s:10:"public_key";s:32:"pk_8daa45abb2df9419b14689b98992b";s:10:"secret_key";s:32:"sk_]0goqY2GYp]I6>;dtSzb}F@PS;[Q%";s:2:"id";s:6:"272174";s:7:"updated";N;s:7:"created";s:19:"2016-12-01 07:25:47";s:22:"\0FS_Entity\0_is_updated";b:0;}}s:11:"all_plugins";O:8:"stdClass":3:{s:9:"timestamp";i:1480702637;s:3:"md5";s:32:"520de869880c785e6f9b670f2c0ffcc9";s:7:"plugins";a:12:{s:19:"akismet/akismet.php";a:5:{s:4:"slug";s:7:"akismet";s:7:"version";s:3:"3.2";s:5:"title";s:7:"Akismet";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:43:"all-in-one-seo-pack/all_in_one_seo_pack.php";a:5:{s:4:"slug";s:19:"all-in-one-seo-pack";s:7:"version";s:6:"2.3.11";s:5:"title";s:19:"All In One SEO Pack";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:24:"buddypress/bp-loader.php";a:5:{s:4:"slug";s:10:"buddypress";s:7:"version";s:5:"2.7.2";s:5:"title";s:10:"BuddyPress";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:9:"hello.php";a:5:{s:4:"slug";s:11:"hello-dolly";s:7:"version";s:3:"1.6";s:5:"title";s:11:"Hello Dolly";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:29:"nextgen-gallery/nggallery.php";a:5:{s:4:"slug";s:15:"nextgen-gallery";s:7:"version";s:6:"2.1.60";s:5:"title";s:15:"NextGEN Gallery";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:23:"slider-image/slider.php";a:5:{s:4:"slug";s:12:"slider-image";s:7:"version";s:6:"3.1.98";s:5:"title";s:6:"Slider";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:33:"w3-total-cache/w3-total-cache.php";a:5:{s:4:"slug";s:14:"w3-total-cache";s:7:"version";s:7:"0.9.5.1";s:5:"title";s:14:"W3 Total Cache";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:24:"wordpress-seo/wp-seo.php";a:5:{s:4:"slug";s:13:"wordpress-seo";s:7:"version";s:3:"3.9";s:5:"title";s:9:"Yoast SEO";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:46:"archives-calendar-widget/archives-calendar.php";a:5:{s:4:"slug";s:24:"archives-calendar-widget";s:7:"version";s:6:"1.0.12";s:5:"title";s:24:"Archives Calendar Widget";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:26:"event-calendar-wd/ecwd.php";a:5:{s:4:"slug";s:17:"event-calendar-wd";s:7:"version";s:6:"1.0.77";s:5:"title";s:17:"Event Calendar WD";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:47:"sewn-in-template-log-in/sewn-template-login.php";a:5:{s:4:"slug";s:23:"sewn-in-template-log-in";s:7:"version";s:5:"1.1.4";s:5:"title";s:23:"Sewn In Template Log In";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:65:"subscribe-to-comments-reloaded/subscribe-to-comments-reloaded.php";a:5:{s:4:"slug";s:30:"subscribe-to-comments-reloaded";s:7:"version";s:6:"160915";s:5:"title";s:30:"Subscribe to Comments Reloaded";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}}}s:10:"all_themes";O:8:"stdClass":3:{s:9:"timestamp";i:1480702641;s:3:"md5";s:32:"0aefc49472d9816f90d1955858889629";s:6:"themes";a:3:{s:12:"blue-scenery";a:5:{s:4:"slug";s:12:"blue-scenery";s:7:"version";s:3:"1.6";s:5:"title";s:12:"Blue Scenery";s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;}s:14:"twentyfourteen";a:5:{s:4:"slug";s:14:"twentyfourteen";s:7:"version";s:3:"1.8";s:5:"title";s:15:"Twenty Fourteen";s:9:"is_active";b:0;s:14:"is_uninstalled";b:0;}s:13:"twentysixteen";a:5:{s:4:"slug";s:13:"twentysixteen";s:7:"version";s:3:"1.3";s:5:"title";s:14:"Twenty Sixteen";s:9:"is_active";b:0;s:14:"is_uninstalled";b:0;}}}s:5:"users";a:1:{i:232105;O:7:"FS_User":12:{s:5:"email";s:22:"cse.mahmudul@gmail.com";s:5:"first";s:14:"Mahmudul Hasan";s:4:"last";s:4:"Khan";s:11:"is_verified";b:1;s:11:"customer_id";N;s:5:"gross";i:0;s:10:"public_key";s:32:"pk_2d13abb830e65f740b136afe1e961";s:10:"secret_key";s:32:"sk_yC8:9qa+&Cmh5LkY%$7Ty]&cPc{>m";s:2:"id";s:6:"232105";s:7:"updated";s:19:"2016-12-01 07:25:47";s:7:"created";s:19:"2016-11-30 20:34:14";s:22:"\0FS_Entity\0_is_updated";b:0;}}s:8:"licenses";a:1:{s:15:"nextgen-gallery";a:1:{i:232105;b:0;}}}', 'yes'),
(216, 'fs_api_cache', 'a:3:{s:25:"get:/v1/users/232105.json";O:8:"stdClass":2:{s:6:"result";O:8:"stdClass":14:{s:11:"customer_id";N;s:5:"gross";i:0;s:2:"ip";s:14:"103.230.105.26";s:6:"source";i:0;s:5:"email";s:22:"cse.mahmudul@gmail.com";s:5:"first";s:14:"Mahmudul Hasan";s:4:"last";s:4:"Khan";s:7:"picture";N;s:11:"is_verified";b:1;s:10:"secret_key";s:32:"sk_yC8:9qa+&Cmh5LkY%$7Ty]&cPc{>m";s:10:"public_key";s:32:"pk_2d13abb830e65f740b136afe1e961";s:2:"id";s:6:"232105";s:7:"created";s:19:"2016-11-30 20:34:14";s:7:"updated";s:19:"2016-12-01 07:25:47";}s:9:"timestamp";i:1480663542;}s:28:"get:/v1/installs/272174.json";O:8:"stdClass":2:{s:6:"result";O:8:"stdClass":30:{s:7:"site_id";s:7:"1202483";s:9:"plugin_id";s:3:"266";s:7:"user_id";s:6:"232105";s:3:"url";s:37:"http://localhost:81/wp_mahmuds_pachal";s:5:"title";s:0:"";s:7:"version";s:6:"2.1.60";s:7:"plan_id";s:3:"374";s:10:"license_id";N;s:13:"trial_plan_id";N;s:10:"trial_ends";N;s:15:"subscription_id";N;s:5:"gross";i:0;s:12:"country_code";s:2:"bd";s:8:"language";s:5:"en-US";s:7:"charset";s:5:"UTF-8";s:16:"platform_version";s:5:"4.6.1";s:11:"sdk_version";N;s:28:"programming_language_version";N;s:9:"is_active";b:1;s:15:"is_disconnected";b:0;s:10:"is_premium";b:0;s:14:"is_uninstalled";b:0;s:9:"is_locked";b:0;s:6:"source";i:0;s:8:"upgraded";N;s:10:"secret_key";s:32:"sk_]0goqY2GYp]I6>;dtSzb}F@PS;[Q%";s:10:"public_key";s:32:"pk_8daa45abb2df9419b14689b98992b";s:2:"id";s:6:"272174";s:7:"created";s:19:"2016-12-01 07:25:47";s:7:"updated";N;}s:9:"timestamp";i:1480663542;}s:34:"get:/v1/installs/272174/plans.json";O:8:"stdClass":2:{s:6:"result";O:8:"stdClass":1:{s:5:"plans";a:1:{i:0;O:8:"stdClass":21:{s:9:"plugin_id";s:3:"266";s:4:"name";s:4:"free";s:5:"title";s:4:"Free";s:11:"description";N;s:17:"is_free_localhost";b:1;s:17:"is_block_features";b:1;s:12:"license_type";i:0;s:16:"is_https_support";b:0;s:12:"trial_period";N;s:23:"is_require_subscription";b:0;s:10:"support_kb";N;s:13:"support_forum";N;s:13:"support_email";N;s:13:"support_phone";N;s:13:"support_skype";N;s:18:"is_success_manager";b:0;s:11:"is_featured";b:0;s:9:"is_hidden";b:0;s:2:"id";s:3:"374";s:7:"created";s:19:"2016-04-24 15:27:47";s:7:"updated";N;}}}s:9:"timestamp";i:1480663542;}}', 'yes'),
(218, 'widget_ngg-images', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(219, 'widget_ngg-mrssw', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(220, 'widget_slideshow', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(221, 'ngg_transient_groups', 'a:7:{s:9:"__counter";i:7;s:3:"MVC";a:2:{s:2:"id";i:2;s:7:"enabled";b:1;}s:16:"col_in_tbl_posts";a:2:{s:2:"id";i:3;s:7:"enabled";b:1;}s:22:"col_in_tbl_ngg_gallery";a:2:{s:2:"id";i:4;s:7:"enabled";b:1;}s:23:"col_in_tbl_ngg_pictures";a:2:{s:2:"id";i:5;s:7:"enabled";b:1;}s:27:"displayed_gallery_rendering";a:2:{s:2:"id";i:6;s:7:"enabled";b:1;}s:20:"col_in_tbl_ngg_album";a:2:{s:2:"id";i:7;s:7:"enabled";b:1;}}', 'yes'),
(222, 'ngg_options', 'a:70:{s:11:"gallerypath";s:19:"wp-content\\gallery\\";s:11:"wpmuCSSfile";s:13:"nggallery.css";s:9:"wpmuStyle";b:0;s:9:"wpmuRoles";b:0;s:16:"wpmuImportFolder";b:0;s:13:"wpmuZipUpload";b:0;s:14:"wpmuQuotaCheck";b:0;s:17:"datamapper_driver";s:22:"custom_post_datamapper";s:21:"gallerystorage_driver";s:25:"ngglegacy_gallery_storage";s:20:"maximum_entity_count";i:500;s:17:"router_param_slug";s:9:"nggallery";s:22:"router_param_separator";s:2:"--";s:19:"router_param_prefix";s:0:"";s:9:"deleteImg";b:1;s:9:"swfUpload";b:1;s:13:"usePermalinks";b:0;s:13:"permalinkSlug";s:9:"nggallery";s:14:"graphicLibrary";s:2:"gd";s:14:"imageMagickDir";s:15:"/usr/local/bin/";s:11:"useMediaRSS";b:0;s:18:"galleries_in_feeds";b:0;s:12:"activateTags";i:0;s:10:"appendType";s:4:"tags";s:9:"maxImages";i:7;s:14:"relatedHeading";s:24:"<h3>Related Images:</h3>";s:10:"thumbwidth";i:240;s:11:"thumbheight";i:160;s:8:"thumbfix";b:1;s:12:"thumbquality";i:100;s:8:"imgWidth";i:800;s:9:"imgHeight";i:600;s:10:"imgQuality";i:100;s:9:"imgBackup";b:1;s:13:"imgAutoResize";b:0;s:9:"galImages";s:2:"20";s:17:"galPagedGalleries";i:0;s:10:"galColumns";i:0;s:12:"galShowSlide";b:1;s:12:"galTextSlide";s:16:"[Show slideshow]";s:14:"galTextGallery";s:17:"[Show thumbnails]";s:12:"galShowOrder";s:7:"gallery";s:7:"galSort";s:9:"sortorder";s:10:"galSortDir";s:3:"ASC";s:10:"galNoPages";b:1;s:13:"galImgBrowser";i:0;s:12:"galHiddenImg";i:0;s:10:"galAjaxNav";i:0;s:11:"thumbEffect";s:8:"fancybox";s:9:"thumbCode";s:41:"class="ngg-fancybox" rel="%GALLERY_NAME%"";s:18:"thumbEffectContext";s:14:"nextgen_images";s:5:"wmPos";s:8:"botRight";s:6:"wmXpos";i:5;s:6:"wmYpos";i:5;s:6:"wmType";s:5:"image";s:6:"wmPath";s:0:"";s:6:"wmFont";s:9:"arial.ttf";s:6:"wmSize";i:10;s:6:"wmText";s:20:"M@hmud&#039;s Pachal";s:7:"wmColor";s:6:"000000";s:8:"wmOpaque";s:3:"100";s:7:"slideFX";s:4:"fade";s:7:"irWidth";i:600;s:8:"irHeight";i:400;s:12:"irRotatetime";i:10;s:11:"activateCSS";i:1;s:7:"CSSfile";s:13:"nggallery.css";s:28:"always_enable_frontend_logic";b:0;s:22:"dynamic_thumbnail_slug";s:13:"nextgen-image";s:23:"dynamic_stylesheet_slug";s:12:"nextgen-dcss";s:11:"installDate";i:1480573992;}', 'yes'),
(224, 'photocrati_auto_update_admin_update_list', '', 'yes'),
(225, 'photocrati_auto_update_admin_check_date', '', 'yes'),
(226, 'ngg_db_version', '1.8.1', 'yes'),
(229, 'pope_module_list', 'a:34:{i:0;s:17:"photocrati-fs|0.6";i:1;s:19:"photocrati-i18n|0.3";i:2;s:25:"photocrati-validation|0.2";i:3;s:21:"photocrati-router|0.9";i:4;s:32:"photocrati-wordpress_routing|0.8";i:5;s:23:"photocrati-security|0.3";i:6;s:32:"photocrati-nextgen_settings|0.15";i:7;s:18:"photocrati-mvc|0.8";i:8;s:20:"photocrati-ajax|0.10";i:9;s:26:"photocrati-datamapper|0.10";i:10;s:30:"photocrati-nextgen-legacy|0.18";i:11;s:28:"photocrati-nextgen-data|0.14";i:12;s:33:"photocrati-dynamic_thumbnails|0.7";i:13;s:29:"photocrati-nextgen_admin|0.11";i:14;s:39:"photocrati-nextgen_gallery_display|0.16";i:15;s:34:"photocrati-frame_communication|0.5";i:16;s:30:"photocrati-attach_to_post|0.17";i:17;s:38:"photocrati-nextgen_addgallery_page|0.9";i:18;s:36:"photocrati-nextgen_other_options|0.9";i:19;s:33:"photocrati-nextgen_pagination|0.4";i:20;s:33:"photocrati-dynamic_stylesheet|0.4";i:21;s:34:"photocrati-nextgen_pro_upgrade|0.6";i:22;s:20:"photocrati-cache|0.2";i:23;s:24:"photocrati-lightbox|0.17";i:24;s:38:"photocrati-nextgen_basic_templates|0.7";i:25;s:37:"photocrati-nextgen_basic_gallery|0.16";i:26;s:42:"photocrati-nextgen_basic_imagebrowser|0.13";i:27;s:39:"photocrati-nextgen_basic_singlepic|0.14";i:28;s:38:"photocrati-nextgen_basic_tagcloud|0.15";i:29;s:35:"photocrati-nextgen_basic_album|0.17";i:30;s:21:"photocrati-widget|0.6";i:31;s:33:"photocrati-third_party_compat|0.6";i:32;s:29:"photocrati-nextgen_xmlrpc|0.6";i:33;s:20:"photocrati-wpcli|0.2";}', 'yes'),
(231, 'wpseo_sitemap_1_cache_validator', '5R88M', 'no'),
(232, 'wpseo_sitemap_display_type_cache_validator', '23mZ', 'no'),
(241, 'slider_image_version', '3.2', 'yes'),
(242, 'slider_image_imege_hover_preview', 'on', 'yes'),
(243, 'widget_hugeit_slider_widget', 'a:2:{i:2;a:2:{s:9:"slider_id";s:1:"1";s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(253, 'wpseo_sitemap_ngg_gallery_cache_validator', '2JHG5', 'no'),
(254, 'wpseo_sitemap_ngg_pictures_cache_validator', '2JO1H', 'no'),
(287, 'wpseo_sitemap_attachment_cache_validator', '2Du54', 'no'),
(297, 'WPLANG', '', 'yes'),
(300, 'wpseo_sitemap_page_cache_validator', '5H7K9', 'no'),
(301, 'wpseo_sitemap_nav_menu_item_cache_validator', '4NO5d', 'no'),
(302, 'wpseo_sitemap_nav_menu_cache_validator', '4NO4A', 'no'),
(328, 'wpseo_sitemap_revision_cache_validator', '2F4UT', 'no'),
(342, 'wpseo_sitemap_cache_validator_global', '2RMpz', 'no'),
(348, 'wpseo_sitemap_category_cache_validator', '2F4QG', 'no'),
(352, 'wpseo_taxonomy_meta', 'a:1:{s:8:"category";a:8:{i:26;a:3:{s:13:"wpseo_focuskw";s:32:"বিনোদন,entertainment";s:13:"wpseo_linkdex";s:2:"11";s:19:"wpseo_content_score";s:2:"30";}i:24;a:3:{s:13:"wpseo_focuskw";s:57:"বিজ্ঞান,প্রযুক্তি,science";s:13:"wpseo_linkdex";s:2:"11";s:19:"wpseo_content_score";s:2:"30";}i:27;a:3:{s:13:"wpseo_focuskw";s:25:"বলিউড,bollywood";s:13:"wpseo_linkdex";s:2:"11";s:19:"wpseo_content_score";s:2:"30";}i:23;a:3:{s:13:"wpseo_focuskw";s:27:"আমার,কথা,blog";s:13:"wpseo_linkdex";s:2:"17";s:19:"wpseo_content_score";s:2:"30";}i:30;a:3:{s:13:"wpseo_focuskw";s:15:"ছবি,photo";s:13:"wpseo_linkdex";s:2:"11";s:19:"wpseo_content_score";s:2:"30";}i:25;a:3:{s:13:"wpseo_focuskw";s:43:"তথ্য,প্রযুক্তি,it";s:13:"wpseo_linkdex";s:2:"15";s:19:"wpseo_content_score";s:2:"30";}i:28;a:3:{s:13:"wpseo_focuskw";s:50:"মহাকাশ,বিজ্ঞান,astronomy";s:13:"wpseo_linkdex";s:2:"11";s:19:"wpseo_content_score";s:2:"30";}i:29;a:3:{s:13:"wpseo_focuskw";s:25:"হলিউড,hollywood";s:13:"wpseo_linkdex";s:2:"11";s:19:"wpseo_content_score";s:2:"30";}}}', 'yes'),
(467, 'wpseo_sitemap_author_cache_validator', '3XDz', 'no'),
(470, 'wpseo_sitemap_post_cache_validator', '5NpEj', 'no'),
(529, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1480626465', 'no'),
(530, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:100:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"6110";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"3747";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"3738";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"3244";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2869";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"2546";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"2229";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"2155";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"2104";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"2089";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"2044";}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";s:4:"2025";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1965";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1937";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1756";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1653";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1625";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1469";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:4:"1380";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1299";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:4:"1296";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:4:"1152";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:4:"1136";}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";s:4:"1065";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:4:"1027";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:4:"1017";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"969";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"964";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"963";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"932";}s:10:"responsive";a:3:{s:4:"name";s:10:"responsive";s:4:"slug";s:10:"responsive";s:5:"count";s:3:"929";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"916";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"861";}s:10:"e-commerce";a:3:{s:4:"name";s:10:"e-commerce";s:4:"slug";s:10:"e-commerce";s:5:"count";s:3:"851";}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";s:3:"841";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"821";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"788";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"783";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"783";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"770";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"759";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"751";}s:9:"analytics";a:3:{s:4:"name";s:9:"analytics";s:4:"slug";s:9:"analytics";s:5:"count";s:3:"749";}s:6:"slider";a:3:{s:4:"name";s:6:"slider";s:4:"slug";s:6:"slider";s:5:"count";s:3:"743";}s:3:"css";a:3:{s:4:"name";s:3:"CSS";s:4:"slug";s:3:"css";s:5:"count";s:3:"736";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"731";}s:4:"form";a:3:{s:4:"name";s:4:"form";s:4:"slug";s:4:"form";s:5:"count";s:3:"725";}s:5:"embed";a:3:{s:4:"name";s:5:"embed";s:4:"slug";s:5:"embed";s:5:"count";s:3:"718";}s:6:"search";a:3:{s:4:"name";s:6:"search";s:4:"slug";s:6:"search";s:5:"count";s:3:"718";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"710";}s:6:"custom";a:3:{s:4:"name";s:6:"custom";s:4:"slug";s:6:"custom";s:5:"count";s:3:"701";}s:9:"slideshow";a:3:{s:4:"name";s:9:"slideshow";s:4:"slug";s:9:"slideshow";s:5:"count";s:3:"656";}s:4:"menu";a:3:{s:4:"name";s:4:"menu";s:4:"slug";s:4:"menu";s:5:"count";s:3:"652";}s:6:"button";a:3:{s:4:"name";s:6:"button";s:4:"slug";s:6:"button";s:5:"count";s:3:"640";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"635";}s:5:"theme";a:3:{s:4:"name";s:5:"theme";s:4:"slug";s:5:"theme";s:5:"count";s:3:"629";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"616";}s:9:"dashboard";a:3:{s:4:"name";s:9:"dashboard";s:4:"slug";s:9:"dashboard";s:5:"count";s:3:"615";}s:4:"tags";a:3:{s:4:"name";s:4:"tags";s:4:"slug";s:4:"tags";s:5:"count";s:3:"614";}s:6:"mobile";a:3:{s:4:"name";s:6:"mobile";s:4:"slug";s:6:"mobile";s:5:"count";s:3:"612";}s:10:"categories";a:3:{s:4:"name";s:10:"categories";s:4:"slug";s:10:"categories";s:5:"count";s:3:"601";}s:6:"editor";a:3:{s:4:"name";s:6:"editor";s:4:"slug";s:6:"editor";s:5:"count";s:3:"585";}s:10:"statistics";a:3:{s:4:"name";s:10:"statistics";s:4:"slug";s:10:"statistics";s:5:"count";s:3:"585";}s:3:"ads";a:3:{s:4:"name";s:3:"ads";s:4:"slug";s:3:"ads";s:5:"count";s:3:"584";}s:4:"user";a:3:{s:4:"name";s:4:"user";s:4:"slug";s:4:"user";s:5:"count";s:3:"580";}s:12:"social-media";a:3:{s:4:"name";s:12:"social media";s:4:"slug";s:12:"social-media";s:5:"count";s:3:"563";}s:5:"users";a:3:{s:4:"name";s:5:"users";s:4:"slug";s:5:"users";s:5:"count";s:3:"553";}s:4:"list";a:3:{s:4:"name";s:4:"list";s:4:"slug";s:4:"list";s:5:"count";s:3:"549";}s:12:"contact-form";a:3:{s:4:"name";s:12:"contact form";s:4:"slug";s:12:"contact-form";s:5:"count";s:3:"546";}s:6:"simple";a:3:{s:4:"name";s:6:"simple";s:4:"slug";s:6:"simple";s:5:"count";s:3:"540";}s:9:"affiliate";a:3:{s:4:"name";s:9:"affiliate";s:4:"slug";s:9:"affiliate";s:5:"count";s:3:"540";}s:7:"plugins";a:3:{s:4:"name";s:7:"plugins";s:4:"slug";s:7:"plugins";s:5:"count";s:3:"538";}s:9:"multisite";a:3:{s:4:"name";s:9:"multisite";s:4:"slug";s:9:"multisite";s:5:"count";s:3:"534";}s:4:"shop";a:3:{s:4:"name";s:4:"shop";s:4:"slug";s:4:"shop";s:5:"count";s:3:"522";}s:7:"picture";a:3:{s:4:"name";s:7:"picture";s:4:"slug";s:7:"picture";s:5:"count";s:3:"519";}s:9:"marketing";a:3:{s:4:"name";s:9:"marketing";s:4:"slug";s:9:"marketing";s:5:"count";s:3:"509";}s:3:"api";a:3:{s:4:"name";s:3:"api";s:4:"slug";s:3:"api";s:5:"count";s:3:"507";}s:7:"contact";a:3:{s:4:"name";s:7:"contact";s:4:"slug";s:7:"contact";s:5:"count";s:3:"496";}s:3:"url";a:3:{s:4:"name";s:3:"url";s:4:"slug";s:3:"url";s:5:"count";s:3:"484";}s:10:"navigation";a:3:{s:4:"name";s:10:"navigation";s:4:"slug";s:10:"navigation";s:5:"count";s:3:"471";}s:10:"newsletter";a:3:{s:4:"name";s:10:"newsletter";s:4:"slug";s:10:"newsletter";s:5:"count";s:3:"469";}s:8:"pictures";a:3:{s:4:"name";s:8:"pictures";s:4:"slug";s:8:"pictures";s:5:"count";s:3:"467";}s:4:"html";a:3:{s:4:"name";s:4:"html";s:4:"slug";s:4:"html";s:5:"count";s:3:"462";}s:6:"events";a:3:{s:4:"name";s:6:"events";s:4:"slug";s:6:"events";s:5:"count";s:3:"459";}s:8:"tracking";a:3:{s:4:"name";s:8:"tracking";s:4:"slug";s:8:"tracking";s:5:"count";s:3:"448";}s:10:"shortcodes";a:3:{s:4:"name";s:10:"shortcodes";s:4:"slug";s:10:"shortcodes";s:5:"count";s:3:"447";}s:8:"calendar";a:3:{s:4:"name";s:8:"calendar";s:4:"slug";s:8:"calendar";s:5:"count";s:3:"443";}s:4:"meta";a:3:{s:4:"name";s:4:"meta";s:4:"slug";s:4:"meta";s:5:"count";s:3:"438";}s:8:"lightbox";a:3:{s:4:"name";s:8:"lightbox";s:4:"slug";s:8:"lightbox";s:5:"count";s:3:"436";}s:3:"tag";a:3:{s:4:"name";s:3:"tag";s:4:"slug";s:3:"tag";s:5:"count";s:3:"430";}s:6:"paypal";a:3:{s:4:"name";s:6:"paypal";s:4:"slug";s:6:"paypal";s:5:"count";s:3:"427";}s:11:"advertising";a:3:{s:4:"name";s:11:"advertising";s:4:"slug";s:11:"advertising";s:5:"count";s:3:"426";}s:6:"upload";a:3:{s:4:"name";s:6:"upload";s:4:"slug";s:6:"upload";s:5:"count";s:3:"425";}s:12:"notification";a:3:{s:4:"name";s:12:"notification";s:4:"slug";s:12:"notification";s:5:"count";s:3:"424";}s:4:"news";a:3:{s:4:"name";s:4:"News";s:4:"slug";s:4:"news";s:5:"count";s:3:"422";}s:7:"sharing";a:3:{s:4:"name";s:7:"sharing";s:4:"slug";s:7:"sharing";s:5:"count";s:3:"422";}s:5:"flash";a:3:{s:4:"name";s:5:"flash";s:4:"slug";s:5:"flash";s:5:"count";s:3:"421";}s:9:"thumbnail";a:3:{s:4:"name";s:9:"thumbnail";s:4:"slug";s:9:"thumbnail";s:5:"count";s:3:"417";}s:16:"custom-post-type";a:3:{s:4:"name";s:16:"custom post type";s:4:"slug";s:16:"custom-post-type";s:5:"count";s:3:"414";}s:8:"linkedin";a:3:{s:4:"name";s:8:"linkedin";s:4:"slug";s:8:"linkedin";s:5:"count";s:3:"413";}}', 'no'),
(533, 'ecwd_old_events', '0', 'yes'),
(534, 'ecwd_version', '1.0.77', 'yes'),
(535, 'ecwd_settings_general', 'a:5:{s:13:"save_settings";i:1;s:11:"date_format";s:5:"Y-m-d";s:11:"time_format";s:3:"H:i";s:11:"week_starts";s:1:"0";s:9:"cpt_order";s:9:"post_name";}', 'yes'),
(536, 'widget_ecwd_widget', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:2:"id";s:2:"96";s:12:"display_type";s:4:"mini";s:10:"page_items";s:1:"5";}s:12:"_multiwidget";i:1;}', 'yes'),
(537, 'ecwd_slug_changed', '0', 'yes'),
(538, 'ecwd_single_slug', 'event', 'yes'),
(539, 'ecwd_slug', 'events', 'yes'),
(540, 'ecwd_cpt_setup', '1', 'yes'),
(542, 'ecwd_settings', '', 'yes'),
(543, 'activation_page_option', 'ok', 'yes'),
(544, 'auto_generated_posts', 'a:4:{i:0;i:90;i:1;i:91;i:2;a:2:{i:0;i:92;i:1;i:93;}i:3;a:2:{i:0;i:94;i:1;i:95;}}', 'yes'),
(545, 'wpseo_sitemap_ecwd_calendar_cache_validator', '5K9lh', 'no'),
(546, 'wpseo_sitemap_ecwd_venue_cache_validator', '3T3f', 'no'),
(547, 'wpseo_sitemap_ecwd_organizer_cache_validator', '5JAEN', 'no'),
(548, 'wpseo_sitemap_ecwd_event_cache_validator', '5JAH5', 'no'),
(551, 'ecwd_admin_notice', 'a:1:{s:19:"ecwd_new_year_promo";a:2:{s:5:"start";s:10:"12/31/2015";s:3:"int";i:0;}}', 'yes'),
(559, 'archivesCalendar', 'a:5:{s:6:"filter";i:1;s:5:"theme";s:10:"calendrier";s:13:"show_settings";i:1;s:3:"css";i:1;s:11:"plugin-init";i:1;}', 'yes'),
(560, 'archivesCalendarThemer', 'a:2:{s:10:"arw-theme1";s:7769:".calendar-archives {\n    position: relative;\n    width: 100%;\n    font-size: 13px;\n}\n\n.calendar-archives * {\n    box-sizing: border-box !important;\n}\n\n.calendar-archives a,\n.calendar-archives a:focus,\n.calendar-archives a:active {\n    outline: none !important;\n}\n\n.calendar-archives.arw-theme1 .calendar-navigation {\n    position: relative;\n    display: table;\n    width: 100%;\n}\n\n.calendar-archives.arw-theme1 .prev-year,\n.calendar-archives.arw-theme1 .next-year,\n.calendar-archives.arw-theme1 .menu-container {\n    display: table-cell;\n    height: 100%;\n    vertical-align: middle;\n}\n\n.calendar-archives.arw-theme1 > .archives-years {\n    position: relative;\n    overflow: hidden;\n}\n\n.calendar-archives.arw-theme1 .year {\n    position: absolute;\n    top: 0;\n    left: 0;\n    margin-left: -100%;\n    width: 100%;\n    z-index: 0;\n}\n\n.calendar-archives.arw-theme1 .year-link {\n    display: none;\n}\n\n.calendar-archives.arw-theme1 .year.last {\n    position: relative;\n}\n\n.calendar-archives.arw-theme1 .year.current {\n    margin-left: 0;\n    z-index: 1;\n}\n\n.settings_page_Arrchives_Calendar_Widget #TB_ajaxContent, .arcw-preview-zone {\n    background-color: #FFFFFF;\n}\n\n.calendar-archives a {\n    text-decoration: none;\n}\n\n.calendar-archives.arw-theme1 .calendar-navigation {\n    height: 30px !important;\n    margin: 0px 0px 1px 0px;\n\n    color: #FFFFFF;\n    font-size: 13px;\n\n    border-top: 0px;\n    border-right: 0px;\n    border-bottom: 0px;\n    border-left: 0px;\n    border-style: solid;\n    border-color: #4e4e4e;\n\n    border-radius: 0px;\n\n    background-color: #4e4e4e;\n}\n\n.calendar-archives.arw-theme1 .prev-year,\n.calendar-archives.arw-theme1 .next-year {\n    width: 32px;\n    border-radius: 0px;\n    font-size: 15px;\n    line-height: 30px;\n    text-align: center;\n    color: #FFFFFF;\n}\n\n.calendar-archives.arw-theme1 .prev-year > span,\n.calendar-archives.arw-theme1 .next-year > span {\n    display: block;\n    line-height: 30px;\n}\n\n.calendar-archives.arw-theme1 .prev-year:hover,\n.calendar-archives.arw-theme1 .next-year:hover {\n    color: #FFFFFF;\n    background-color: #707070;\n}\n\n.calendar-archives.arw-theme1 .prev-year:hover span,\n.calendar-archives.arw-theme1 .next-year:hover span {\n    color: #FFFFFF;\n}\n\n.calendar-archives.arw-theme1 .prev-year.disabled,\n.calendar-archives.arw-theme1 .next-year.disabled {\n    opacity: 0.4;\n    cursor: default;\n}\n\n.calendar-archives.arw-theme1 .prev-year.disabled:hover,\n.calendar-archives.arw-theme1 .next-year.disabled:hover {\n    background: none;\n}\n\n.calendar-archives.arw-theme1 .prev-year {\n    border-right: 1px #FFFFFF solid;\n    border-bottom-right-radius: 0;\n    border-top-right-radius: 0;\n}\n\n.calendar-archives.arw-theme1 .next-year {\n    border-left: 1px #FFFFFF solid;\n    border-bottom-left-radius: 0;\n    border-top-left-radius: 0;\n}\n\n.calendar-archives.arw-theme1 .menu-container {\n    position: relative;\n    height: 30px;\n    padding: 0;\n    text-align: center;\n    text-transform: capitalize;\n}\n\n.calendar-archives.arw-theme1 .menu-container:hover {\n    background-color: #707070\n}\n\n.calendar-archives.arw-theme1 .menu-container > a.title {\n    display: block;\n    height: 30px;\n    line-height: 30px;\n    color: #FFFFFF;\n    vertical-align: middle;\n}\n\n.calendar-archives.arw-theme1 .menu-container > ul,\n.calendar-archives.arw-theme1 .menu-container > ul > li {\n    margin: 0;\n    padding: 0;\n}\n\n.calendar-archives.arw-theme1 .menu-container > ul.menu {\n    position: absolute;\n    display: none;\n    width: 100%;\n    top: 0;\n    overflow: hidden;\n    border-radius: 0;\n    box-shadow: 0 0 10px 0 #000000;\n    background: #FFFFFF;\n    z-index: 99;\n}\n\n.calendar-archives.arw-theme1 .menu-container li {\n    display: block;\n}\n\n.calendar-archives.arw-theme1 .menu-container li > a {\n    display: block;\n    height: 30px;\n    line-height: 30px;\n    color: #7e7e7e;\n}\n\n.calendar-archives.arw-theme1 .menu-container li > a:hover {\n    cursor: pointer;\n    color: #FFFFFF;\n    background: #7e7e7e;\n}\n\n.calendar-archives.arw-theme1 .menu-container li > a.selected {\n    color: #FFFFFF;\n    background: #7e7e7e;\n}\n\n.calendar-archives.arw-theme1 .menu-container li > a.selected:hover {\n    text-decoration: none;\n    cursor: default;\n    color: #FFFFFF;\n    background: #7e7e7e;\n}\n\n.calendar-archives.arw-theme1 .arrow-down {\n    position: absolute;\n    width: 24px;\n    height: 30px;\n    line-height: 30px;\n    top: 0;\n    right: 0;\n    font-family: Verdana, Arial, Helvetica, sans-serif;\n    font-size: 9px;\n    color: #FFF;\n    cursor: pointer;\n    border-left: 1px #4e4e4e solid;\n}\n\n.calendar-archives.arw-theme1 .arrow-down:hover {\n    border-color: #FFFFFF !important;\n    background-color: #909090;\n}\n\n.calendar-archives.arw-theme1 .menu-container:hover > .arrow-down {\n    border-left: 1px #4e4e4e solid;\n}\n\n.calendar-archives.arw-theme1 > .archives-years {\n    background-color: #FFFFFF;\n}\n\n.calendar-archives.arw-theme1 .month,\n.calendar-archives.arw-theme1 .day {\n    position: relative;\n    display: block;\n    overflow: hidden;\n    float: left;\n    float: left;\n    color: #CCCCCC;\n    background-color: #f0f0f0;\n    border-bottom: 1px #FFFFFF solid;\n    border-right: 1px #FFFFFF solid;\n    border-radius: 0px;\n\n\n\n}\n\n.calendar-archives.arw-theme1 .month.has-posts a,\n.calendar-archives.arw-theme1 .day.has-posts a {\n    display: block;\n    width: 100%;\n    height: 100%;\n    color: #FFFFFF;\n    border-radius: 0px;\n    /*border-bottom: 3px solid #b93207;*/\n    background-color: #707070;\n}\n\n.calendar-archives.arw-theme1 .month.has-posts a:hover,\n.calendar-archives.arw-theme1 .day.has-posts a:hover {\n    background-color: #4E4E4E;\n    color: #FFFFFF;\n}\n\n.calendar-archives.arw-theme1 .month.last,\n.calendar-archives.arw-theme1 .day.last {\n    border-right: none !important;\n    margin-right: 0 !important;\n}\n\n.calendar-archives.arw-theme1 .month {\n    width: 25%;\n    height: 50px;\n}\n\n.calendar-archives.arw-theme1 .month-name {\n    text-transform: capitalize;\n    font-size: 16px;\n    font-weight: 400;\n    display: block;\n    position: absolute;\n    top: 6px;\n    left: 8px;\n    color: #CCCCCC;\n}\n\n.calendar-archives.arw-theme1 .postcount {\n    display: block;\n    color: #CCCCCC;\n}\n\n.calendar-archives.arw-theme1 .month.has-posts .postcount {\n    display: block;\n    color: #FFFFFF;\n}\n\n.calendar-archives.arw-theme1 .month.has-posts:hover .postcount {\n    color: #FFFFFF;\n}\n\n.calendar-archives.arw-theme1 .postcount {\n    position: absolute;\n    right: 6px;\n    bottom: 6px;\n    font-size: 14px;\n}\n\n.calendar-archives.arw-theme1 .postcount .number {\n    font-size: 9px;\n}\n\n.calendar-archives.arw-theme1 .postcount .count-text {\n    font-size: 9px;\n\n}\n\n.calendar-archives.arw-theme1 .day {\n    width: 14.285% !important;\n    height: 25px;\n    font-size: 14px;\n    line-height: 25px;\n    text-align: center;\n    font-weight: normal;\n}\n\n.calendar-archives.arw-theme1 .day.today {\n    border-bottom: 3px solid#f0ad4e;;\n}\n\n.calendar-archives.arw-theme1 .day.has-posts a {\n    height: 25px;\n    text-decoration: none;\n    font-weight: normal;\n}\n\n.calendar-archives.arw-theme1 .day.noday {\n    box-shadow: none;\n    background: none !important;\n    border-bottom: 1px #FFFFFF solid;\n    border-right: 1px #FFFFFF solid;\n}\n\n.calendar-archives.arw-theme1 .day.weekday {\n    display: inline-block;\n    padding: 0;\n    height: 22px;\n    line-height: 22px;\n    border: none;\n    font-size: 11px;\n    font-weight: normal;\n    color: #FFFFFF;\n    text-transform: uppercase;\n    box-shadow: none;\n    background: none !important;\n}\n\n.calendar-archives.arw-theme1 .week-row {\n    margin: 0;\n    padding: 0;\n    overflow: hidden;\n    background: #FFFFFF;\n}\n\n.calendar-archives.arw-theme1 .week-row.weekdays {\n    height: 22px;\n    line-height: 22px;\n    margin-bottom: 1px;\n    background-color: #7e7e7e;\n}\n";s:10:"arw-theme2";s:0:"";}', 'yes'),
(561, 'widget_archives_calendar', 'a:2:{i:2;a:11:{s:5:"title";s:8:"Archives";s:9:"next_text";s:4:"&gt;";s:9:"prev_text";s:4:"&lt;";s:10:"post_count";s:1:"1";s:10:"month_view";s:1:"0";s:12:"month_select";s:7:"default";s:18:"disable_title_link";i:0;s:15:"different_theme";i:0;s:5:"theme";s:6:"pastel";s:10:"categories";N;s:9:"post_type";a:1:{i:0;s:4:"post";}}s:12:"_multiwidget";i:1;}', 'yes'),
(587, '_site_transient_timeout_browser_f3140f372f37c9f4adddd0129a718eaa', '1481221759', 'no'),
(588, '_site_transient_browser_f3140f372f37c9f4adddd0129a718eaa', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"56.0.2924.10";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'no'),
(646, 'wpseo_sitemap_97_cache_validator', '5WeRT', 'no'),
(647, 'wpseo_sitemap_post_tag_cache_validator', '2F4Th', 'no'),
(665, 'wpseo_sitemap_114_cache_validator', '5YX7Z', 'no'),
(701, 'wpseo_sitemap_117_cache_validator', '64pFd', 'no'),
(717, 'wpseo_sitemap_120_cache_validator', '69zTF', 'no'),
(754, 'subscribe_reloaded_deferred_admin_notices', 'a:1:{s:25:"notify_update_new_install";a:4:{s:6:"status";s:4:"read";s:7:"message";s:911:"<p><strong>Thank you for installing Subscribe to Comments Reloaded!</strong>.</p><p>If you find a bug or an issue you can report it <a href="https://github.com/stcr/subscribe-to-comments-reloaded/issues" target="_blank">here</a>.</p><p>Please consider to make a donation to support the plugin, you can donate via <a href="\nhttps://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=XF86X93FDCGYA&lc=US&item_name=Datasoft%20Engineering&item_number=DI%2dSTCR&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_LG%2egif%3aNonHosted" target="_blank">PayPal</a>.</p><p>Please visit the <a href="https://wordpress.org/plugins/subscribe-to-comments-reloaded/changelog/" target="_blank">Changelog</a> for detailed information on plugin changes.<a class="dismiss" href="#">Dismiss.  </a><img class="stcr-loading-animation" src="http://localhost:81/wp_mahmuds_pachal/wp-admin//images/loading.gif" alt="Working..."></p>";s:4:"type";s:7:"updated";s:5:"nonce";i:0;}}', 'yes'),
(755, 'subscribe_reloaded_subscriber_table', 'yes', 'yes'),
(756, 'subscribe_reloaded_version', '160915', 'yes'),
(757, 'subscribe_reloaded_manager_page', '/comment-subscriptions/', 'yes'),
(758, 'subscribe_reloaded_unique_key', 'ec0e168f30bcbee131d2aab92f3472af', 'yes'),
(759, 'subscribe_reloaded_fresh_install', 'no', 'yes'),
(760, 'subscribe_reloaded_safely_uninstall', 'yes', 'yes'),
(761, 'subscribe_reloaded_stcr_position', 'no', 'yes'),
(762, 'subscribe_reloaded_reply_to', '', 'yes'),
(763, 'subscribe_reloaded_oneclick_text', '<p>Your are not longer subscribe to the post:</p>\r\n\r\n<h3>[post_title]</h3>\r\n<br>', 'yes'),
(764, 'subscribe_reloaded_data_sanitized', 'yes', 'yes'),
(765, 'subscribe_reloaded_show_subscription_box', 'yes', 'yes'),
(766, 'subscribe_reloaded_checked_by_default', 'no', 'yes'),
(767, 'subscribe_reloaded_enable_advanced_subscriptions', 'no', 'yes'),
(768, 'subscribe_reloaded_default_subscription_type', '2', 'yes'),
(769, 'subscribe_reloaded_checked_by_default_value', '0', 'yes'),
(770, 'subscribe_reloaded_checkbox_inline_style', 'width:30px', 'yes'),
(771, 'subscribe_reloaded_checkbox_html', '<p class=''comment-form-subscriptions''><label for=''subscribe-reloaded''>[checkbox_field] [checkbox_label]</label></p>', 'yes'),
(772, 'subscribe_reloaded_checkbox_label', 'Notify me of followup comments via e-mail. You can also <a href=''[subscribe_link]''>subscribe</a> without commenting.', 'yes'),
(773, 'subscribe_reloaded_subscribed_label', 'You are subscribed to this post. <a href=''[manager_link]''>Manage</a> your subscriptions.', 'yes'),
(774, 'subscribe_reloaded_subscribed_waiting_label', 'Your subscription to this post needs to be confirmed. <a href=''[manager_link]''>Manage your subscriptions</a>.', 'yes'),
(775, 'subscribe_reloaded_author_label', 'You can <a href=''[manager_link]''>manage the subscriptions</a> of this post.', 'yes'),
(776, 'subscribe_reloaded_manager_page_enabled', 'yes', 'yes'),
(777, 'subscribe_reloaded_virtual_manager_page_enabled', 'yes', 'yes');
INSERT INTO `tbl_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(778, 'subscribe_reloaded_manager_page_title', 'Manage subscriptions', 'yes'),
(779, 'subscribe_reloaded_custom_header_meta', '<meta name=''robots'' content=''noindex,nofollow''>', 'yes'),
(780, 'subscribe_reloaded_request_mgmt_link', 'To manage your subscriptions, please enter your email address here below. We will send you a message containing the link to access your personal management page.', 'yes'),
(781, 'subscribe_reloaded_request_mgmt_link_thankyou', 'Thank you for using our subscription service. Your request has been completed, and you should receive an email with the management link in a few minutes.', 'yes'),
(782, 'subscribe_reloaded_subscribe_without_commenting', 'You can follow the discussion on <strong>[post_title]</strong> without having to leave a comment. Cool, huh? Just enter your email address in the form here below and you''re all set.', 'yes'),
(783, 'subscribe_reloaded_subscription_confirmed', 'Thank you for using our subscription service. Your request has been completed. You will receive a notification email every time a new comment to this article is approved and posted by the administrator.', 'yes'),
(784, 'subscribe_reloaded_subscription_confirmed_dci', 'Thank you for using our subscription service. In order to confirm your request, please check your email for the verification message and follow the instructions.', 'yes'),
(785, 'subscribe_reloaded_author_text', 'In order to cancel or suspend one or more notifications, select the corresponding checkbox(es) and click on the button at the end of the list.', 'yes'),
(786, 'subscribe_reloaded_user_text', 'In order to cancel or suspend one or more notifications, select the corresponding checkbox(es) and click on the button at the end of the list. You are currently subscribed to:', 'yes'),
(787, 'subscribe_reloaded_from_name', 'M@hmud&#039;s Pachal', 'yes'),
(788, 'subscribe_reloaded_from_email', 'cse.mahmudul@gmail.com', 'yes'),
(789, 'subscribe_reloaded_notification_subject', 'There is a new comment to [post_title]', 'yes'),
(790, 'subscribe_reloaded_notification_content', 'There is a new comment to [post_title].\nComment Link: [comment_permalink]\nAuthor: [comment_author]\nComment:\n[comment_content]\nPermalink: [post_permalink]\nManage your subscriptions: [manager_link]', 'yes'),
(791, 'subscribe_reloaded_double_check_subject', 'Please confirm your subscription to [post_title]', 'yes'),
(792, 'subscribe_reloaded_double_check_content', 'You have requested to be notified every time a new comment is added to:\n[post_permalink]\n\nPlease confirm your request by clicking on this link:\n[confirm_link]', 'yes'),
(793, 'subscribe_reloaded_management_subject', 'Manage your subscriptions on [blog_name]', 'yes'),
(794, 'subscribe_reloaded_management_content', 'You have requested to manage your subscriptions to the articles on [blog_name]. Please check the Subscriptions management link in your email', 'yes'),
(795, 'subscribe_reloaded_management_email_content', 'You have requested to manage your subscriptions to the articles on [blog_name]. Follow this link to access your personal page:\n[manager_link]', 'yes'),
(796, 'subscribe_reloaded_purge_days', '30', 'yes'),
(797, 'subscribe_reloaded_enable_double_check', 'no', 'yes'),
(798, 'subscribe_reloaded_notify_authors', 'no', 'yes'),
(799, 'subscribe_reloaded_enable_html_emails', 'yes', 'yes'),
(800, 'subscribe_reloaded_htmlify_message_links', 'no', 'yes'),
(801, 'subscribe_reloaded_process_trackbacks', 'no', 'yes'),
(802, 'subscribe_reloaded_enable_admin_messages', 'no', 'yes'),
(803, 'subscribe_reloaded_admin_subscribe', 'no', 'yes'),
(804, 'subscribe_reloaded_admin_bcc', 'no', 'yes'),
(812, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1480702642;s:7:"checked";a:12:{s:19:"akismet/akismet.php";s:3:"3.2";s:43:"all-in-one-seo-pack/all_in_one_seo_pack.php";s:6:"2.3.11";s:46:"archives-calendar-widget/archives-calendar.php";s:6:"1.0.12";s:24:"buddypress/bp-loader.php";s:5:"2.7.2";s:26:"event-calendar-wd/ecwd.php";s:6:"1.0.77";s:9:"hello.php";s:3:"1.6";s:29:"nextgen-gallery/nggallery.php";s:6:"2.1.60";s:47:"sewn-in-template-log-in/sewn-template-login.php";s:5:"1.1.4";s:23:"slider-image/slider.php";s:6:"3.1.98";s:65:"subscribe-to-comments-reloaded/subscribe-to-comments-reloaded.php";s:6:"160915";s:33:"w3-total-cache/w3-total-cache.php";s:7:"0.9.5.1";s:24:"wordpress-seo/wp-seo.php";s:3:"3.9";}s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:12:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:3:"3.2";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:54:"https://downloads.wordpress.org/plugin/akismet.3.2.zip";}s:43:"all-in-one-seo-pack/all_in_one_seo_pack.php";O:8:"stdClass":6:{s:2:"id";s:3:"520";s:4:"slug";s:19:"all-in-one-seo-pack";s:6:"plugin";s:43:"all-in-one-seo-pack/all_in_one_seo_pack.php";s:11:"new_version";s:6:"2.3.11";s:3:"url";s:50:"https://wordpress.org/plugins/all-in-one-seo-pack/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/all-in-one-seo-pack.2.3.11.zip";}s:46:"archives-calendar-widget/archives-calendar.php";O:8:"stdClass":6:{s:2:"id";s:5:"40791";s:4:"slug";s:24:"archives-calendar-widget";s:6:"plugin";s:46:"archives-calendar-widget/archives-calendar.php";s:11:"new_version";s:6:"1.0.12";s:3:"url";s:55:"https://wordpress.org/plugins/archives-calendar-widget/";s:7:"package";s:74:"https://downloads.wordpress.org/plugin/archives-calendar-widget.1.0.12.zip";}s:24:"buddypress/bp-loader.php";O:8:"stdClass":7:{s:2:"id";s:4:"7756";s:4:"slug";s:10:"buddypress";s:6:"plugin";s:24:"buddypress/bp-loader.php";s:11:"new_version";s:5:"2.7.2";s:3:"url";s:41:"https://wordpress.org/plugins/buddypress/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/buddypress.2.7.2.zip";s:14:"upgrade_notice";s:57:"See: https://codex.buddypress.org/releases/version-2-7-2/";}s:26:"event-calendar-wd/ecwd.php";O:8:"stdClass":6:{s:2:"id";s:5:"61022";s:4:"slug";s:17:"event-calendar-wd";s:6:"plugin";s:26:"event-calendar-wd/ecwd.php";s:11:"new_version";s:6:"1.0.77";s:3:"url";s:48:"https://wordpress.org/plugins/event-calendar-wd/";s:7:"package";s:67:"https://downloads.wordpress.org/plugin/event-calendar-wd.1.0.77.zip";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}s:29:"nextgen-gallery/nggallery.php";O:8:"stdClass":6:{s:2:"id";s:3:"592";s:4:"slug";s:15:"nextgen-gallery";s:6:"plugin";s:29:"nextgen-gallery/nggallery.php";s:11:"new_version";s:6:"2.1.60";s:3:"url";s:46:"https://wordpress.org/plugins/nextgen-gallery/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/nextgen-gallery.2.1.60.zip";}s:47:"sewn-in-template-log-in/sewn-template-login.php";O:8:"stdClass":6:{s:2:"id";s:5:"61329";s:4:"slug";s:23:"sewn-in-template-log-in";s:6:"plugin";s:47:"sewn-in-template-log-in/sewn-template-login.php";s:11:"new_version";s:5:"1.1.4";s:3:"url";s:54:"https://wordpress.org/plugins/sewn-in-template-log-in/";s:7:"package";s:72:"https://downloads.wordpress.org/plugin/sewn-in-template-log-in.1.1.4.zip";}s:23:"slider-image/slider.php";O:8:"stdClass":6:{s:2:"id";s:5:"49075";s:4:"slug";s:12:"slider-image";s:6:"plugin";s:23:"slider-image/slider.php";s:11:"new_version";s:6:"3.1.98";s:3:"url";s:43:"https://wordpress.org/plugins/slider-image/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/slider-image.3.1.98.zip";}s:65:"subscribe-to-comments-reloaded/subscribe-to-comments-reloaded.php";O:8:"stdClass":6:{s:2:"id";s:5:"17608";s:4:"slug";s:30:"subscribe-to-comments-reloaded";s:6:"plugin";s:65:"subscribe-to-comments-reloaded/subscribe-to-comments-reloaded.php";s:11:"new_version";s:6:"160915";s:3:"url";s:61:"https://wordpress.org/plugins/subscribe-to-comments-reloaded/";s:7:"package";s:80:"https://downloads.wordpress.org/plugin/subscribe-to-comments-reloaded.160915.zip";}s:33:"w3-total-cache/w3-total-cache.php";O:8:"stdClass":6:{s:2:"id";s:4:"9376";s:4:"slug";s:14:"w3-total-cache";s:6:"plugin";s:33:"w3-total-cache/w3-total-cache.php";s:11:"new_version";s:7:"0.9.5.1";s:3:"url";s:45:"https://wordpress.org/plugins/w3-total-cache/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/w3-total-cache.0.9.5.1.zip";}s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":6:{s:2:"id";s:4:"5899";s:4:"slug";s:13:"wordpress-seo";s:6:"plugin";s:24:"wordpress-seo/wp-seo.php";s:11:"new_version";s:3:"3.9";s:3:"url";s:44:"https://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/wordpress-seo.3.9.zip";}}}', 'no'),
(813, 'w3tc_extensions_hooks', '{"actions":[],"filters":{"w3tc_notes":["w3tc_notes_wordpress_seo"]},"next_check_date":1480792356}', 'yes'),
(845, 'illegal_names', 'a:19:{i:0;s:3:"www";i:1;s:3:"web";i:2;s:4:"root";i:3;s:5:"admin";i:4;s:4:"main";i:5;s:6:"invite";i:6;s:13:"administrator";i:7;s:6:"groups";i:8;s:7:"members";i:9;s:6:"forums";i:10;s:5:"blogs";i:11;s:8:"activity";i:12;s:7:"profile";i:13;s:7:"friends";i:14;s:6:"search";i:15;s:8:"settings";i:16;s:13:"notifications";i:17;s:8:"register";i:18;s:8:"activate";}', 'no'),
(848, 'akismet_spam_count', '3', 'yes'),
(974, 'category_children', 'a:2:{i:24;a:2:{i:0;i:25;i:1;i:28;}i:26;a:2:{i:0;i:27;i:1;i:29;}}', 'yes'),
(1016, 'wpseo_sitemap_130_cache_validator', '2F4RW', 'no'),
(1121, '_site_transient_timeout_theme_roots', '1480704441', 'no'),
(1122, '_site_transient_theme_roots', 'a:4:{s:12:"blue-scenery";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:13:"twentysixteen";s:7:"/themes";}', 'no'),
(1123, '_site_transient_timeout_aioseop_update_check_time', '1480724270', 'no'),
(1124, '_site_transient_aioseop_update_check_time', '1480702670', 'no'),
(1191, '_transient_timeout_2__974818834', '1480707986', 'no'),
(1192, '_transient_2__974818834', '{"photocrati-ajax#ajax.min.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/ajax\\/static\\/ajax.min.js","photocrati-nextgen_admin#gritter\\/gritter.min.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_admin\\/static\\/gritter\\/gritter.min.js","photocrati-nextgen_admin#gritter\\/css\\/gritter.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_admin\\/static\\/gritter\\/css\\/gritter.min.css","photocrati-nextgen_admin#ngg_progressbar.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_admin\\/static\\/ngg_progressbar.min.js","photocrati-nextgen_admin#ngg_progressbar.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_admin\\/static\\/ngg_progressbar.min.css","photocrati-nextgen_admin#select2\\/select2.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_admin\\/static\\/select2\\/select2.min.css","photocrati-nextgen_admin#select2\\/select2.modded.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_admin\\/static\\/select2\\/select2.modded.min.js","photocrati-nextgen_admin#jquery.nextgen_radio_toggle.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_admin\\/static\\/jquery.nextgen_radio_toggle.min.js","photocrati-nextgen_admin#jquery-ui\\/jquery-ui-1.10.4.custom.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_admin\\/static\\/jquery-ui\\/jquery-ui-1.10.4.custom.min.css","photocrati-frame_communication#frame_event_publisher.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/frame_communication\\/static\\/frame_event_publisher.min.js","photocrati-nextgen_gallery_display#nextgen_gallery_display_settings.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_gallery_display\\/static\\/nextgen_gallery_display_settings.min.js","photocrati-nextgen_gallery_display#nextgen_gallery_display_settings.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_gallery_display\\/static\\/nextgen_gallery_display_settings.min.css","photocrati-nextgen_gallery_display#nextgen_gallery_related_images.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_gallery_display\\/static\\/nextgen_gallery_related_images.min.css","photocrati-nextgen_gallery_display#common.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_gallery_display\\/static\\/common.min.js","photocrati-nextgen_gallery_display#trigger_buttons.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_gallery_display\\/static\\/trigger_buttons.min.css","photocrati-nextgen_gallery_display#fontawesome\\/font-awesome.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_gallery_display\\/static\\/fontawesome\\/font-awesome.min.css","photocrati-attach_to_post#ngg_attach_to_post_tinymce_plugin.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/attach_to_post\\/static\\/ngg_attach_to_post_tinymce_plugin.min.css","photocrati-nextgen_addgallery_page#browserplus-2.4.21.min.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/browserplus-2.4.21.min.js","photocrati-nextgen_addgallery_page#plupload-2.1.1\\/moxie.min.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/plupload-2.1.1\\/moxie.min.js","photocrati-nextgen_addgallery_page#plupload-2.1.1\\/plupload.dev.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/plupload-2.1.1\\/plupload.dev.min.js","photocrati-nextgen_addgallery_page#plupload-2.1.1\\/jquery.plupload.queue\\/jquery.plupload.queue.min.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/plupload-2.1.1\\/jquery.plupload.queue\\/jquery.plupload.queue.min.js","photocrati-nextgen_addgallery_page#plupload-2.1.1\\/jquery.plupload.queue\\/css\\/jquery.plupload.queue.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/plupload-2.1.1\\/jquery.plupload.queue\\/css\\/jquery.plupload.queue.min.css","photocrati-nextgen_addgallery_page#styles.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/styles.min.css","photocrati-nextgen_addgallery_page#jquery.filetree\\/jquery.filetree.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/jquery.filetree\\/jquery.filetree.min.js","photocrati-nextgen_addgallery_page#jquery.filetree\\/jquery.filetree.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/jquery.filetree\\/jquery.filetree.min.css","photocrati-nextgen_addgallery_page#media-library-import.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/media-library-import.min.js","photocrati-nextgen_addgallery_page#media-library-import.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_addgallery_page\\/static\\/media-library-import.min.css","photocrati-nextgen_basic_gallery#slideshow\\/jquery.cycle.all.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_basic_gallery\\/static\\/slideshow\\/jquery.cycle.all.min.js","photocrati-nextgen_basic_gallery#slideshow\\/nextgen_basic_slideshow.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_basic_gallery\\/static\\/slideshow\\/nextgen_basic_slideshow.min.css","photocrati-nextgen_basic_gallery#slideshow\\/jquery.waitforimages.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_basic_gallery\\/static\\/slideshow\\/jquery.waitforimages.min.js","photocrati-nextgen_basic_gallery#slideshow\\/nextgen_basic_slideshow.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_basic_gallery\\/static\\/slideshow\\/nextgen_basic_slideshow.min.js","photocrati-lightbox#lightbox_context.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/lightbox\\/static\\/lightbox_context.min.js","|photocrati-lightbox|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/lightbox\\/static","photocrati-lightbox#fancybox\\/jquery.fancybox-1.3.4.css||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/lightbox\\/static\\/fancybox\\/jquery.fancybox-1.3.4.min.css","photocrati-lightbox#fancybox\\/jquery.easing-1.3.pack.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/lightbox\\/static\\/fancybox\\/jquery.easing-1.3.pack.js","photocrati-lightbox#fancybox\\/jquery.fancybox-1.3.4.pack.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/lightbox\\/static\\/fancybox\\/jquery.fancybox-1.3.4.pack.js","photocrati-lightbox#fancybox\\/nextgen_fancybox_init.js||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/lightbox\\/static\\/fancybox\\/nextgen_fancybox_init.min.js","photocrati-nextgen_basic_gallery#slideshow\\/placeholder.gif||http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/mu-plugins|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery|http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/themes\\/blue-scenery":"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_basic_gallery\\/static\\/slideshow\\/placeholder.gif"}', 'no'),
(1193, '_transient_timeout_2__536483053', '1480707839', 'no'),
(1194, '_transient_2__536483053', '{"photocrati-nextgen_basic_gallery#slideshow\\/jquery.cycle.all.js|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\nextgen_basic_gallery\\\\static\\\\slideshow\\\\jquery.cycle.all.min.js","photocrati-nextgen_basic_gallery#slideshow\\/nextgen_basic_slideshow.css|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\nextgen_basic_gallery\\\\static\\\\slideshow\\\\nextgen_basic_slideshow.min.css","photocrati-nextgen_basic_gallery#slideshow\\/jquery.waitforimages.js|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\nextgen_basic_gallery\\\\static\\\\slideshow\\\\jquery.waitforimages.min.js","photocrati-nextgen_basic_gallery#slideshow\\/nextgen_basic_slideshow.js|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\nextgen_basic_gallery\\\\static\\\\slideshow\\\\nextgen_basic_slideshow.min.js","photocrati-lightbox#lightbox_context.js|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\lightbox\\\\static\\\\lightbox_context.min.js","|photocrati-lightbox|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\lightbox\\\\static","photocrati-lightbox#fancybox\\/jquery.fancybox-1.3.4.css|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\lightbox\\\\static\\\\fancybox\\\\jquery.fancybox-1.3.4.min.css","photocrati-lightbox#fancybox\\/jquery.easing-1.3.pack.js|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\lightbox\\\\static\\\\fancybox\\\\jquery.easing-1.3.pack.js","photocrati-lightbox#fancybox\\/jquery.fancybox-1.3.4.pack.js|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\lightbox\\\\static\\\\fancybox\\\\jquery.fancybox-1.3.4.pack.js","photocrati-lightbox#fancybox\\/nextgen_fancybox_init.js|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\lightbox\\\\static\\\\fancybox\\\\nextgen_fancybox_init.min.js","photocrati-nextgen_basic_gallery#slideshow\\/placeholder.gif|1":"G:\\\\XAMPP_Software\\\\htdocs\\\\wp_mahmuds_pachal\\\\wp-content\\\\plugins\\\\nextgen-gallery\\\\products\\\\photocrati_nextgen\\\\modules\\\\nextgen_basic_gallery\\\\static\\\\slideshow\\\\placeholder.gif"}', 'no'),
(1195, '_transient_timeout_w3tc.verify_plugins', '1481310600', 'no'),
(1196, '_transient_w3tc.verify_plugins', '1', 'no'),
(1197, '_transient_timeout_wpseo-dashboard-totals', '1480792356', 'no'),
(1198, '_transient_wpseo-dashboard-totals', 'a:4:{i:1;a:3:{i:0;a:5:{s:8:"seo_rank";s:3:"bad";s:5:"title";s:24:"Posts with bad SEO score";s:5:"class";s:16:"wpseo-glance-bad";s:10:"icon_class";s:3:"bad";s:5:"count";s:1:"2";}i:1;a:5:{s:8:"seo_rank";s:2:"ok";s:5:"title";s:23:"Posts with OK SEO score";s:5:"class";s:15:"wpseo-glance-ok";s:10:"icon_class";s:2:"ok";s:5:"count";s:1:"3";}i:3;a:5:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Posts without focus keyword";s:5:"class";s:15:"wpseo-glance-na";s:10:"icon_class";s:2:"na";s:5:"count";s:1:"1";}}i:4;a:3:{i:0;a:5:{s:8:"seo_rank";s:3:"bad";s:5:"title";s:24:"Posts with bad SEO score";s:5:"class";s:16:"wpseo-glance-bad";s:10:"icon_class";s:3:"bad";s:5:"count";s:1:"2";}i:1;a:5:{s:8:"seo_rank";s:2:"ok";s:5:"title";s:23:"Posts with OK SEO score";s:5:"class";s:15:"wpseo-glance-ok";s:10:"icon_class";s:2:"ok";s:5:"count";s:1:"3";}i:3;a:5:{s:8:"seo_rank";s:2:"na";s:5:"title";s:27:"Posts without focus keyword";s:5:"class";s:15:"wpseo-glance-na";s:10:"icon_class";s:2:"na";s:5:"count";s:1:"1";}}i:3;a:1:{i:1;a:5:{s:8:"seo_rank";s:2:"ok";s:5:"title";s:23:"Posts with OK SEO score";s:5:"class";s:15:"wpseo-glance-ok";s:10:"icon_class";s:2:"ok";s:5:"count";s:1:"1";}}i:2;a:1:{i:0;a:5:{s:8:"seo_rank";s:3:"bad";s:5:"title";s:24:"Posts with bad SEO score";s:5:"class";s:16:"wpseo-glance-bad";s:10:"icon_class";s:3:"bad";s:5:"count";s:1:"1";}}}', 'no'),
(1199, '_transient_timeout_plugin_slugs', '1480792203', 'no'),
(1200, '_transient_plugin_slugs', 'a:12:{i:0;s:19:"akismet/akismet.php";i:1;s:43:"all-in-one-seo-pack/all_in_one_seo_pack.php";i:2;s:46:"archives-calendar-widget/archives-calendar.php";i:3;s:24:"buddypress/bp-loader.php";i:4;s:26:"event-calendar-wd/ecwd.php";i:5;s:9:"hello.php";i:6;s:29:"nextgen-gallery/nggallery.php";i:7;s:47:"sewn-in-template-log-in/sewn-template-login.php";i:8;s:23:"slider-image/slider.php";i:9;s:65:"subscribe-to-comments-reloaded/subscribe-to-comments-reloaded.php";i:10;s:33:"w3-total-cache/w3-total-cache.php";i:11;s:24:"wordpress-seo/wp-seo.php";}', 'no'),
(1201, '_transient_timeout_dash_88ae138922fe95674369b1cb3d215a2b', '1480749003', 'no'),
(1202, '_transient_dash_88ae138922fe95674369b1cb3d215a2b', '<div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: cURL error 6: Could not resolve host: wordpress.org</p></div><div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: cURL error 6: Could not resolve host: planet.wordpress.org</p></div><div class="rss-widget"><ul></ul></div>', 'no'),
(1203, '_transient_timeout_3___1395736393', '1480707838', 'no'),
(1204, '_transient_3___1395736393', '["ID","post_author","post_date","post_date_gmt","post_content","post_title","post_excerpt","post_status","comment_status","ping_status","post_password","post_name","to_ping","pinged","post_modified","post_modified_gmt","post_content_filtered","post_parent","guid","menu_order","post_type","post_mime_type","comment_count"]', 'no'),
(1205, '_transient_timeout_5___1395736393', '1480707838', 'no'),
(1206, '_transient_5___1395736393', '["pid","image_slug","post_id","galleryid","filename","description","alttext","imagedate","exclude","sortorder","meta_data","extras_post_id","updated_at"]', 'no'),
(1207, '_transient_timeout_4___1395736393', '1480707838', 'no'),
(1208, '_transient_4___1395736393', '["gid","name","slug","path","title","galdesc","pageid","previewpic","author","extras_post_id"]', 'no'),
(1209, '_transient_timeout_6__451327698', '1480707838', 'no'),
(1210, '_transient_6__451327698', '"\\n\\t<!-- Thumbnails Link -->\\n\\t<div class=\\"slideshowlink\\">\\n        <a href=''http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/nggallery\\/thumbnails''>&#091;Show thumbnails&#093;<\\/a>\\n\\t<\\/div>\\n\\n<div class=\\"ngg-slideshow-image-list ngg-slideshow-nojs\\" id=\\"ngg-slideshow-5d66dd06c698498aae753a47b24f7de0-227850-image-list\\">\\n\\t<div id=\\"ngg-image-0\\" class=\\"ngg-gallery-slideshow-image\\" >\\n\\t\\t<img data-image-id=''1''\\n\\t\\t     title=\\"\\"\\n\\t\\t     alt=\\"13662028_1109900409055524_5232681174920285749_o\\"\\n\\t\\t     src=\\"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/gallery\\/my_images\\/13662028_1109900409055524_5232681174920285749_o.jpg\\"\\n\\t\\t     width=\\"400\\"\\n\\t\\t     height=\\"400\\"\\/>\\n\\t\\t<\\/div> \\n<div id=\\"ngg-image-1\\" class=\\"ngg-gallery-slideshow-image\\" >\\n\\t\\t<img data-image-id=''2''\\n\\t\\t     title=\\"\\"\\n\\t\\t     alt=\\"13680665_1109900405722191_2777831404448902692_n\\"\\n\\t\\t     src=\\"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/gallery\\/my_images\\/13680665_1109900405722191_2777831404448902692_n.jpg\\"\\n\\t\\t     width=\\"400\\"\\n\\t\\t     height=\\"400\\"\\/>\\n\\t\\t<\\/div> \\n<div id=\\"ngg-image-2\\" class=\\"ngg-gallery-slideshow-image\\" >\\n\\t\\t<img data-image-id=''3''\\n\\t\\t     title=\\"\\"\\n\\t\\t     alt=\\"13697997_1109900402388858_7743577443761806408_o\\"\\n\\t\\t     src=\\"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/gallery\\/my_images\\/13697997_1109900402388858_7743577443761806408_o.jpg\\"\\n\\t\\t     width=\\"400\\"\\n\\t\\t     height=\\"400\\"\\/>\\n\\t\\t<\\/div> \\n<div id=\\"ngg-image-3\\" class=\\"ngg-gallery-slideshow-image\\" >\\n\\t\\t<img data-image-id=''4''\\n\\t\\t     title=\\"\\"\\n\\t\\t     alt=\\"13767410_1109900399055525_2705110579242990808_o\\"\\n\\t\\t     src=\\"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/gallery\\/my_images\\/13767410_1109900399055525_2705110579242990808_o.jpg\\"\\n\\t\\t     width=\\"400\\"\\n\\t\\t     height=\\"400\\"\\/>\\n\\t\\t<\\/div> \\n<div id=\\"ngg-image-4\\" class=\\"ngg-gallery-slideshow-image\\" >\\n\\t\\t<img data-image-id=''5''\\n\\t\\t     title=\\"\\"\\n\\t\\t     alt=\\"13872769_1109900412388857_897054101226765220_n\\"\\n\\t\\t     src=\\"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/gallery\\/my_images\\/13872769_1109900412388857_897054101226765220_n.jpg\\"\\n\\t\\t     width=\\"400\\"\\n\\t\\t     height=\\"400\\"\\/>\\n\\t\\t<\\/div> \\n<\\/div>\\n<div class=\\"ngg-galleryoverview ngg-slideshow\\"\\n     id=\\"ngg-slideshow-5d66dd06c698498aae753a47b24f7de0-227850\\"\\n     data-placeholder=\\"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/nextgen_basic_gallery\\/static\\/slideshow\\/placeholder.gif\\"\\n     style=\\"max-width: 600px; max-height: 400px;\\">\\n\\t<div class=\\"ngg-slideshow-loader\\"\\n\\t     id=\\"ngg-slideshow-5d66dd06c698498aae753a47b24f7de0-227850-loader\\"\\n\\t     style=\\"width: 600px; height: 400px;\\">\\n\\t\\t<img src=\\"http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/wp-content\\/plugins\\/nextgen-gallery\\/products\\/photocrati_nextgen\\/modules\\/ngglegacy\\/images\\/loader.gif\\" alt=\\"\\"\\/>\\n\\t<\\/div>\\n<\\/div>\\n<script type=\\"text\\/javascript\\">\\n\\tjQuery(''#ngg-slideshow-5d66dd06c698498aae753a47b24f7de0-227850-image-list'').hide().removeClass(''ngg-slideshow-nojs'');\\n\\tjQuery(function($) {\\n\\t\\tjQuery(''#ngg-slideshow-5d66dd06c698498aae753a47b24f7de0-227850'').nggShowSlideshow({\\n\\t\\t\\tid: ''5d66dd06c698498aae753a47b24f7de0'',\\n\\t\\t\\tfx: ''fade'',\\n\\t\\t\\twidth: 600,\\n\\t\\t\\theight: 400,\\n\\t\\t\\tdomain: ''http:\\/\\/localhost:81\\/wp_mahmuds_pachal\\/'',\\n\\t\\t\\ttimeout: 10000\\t\\t});\\n\\t});\\n<\\/script>\\n"', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_postmeta`
--

CREATE TABLE IF NOT EXISTS `tbl_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=559 ;

--
-- Dumping data for table `tbl_postmeta`
--

INSERT INTO `tbl_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_wp_attached_file', '2016/12/Linea_M_Logo_Metro_de_Medellin.svg_.png'),
(3, 4, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:47:"2016/12/Linea_M_Logo_Metro_de_Medellin.svg_.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"Linea_M_Logo_Metro_de_Medellin.svg_-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:47:"Linea_M_Logo_Metro_de_Medellin.svg_-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:47:"Linea_M_Logo_Metro_de_Medellin.svg_-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:49:"Linea_M_Logo_Metro_de_Medellin.svg_-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:24:"blue_scenery_slider_size";a:4:{s:4:"file";s:48:"Linea_M_Logo_Metro_de_Medellin.svg_-2000x700.png";s:5:"width";i:2000;s:6:"height";i:700;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(4, 4, '_wp_attachment_image_alt', 'Mahmud'),
(5, 5, '_wp_attached_file', '2016/12/cropped-Linea_M_Logo_Metro_de_Medellin.svg_.png'),
(6, 5, '_wp_attachment_context', 'site-icon'),
(7, 5, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:55:"2016/12/cropped-Linea_M_Logo_Metro_de_Medellin.svg_.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:55:"cropped-Linea_M_Logo_Metro_de_Medellin.svg_-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:55:"cropped-Linea_M_Logo_Metro_de_Medellin.svg_-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-270";a:4:{s:4:"file";s:55:"cropped-Linea_M_Logo_Metro_de_Medellin.svg_-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-192";a:4:{s:4:"file";s:55:"cropped-Linea_M_Logo_Metro_de_Medellin.svg_-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-180";a:4:{s:4:"file";s:55:"cropped-Linea_M_Logo_Metro_de_Medellin.svg_-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-32";a:4:{s:4:"file";s:53:"cropped-Linea_M_Logo_Metro_de_Medellin.svg_-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(8, 6, '_wp_attached_file', '2016/12/Follow-your-herat-chase-your-dreams.png'),
(9, 6, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:851;s:6:"height";i:315;s:4:"file";s:47:"2016/12/Follow-your-herat-chase-your-dreams.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"Follow-your-herat-chase-your-dreams-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:47:"Follow-your-herat-chase-your-dreams-300x111.png";s:5:"width";i:300;s:6:"height";i:111;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:47:"Follow-your-herat-chase-your-dreams-768x284.png";s:5:"width";i:768;s:6:"height";i:284;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(10, 6, '_wp_attachment_image_alt', 'Follow Your Heart, Chase Your Dream'),
(11, 7, '_wp_attached_file', '2016/12/fb_MHKDhoom3_image.jpg'),
(12, 7, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:850;s:6:"height";i:314;s:4:"file";s:30:"2016/12/fb_MHKDhoom3_image.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"fb_MHKDhoom3_image-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"fb_MHKDhoom3_image-300x111.jpg";s:5:"width";i:300;s:6:"height";i:111;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:30:"fb_MHKDhoom3_image-768x284.jpg";s:5:"width";i:768;s:6:"height";i:284;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(13, 7, '_wp_attachment_image_alt', 'Mahmud Dhoom 3'),
(14, 8, '_wp_attached_file', '2016/12/100167.gif'),
(15, 8, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:550;s:6:"height";i:300;s:4:"file";s:18:"2016/12/100167.gif";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"100167-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:18:"100167-300x164.gif";s:5:"width";i:300;s:6:"height";i:164;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(16, 8, '_wp_attachment_image_alt', ''),
(17, 9, '_wp_attached_file', '2016/12/1468618_1378334399081666_1667513437_n.jpg'),
(18, 9, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:360;s:4:"file";s:49:"2016/12/1468618_1378334399081666_1667513437_n.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:49:"1468618_1378334399081666_1667513437_n-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:49:"1468618_1378334399081666_1667513437_n-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(19, 9, '_wp_attachment_image_alt', 'Looking for Love'),
(20, 12, '_menu_item_type', 'post_type'),
(21, 12, '_menu_item_menu_item_parent', '77'),
(22, 12, '_menu_item_object_id', '10'),
(23, 12, '_menu_item_object', 'page'),
(24, 12, '_menu_item_target', ''),
(25, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(26, 12, '_menu_item_xfn', ''),
(27, 12, '_menu_item_url', ''),
(28, 13, '_menu_item_type', 'post_type'),
(29, 13, '_menu_item_menu_item_parent', '77'),
(30, 13, '_menu_item_object_id', '11'),
(31, 13, '_menu_item_object', 'page'),
(32, 13, '_menu_item_target', ''),
(33, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(34, 13, '_menu_item_xfn', ''),
(35, 13, '_menu_item_url', ''),
(36, 47, '_menu_item_type', 'post_type'),
(37, 47, '_menu_item_menu_item_parent', '77'),
(38, 47, '_menu_item_object_id', '46'),
(39, 47, '_menu_item_object', 'page'),
(40, 47, '_menu_item_target', ''),
(41, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(42, 47, '_menu_item_xfn', ''),
(43, 47, '_menu_item_url', ''),
(44, 48, 'title', 'NextGEN Basic Thumbnails'),
(45, 48, 'preview_image_relpath', '\\nextgen-gallery\\products\\photocrati_nextgen\\modules\\nextgen_basic_gallery\\static\\thumb_preview.jpg'),
(46, 48, 'default_source', 'galleries'),
(47, 48, 'view_order', '10000'),
(48, 48, 'name', 'photocrati-nextgen_basic_thumbnails'),
(49, 48, 'installed_at_version', '2.1.60'),
(50, 48, 'hidden_from_ui', ''),
(51, 48, 'hidden_from_igw', ''),
(52, 48, '__defaults_set', '1'),
(53, 48, 'filter', 'raw'),
(54, 48, 'entity_types', 'WyJpbWFnZSJd'),
(55, 48, 'aliases', 'WyJiYXNpY190aHVtYm5haWwiLCJiYXNpY190aHVtYm5haWxzIiwibmV4dGdlbl9iYXNpY190aHVtYm5haWxzIl0='),
(56, 48, 'id_field', 'ID'),
(57, 48, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJpbWFnZXNfcGVyX3BhZ2UiOiIyMCIsIm51bWJlcl9vZl9jb2x1bW5zIjowLCJ0aHVtYm5haWxfd2lkdGgiOjI0MCwidGh1bWJuYWlsX2hlaWdodCI6MTYwLCJzaG93X2FsbF9pbl9saWdodGJveCI6MCwiYWpheF9wYWdpbmF0aW9uIjowLCJ1c2VfaW1hZ2Vicm93c2VyX2VmZmVjdCI6MCwidGVtcGxhdGUiOiIiLCJkaXNwbGF5X25vX2ltYWdlc19lcnJvciI6MSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJzaG93X3NsaWRlc2hvd19saW5rIjoxLCJzbGlkZXNob3dfbGlua190ZXh0IjoiW1Nob3cgc2xpZGVzaG93XSIsIm92ZXJyaWRlX3RodW1ibmFpbF9zZXR0aW5ncyI6MCwidGh1bWJuYWlsX3F1YWxpdHkiOiIxMDAiLCJ0aHVtYm5haWxfY3JvcCI6MSwidGh1bWJuYWlsX3dhdGVybWFyayI6MCwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciJ9'),
(58, 49, 'title', 'NextGEN Basic Slideshow'),
(59, 49, 'preview_image_relpath', '\\nextgen-gallery\\products\\photocrati_nextgen\\modules\\nextgen_basic_gallery\\static\\slideshow_preview.jpg'),
(60, 49, 'default_source', 'galleries'),
(61, 49, 'view_order', '10010'),
(62, 49, 'name', 'photocrati-nextgen_basic_slideshow'),
(63, 49, 'installed_at_version', '2.1.60'),
(64, 49, 'hidden_from_ui', ''),
(65, 49, 'hidden_from_igw', ''),
(66, 49, '__defaults_set', '1'),
(67, 49, 'filter', 'raw'),
(68, 49, 'entity_types', 'WyJpbWFnZSJd'),
(69, 49, 'aliases', 'WyJiYXNpY19zbGlkZXNob3ciLCJuZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyJd'),
(70, 49, 'id_field', 'ID'),
(71, 49, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJ5X3dpZHRoIjo2MDAsImdhbGxlcnlfaGVpZ2h0Ijo0MDAsInRodW1ibmFpbF93aWR0aCI6MjQwLCJ0aHVtYm5haWxfaGVpZ2h0IjoxNjAsImN5Y2xlX2ludGVydmFsIjoxMCwiY3ljbGVfZWZmZWN0IjoiZmFkZSIsImVmZmVjdF9jb2RlIjoiY2xhc3M9XCJuZ2ctZmFuY3lib3hcIiByZWw9XCIlR0FMTEVSWV9OQU1FJVwiIiwic2hvd190aHVtYm5haWxfbGluayI6MSwidGh1bWJuYWlsX2xpbmtfdGV4dCI6IltTaG93IHRodW1ibmFpbHNdIiwidGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0='),
(72, 50, 'title', 'NextGEN Basic ImageBrowser'),
(73, 50, 'preview_image_relpath', '\\nextgen-gallery\\products\\photocrati_nextgen\\modules\\nextgen_basic_imagebrowser\\static\\preview.jpg'),
(74, 50, 'default_source', 'galleries'),
(75, 50, 'view_order', '10020'),
(76, 50, 'name', 'photocrati-nextgen_basic_imagebrowser'),
(77, 50, 'installed_at_version', '2.1.60'),
(78, 50, 'hidden_from_ui', ''),
(79, 50, 'hidden_from_igw', ''),
(80, 50, '__defaults_set', '1'),
(81, 50, 'filter', 'raw'),
(82, 50, 'entity_types', 'WyJpbWFnZSJd'),
(83, 50, 'aliases', 'WyJiYXNpY19pbWFnZWJyb3dzZXIiLCJpbWFnZWJyb3dzZXIiLCJuZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3NlciJd'),
(84, 50, 'id_field', 'ID'),
(85, 50, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ0ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifQ=='),
(86, 51, 'title', 'NextGEN Basic SinglePic'),
(87, 51, 'preview_image_relpath', '\\nextgen-gallery\\products\\photocrati_nextgen\\modules\\nextgen_basic_singlepic\\static\\preview.gif'),
(88, 51, 'default_source', 'galleries'),
(89, 51, 'view_order', '10060'),
(90, 51, 'hidden_from_ui', '1'),
(91, 51, 'hidden_from_igw', '1'),
(92, 51, 'name', 'photocrati-nextgen_basic_singlepic'),
(93, 51, 'installed_at_version', '2.1.60'),
(94, 51, '__defaults_set', '1'),
(95, 51, 'filter', 'raw'),
(96, 51, 'entity_types', 'WyJpbWFnZSJd'),
(97, 51, 'aliases', 'WyJiYXNpY19zaW5nbGVwaWMiLCJzaW5nbGVwaWMiLCJuZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyJd'),
(98, 51, 'id_field', 'ID'),
(99, 51, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ3aWR0aCI6IiIsImhlaWdodCI6IiIsIm1vZGUiOiIiLCJkaXNwbGF5X3dhdGVybWFyayI6MCwiZGlzcGxheV9yZWZsZWN0aW9uIjowLCJmbG9hdCI6IiIsImxpbmsiOiIiLCJsaW5rX3RhcmdldCI6Il9ibGFuayIsInF1YWxpdHkiOjEwMCwiY3JvcCI6MCwidGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0='),
(100, 52, 'title', 'NextGEN Basic TagCloud'),
(101, 52, 'preview_image_relpath', '\\nextgen-gallery\\products\\photocrati_nextgen\\modules\\nextgen_basic_tagcloud\\static\\preview.gif'),
(102, 52, 'default_source', 'tags'),
(103, 52, 'view_order', '10100'),
(104, 52, 'name', 'photocrati-nextgen_basic_tagcloud'),
(105, 52, 'installed_at_version', '2.1.60'),
(106, 52, 'hidden_from_ui', ''),
(107, 52, 'hidden_from_igw', ''),
(108, 52, '__defaults_set', '1'),
(109, 52, 'filter', 'raw'),
(110, 52, 'entity_types', 'WyJpbWFnZSJd'),
(111, 52, 'aliases', 'WyJiYXNpY190YWdjbG91ZCIsInRhZ2Nsb3VkIiwibmV4dGdlbl9iYXNpY190YWdjbG91ZCJd'),
(112, 52, 'id_field', 'ID'),
(113, 52, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwibnVtYmVyIjo0NSwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciJ9'),
(114, 53, 'title', 'NextGEN Basic Compact Album'),
(115, 53, 'preview_image_relpath', '\\nextgen-gallery\\products\\photocrati_nextgen\\modules\\nextgen_basic_album\\static\\compact_preview.jpg'),
(116, 53, 'default_source', 'albums'),
(117, 53, 'view_order', '10200'),
(118, 53, 'name', 'photocrati-nextgen_basic_compact_album'),
(119, 53, 'installed_at_version', '2.1.60'),
(120, 53, 'hidden_from_ui', ''),
(121, 53, 'hidden_from_igw', ''),
(122, 53, '__defaults_set', '1'),
(123, 53, 'filter', 'raw'),
(124, 53, 'entity_types', 'WyJhbGJ1bSIsImdhbGxlcnkiXQ=='),
(125, 53, 'aliases', 'WyJiYXNpY19jb21wYWN0X2FsYnVtIiwibmV4dGdlbl9iYXNpY19hbGJ1bSIsImJhc2ljX2FsYnVtX2NvbXBhY3QiLCJjb21wYWN0X2FsYnVtIl0='),
(126, 53, 'id_field', 'ID'),
(127, 53, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOjAsImVuYWJsZV9icmVhZGNydW1icyI6MSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJlbmFibGVfZGVzY3JpcHRpb25zIjowLCJ0ZW1wbGF0ZSI6IiIsIm9wZW5fZ2FsbGVyeV9pbl9saWdodGJveCI6MCwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifQ=='),
(128, 54, 'title', 'NextGEN Basic Extended Album'),
(129, 54, 'preview_image_relpath', '\\nextgen-gallery\\products\\photocrati_nextgen\\modules\\nextgen_basic_album\\static\\extended_preview.jpg'),
(130, 54, 'default_source', 'albums'),
(131, 54, 'view_order', '10210'),
(132, 54, 'name', 'photocrati-nextgen_basic_extended_album'),
(133, 54, 'installed_at_version', '2.1.60'),
(134, 54, 'hidden_from_ui', ''),
(135, 54, 'hidden_from_igw', ''),
(136, 54, '__defaults_set', '1'),
(137, 54, 'filter', 'raw'),
(138, 54, 'entity_types', 'WyJhbGJ1bSIsImdhbGxlcnkiXQ=='),
(139, 54, 'aliases', 'WyJiYXNpY19leHRlbmRlZF9hbGJ1bSIsIm5leHRnZW5fYmFzaWNfZXh0ZW5kZWRfYWxidW0iLCJleHRlbmRlZF9hbGJ1bSJd'),
(140, 54, 'id_field', 'ID'),
(141, 54, 'settings', 'eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOjAsImVuYWJsZV9icmVhZGNydW1icyI6MSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJlbmFibGVfZGVzY3JpcHRpb25zIjowLCJ0ZW1wbGF0ZSI6IiIsIm9wZW5fZ2FsbGVyeV9pbl9saWdodGJveCI6MCwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjowLCJ0aHVtYm5haWxfd2lkdGgiOjI0MCwidGh1bWJuYWlsX2hlaWdodCI6MTYwLCJ0aHVtYm5haWxfcXVhbGl0eSI6MTAwLCJ0aHVtYm5haWxfY3JvcCI6dHJ1ZSwidGh1bWJuYWlsX3dhdGVybWFyayI6MCwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifQ=='),
(142, 55, '__defaults_set', '1'),
(143, 55, 'filter', 'raw'),
(144, 55, 'id_field', 'ID'),
(145, 56, '__defaults_set', '1'),
(146, 56, 'filter', 'raw'),
(147, 56, 'id_field', 'ID'),
(151, 57, '__defaults_set', '1'),
(152, 57, 'filter', 'raw'),
(153, 57, 'id_field', 'ID'),
(154, 58, '__defaults_set', '1'),
(155, 58, 'filter', 'raw'),
(156, 58, 'id_field', 'ID'),
(157, 59, '__defaults_set', '1'),
(158, 59, 'filter', 'raw'),
(159, 59, 'id_field', 'ID'),
(163, 60, '__defaults_set', '1'),
(164, 60, 'filter', 'raw'),
(165, 60, 'id_field', 'ID'),
(166, 61, '__defaults_set', '1'),
(167, 61, 'filter', 'raw'),
(168, 61, 'id_field', 'ID'),
(172, 62, '__defaults_set', '1'),
(173, 62, 'filter', 'raw'),
(174, 62, 'id_field', 'ID'),
(175, 63, '__defaults_set', '1'),
(176, 63, 'filter', 'raw'),
(177, 63, 'id_field', 'ID'),
(181, 64, '__defaults_set', '1'),
(182, 64, 'filter', 'raw'),
(183, 64, 'id_field', 'ID'),
(184, 65, '__defaults_set', '1'),
(185, 65, 'filter', 'raw'),
(186, 65, 'id_field', 'ID'),
(190, 66, '__defaults_set', '1'),
(191, 66, 'filter', 'raw'),
(192, 66, 'id_field', 'ID'),
(193, 67, '_wp_attached_file', '2016/12/13662028_1109900409055524_5232681174920285749_o.jpg'),
(194, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1152;s:6:"height";i:1152;s:4:"file";s:59:"2016/12/13662028_1109900409055524_5232681174920285749_o.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:59:"13662028_1109900409055524_5232681174920285749_o-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:59:"13662028_1109900409055524_5232681174920285749_o-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:59:"13662028_1109900409055524_5232681174920285749_o-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:61:"13662028_1109900409055524_5232681174920285749_o-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:24:"blue_scenery_slider_size";a:4:{s:4:"file";s:60:"13662028_1109900409055524_5232681174920285749_o-1152x700.jpg";s:5:"width";i:1152;s:6:"height";i:700;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(195, 68, '_wp_attached_file', '2016/12/13680665_1109900405722191_2777831404448902692_n.jpg'),
(196, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:540;s:6:"height";i:540;s:4:"file";s:59:"2016/12/13680665_1109900405722191_2777831404448902692_n.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:59:"13680665_1109900405722191_2777831404448902692_n-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:59:"13680665_1109900405722191_2777831404448902692_n-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(197, 69, '_wp_attached_file', '2016/12/13697997_1109900402388858_7743577443761806408_o.jpg'),
(198, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:59:"2016/12/13697997_1109900402388858_7743577443761806408_o.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:59:"13697997_1109900402388858_7743577443761806408_o-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:59:"13697997_1109900402388858_7743577443761806408_o-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:59:"13697997_1109900402388858_7743577443761806408_o-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:61:"13697997_1109900402388858_7743577443761806408_o-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:24:"blue_scenery_slider_size";a:4:{s:4:"file";s:60:"13697997_1109900402388858_7743577443761806408_o-1200x700.jpg";s:5:"width";i:1200;s:6:"height";i:700;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(199, 70, '_wp_attached_file', '2016/12/13767410_1109900399055525_2705110579242990808_o.jpg'),
(200, 70, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1152;s:6:"height";i:1152;s:4:"file";s:59:"2016/12/13767410_1109900399055525_2705110579242990808_o.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:59:"13767410_1109900399055525_2705110579242990808_o-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:59:"13767410_1109900399055525_2705110579242990808_o-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:59:"13767410_1109900399055525_2705110579242990808_o-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:61:"13767410_1109900399055525_2705110579242990808_o-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:24:"blue_scenery_slider_size";a:4:{s:4:"file";s:60:"13767410_1109900399055525_2705110579242990808_o-1152x700.jpg";s:5:"width";i:1152;s:6:"height";i:700;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(201, 71, '_wp_attached_file', '2016/12/13872769_1109900412388857_897054101226765220_n.jpg'),
(202, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:480;s:4:"file";s:58:"2016/12/13872769_1109900412388857_897054101226765220_n.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:58:"13872769_1109900412388857_897054101226765220_n-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:58:"13872769_1109900412388857_897054101226765220_n-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(203, 73, '_menu_item_type', 'post_type'),
(204, 73, '_menu_item_menu_item_parent', '0'),
(205, 73, '_menu_item_object_id', '72'),
(206, 73, '_menu_item_object', 'page'),
(207, 73, '_menu_item_target', ''),
(208, 73, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(209, 73, '_menu_item_xfn', ''),
(210, 73, '_menu_item_url', ''),
(211, 75, '_menu_item_type', 'post_type'),
(212, 75, '_menu_item_menu_item_parent', '0'),
(213, 75, '_menu_item_object_id', '74'),
(214, 75, '_menu_item_object', 'page'),
(215, 75, '_menu_item_target', ''),
(216, 75, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(217, 75, '_menu_item_xfn', ''),
(218, 75, '_menu_item_url', ''),
(219, 76, '_edit_last', '1'),
(220, 76, '_edit_lock', '1480615206:1'),
(221, 76, '_wp_page_template', 'default'),
(222, 77, '_menu_item_type', 'post_type'),
(223, 77, '_menu_item_menu_item_parent', '0'),
(224, 77, '_menu_item_object_id', '76'),
(225, 77, '_menu_item_object', 'page'),
(226, 77, '_menu_item_target', ''),
(227, 77, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(228, 77, '_menu_item_xfn', ''),
(229, 77, '_menu_item_url', ''),
(230, 76, '_yoast_wpseo_content_score', '60'),
(231, 80, '_edit_last', '1'),
(232, 80, '_edit_lock', '1480602811:1'),
(233, 80, '_wp_page_template', 'default'),
(234, 81, '_menu_item_type', 'post_type'),
(235, 81, '_menu_item_menu_item_parent', '0'),
(236, 81, '_menu_item_object_id', '80'),
(237, 81, '_menu_item_object', 'page'),
(238, 81, '_menu_item_target', ''),
(239, 81, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(240, 81, '_menu_item_xfn', ''),
(241, 81, '_menu_item_url', ''),
(242, 80, '_yoast_wpseo_content_score', '60'),
(243, 90, 'ecwd_calendar_theme', NULL),
(244, 91, 'ecwd_venue_lat_long', '51.554448,-0.286331'),
(245, 91, 'ecwd_venue_location', '23A Wembley Hill Rd, Wembley, Greater London HA9 8AS, UK'),
(246, 94, 'ecwd_event_date_from', '2016/12/01 19:11'),
(247, 94, 'ecwd_event_date_to', '2016/12/01 19:11'),
(248, 94, 'ecwd_event_venue', '91'),
(249, 94, 'ecwd_event_location', '23A Wembley Hill Rd, Wembley, Greater London HA9 8AS, UK'),
(250, 94, 'ecwd_lat_long', '51.554448,-0.286331'),
(251, 94, 'ecwd_event_organizers', 'a:2:{i:0;s:2:"92";i:1;s:2:"93";}'),
(252, 94, 'ecwd_event_calendars', 'a:1:{i:0;s:2:"90";}'),
(253, 95, 'ecwd_event_date_from', '2016/12/08 19:11'),
(254, 95, 'ecwd_event_date_to', '2016/12/08 19:11'),
(255, 95, 'ecwd_event_venue', '91'),
(256, 95, 'ecwd_event_calendars', 'a:1:{i:0;s:2:"90";}'),
(257, 95, 'ecwd_event_location', '23A Wembley Hill Rd, Wembley, Greater London HA9 8AS, UK'),
(258, 95, 'ecwd_lat_long', '51.554448,-0.286331'),
(259, 95, 'ecwd_event_organizers', 'a:2:{i:0;s:2:"92";i:1;s:2:"93";}'),
(260, 96, '_edit_lock', '1480615904:1'),
(261, 96, '_edit_last', '1'),
(262, 96, 'ecwd_calendar_theme', 'calendar'),
(263, 97, '_edit_lock', '1480656238:4'),
(264, 97, '_edit_last', '4'),
(265, 97, '_yoast_wpseo_content_score', '30'),
(266, 97, '_yoast_wpseo_primary_category', '28'),
(267, 99, '_wp_attached_file', '2016/12/1pes12-android.png'),
(268, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1280;s:6:"height";i:720;s:4:"file";s:26:"2016/12/1pes12-android.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"1pes12-android-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"1pes12-android-300x169.png";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:26:"1pes12-android-768x432.png";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:27:"1pes12-android-1024x576.png";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:9:"image/png";}s:24:"blue_scenery_slider_size";a:4:{s:4:"file";s:27:"1pes12-android-1280x700.png";s:5:"width";i:1280;s:6:"height";i:700;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(269, 100, '_wp_attached_file', '2016/12/753ae8936f3768920a6b6fa235603507-7.jpg'),
(270, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:324;s:4:"file";s:46:"2016/12/753ae8936f3768920a6b6fa235603507-7.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:46:"753ae8936f3768920a6b6fa235603507-7-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:46:"753ae8936f3768920a6b6fa235603507-7-278x300.jpg";s:5:"width";i:278;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(271, 101, '_wp_attached_file', '2016/12/a85e33a58106a8db419e7cb8145c4696-Untitled-17.jpg'),
(272, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:643;s:6:"height";i:565;s:4:"file";s:56:"2016/12/a85e33a58106a8db419e7cb8145c4696-Untitled-17.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:56:"a85e33a58106a8db419e7cb8145c4696-Untitled-17-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:56:"a85e33a58106a8db419e7cb8145c4696-Untitled-17-300x264.jpg";s:5:"width";i:300;s:6:"height";i:264;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(273, 102, '_wp_attached_file', '2016/12/amazing-spiderman-galaxy-s3.jpg'),
(274, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:705;s:6:"height";i:344;s:4:"file";s:39:"2016/12/amazing-spiderman-galaxy-s3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"amazing-spiderman-galaxy-s3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:39:"amazing-spiderman-galaxy-s3-300x146.jpg";s:5:"width";i:300;s:6:"height";i:146;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(275, 103, '_wp_attached_file', '2016/12/e44e8b9dd2fad481529192093124067f-nasa-europa.jpg'),
(276, 103, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:350;s:6:"height";i:218;s:4:"file";s:56:"2016/12/e44e8b9dd2fad481529192093124067f-nasa-europa.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:56:"e44e8b9dd2fad481529192093124067f-nasa-europa-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:56:"e44e8b9dd2fad481529192093124067f-nasa-europa-300x187.jpg";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(277, 104, '_wp_attached_file', '2016/12/Grand-Theft-Auto-III-screenshot.jpg'),
(278, 104, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:728;s:6:"height";i:363;s:4:"file";s:43:"2016/12/Grand-Theft-Auto-III-screenshot.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"Grand-Theft-Auto-III-screenshot-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:43:"Grand-Theft-Auto-III-screenshot-300x150.jpg";s:5:"width";i:300;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(279, 105, '_wp_attached_file', '2016/12/modern-combat-4-zero-hour-screen1.jpg'),
(280, 105, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:705;s:6:"height";i:344;s:4:"file";s:45:"2016/12/modern-combat-4-zero-hour-screen1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:45:"modern-combat-4-zero-hour-screen1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:45:"modern-combat-4-zero-hour-screen1-300x146.jpg";s:5:"width";i:300;s:6:"height";i:146;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(281, 106, '_wp_attached_file', '2016/12/N.O.V.A.-3-screenshot.jpg'),
(282, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:705;s:6:"height";i:344;s:4:"file";s:33:"2016/12/N.O.V.A.-3-screenshot.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"N.O.V.A.-3-screenshot-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"N.O.V.A.-3-screenshot-300x146.jpg";s:5:"width";i:300;s:6:"height";i:146;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(285, 108, '_wp_attached_file', '2016/12/The-Dark-Knight-Rises-galaxy-s3.jpg'),
(286, 108, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:705;s:6:"height";i:344;s:4:"file";s:43:"2016/12/The-Dark-Knight-Rises-galaxy-s3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"The-Dark-Knight-Rises-galaxy-s3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:43:"The-Dark-Knight-Rises-galaxy-s3-300x146.jpg";s:5:"width";i:300;s:6:"height";i:146;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(287, 109, '_wp_attached_file', '2016/12/unnamed-1.jpg'),
(288, 109, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:705;s:6:"height";i:345;s:4:"file";s:21:"2016/12/unnamed-1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"unnamed-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"unnamed-1-300x147.jpg";s:5:"width";i:300;s:6:"height";i:147;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(289, 110, '_wp_attached_file', '2016/12/unnamed.jpg'),
(290, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:705;s:6:"height";i:345;s:4:"file";s:19:"2016/12/unnamed.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"unnamed-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"unnamed-300x147.jpg";s:5:"width";i:300;s:6:"height";i:147;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(291, 111, '_wp_attached_file', '2016/12/Wild-Blood-apk-download.jpg'),
(292, 111, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:705;s:6:"height";i:344;s:4:"file";s:35:"2016/12/Wild-Blood-apk-download.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:35:"Wild-Blood-apk-download-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:35:"Wild-Blood-apk-download-300x146.jpg";s:5:"width";i:300;s:6:"height";i:146;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(295, 113, '_wp_attached_file', '2016/12/Need-for-Speed-Most-Wanted-screens.jpg'),
(296, 113, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:705;s:6:"height";i:344;s:4:"file";s:46:"2016/12/Need-for-Speed-Most-Wanted-screens.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:46:"Need-for-Speed-Most-Wanted-screens-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:46:"Need-for-Speed-Most-Wanted-screens-300x146.jpg";s:5:"width";i:300;s:6:"height";i:146;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(297, 114, '_edit_lock', '1480656582:4'),
(298, 114, '_edit_last', '4'),
(301, 114, '_yoast_wpseo_content_score', '30'),
(302, 114, '_yoast_wpseo_primary_category', '29'),
(305, 117, '_edit_lock', '1480655934:4'),
(306, 117, '_edit_last', '4'),
(309, 117, '_yoast_wpseo_content_score', '30'),
(310, 117, '_yoast_wpseo_primary_category', '27'),
(311, 119, '_edit_lock', '1480620891:1'),
(312, 119, '_edit_last', '1'),
(313, 120, '_edit_lock', '1480655520:4'),
(314, 120, '_edit_last', '4'),
(317, 120, '_yoast_wpseo_content_score', '90'),
(318, 120, '_yoast_wpseo_primary_category', '25'),
(319, 120, '_stcr@_subscriber1@gmail.com', '2016-12-01 14:32:06|Y'),
(337, 120, '_yoast_wpseo_focuskw_text_input', 'এন্ড্রয়েড,HD,গেমস,এইচডি,২০১২,১৩'),
(338, 120, '_yoast_wpseo_focuskw', 'এন্ড্রয়েড,HD,গেমস,এইচডি,২০১২,১৩'),
(339, 120, '_yoast_wpseo_linkdex', '63'),
(391, 120, '_aioseop_description', '২০১২-১৩ সালের এন্ড্রয়েড সেরা ১০টি এন্ড্রয়েড এইচডি গেমস নিয়ে সাজান হয়েছে এ পোস্ট টি।'),
(392, 120, '_aioseop_noindex', 'on'),
(393, 120, '_aioseop_nofollow', 'on'),
(394, 120, '_aioseop_noodp', 'on'),
(395, 120, '_aioseop_noydir', 'on'),
(413, 117, '_yoast_wpseo_focuskw_text_input', 'শাহরুখ,আলিয়া,ডিয়ার,জিন্দেগি'),
(414, 117, '_yoast_wpseo_focuskw', 'শাহরুখ,আলিয়া,ডিয়ার,জিন্দেগি'),
(415, 117, '_yoast_wpseo_linkdex', '56'),
(433, 117, '_aioseop_description', '‘কিং খান’ আরও একবার আলিয়ার সঙ্গে জুটি বাঁধতে রাজি, তবে এর সঙ্গে একটি শর্ত জুড়ে দিয়েছেন তিনি।'),
(434, 117, '_aioseop_noindex', 'on'),
(435, 117, '_aioseop_nofollow', 'on'),
(436, 117, '_aioseop_noodp', 'on'),
(437, 117, '_aioseop_noydir', 'on'),
(455, 97, '_yoast_wpseo_focuskw_text_input', 'নাসা,এলিয়েন'),
(456, 97, '_yoast_wpseo_focuskw', 'নাসা,এলিয়েন'),
(457, 97, '_yoast_wpseo_linkdex', '39'),
(475, 97, '_aioseop_description', 'চমক হতে পারে আমাদের এই সৌরজগতে এলিয়েন বা ভিনগ্রহের প্রাণীর গতিবিধি আবিষ্কারের তথ্য।'),
(476, 97, '_aioseop_noindex', 'on'),
(477, 97, '_aioseop_nofollow', 'on'),
(478, 97, '_aioseop_noodp', 'on'),
(479, 97, '_aioseop_noydir', 'on'),
(497, 114, '_yoast_wpseo_focuskw_text_input', 'ডক্টর,স্ট্রেঞ্জ,মারভেল,সুপারহিরো,বেনেডিক্ট,কাম্বারব্যাচ'),
(498, 114, '_yoast_wpseo_focuskw', 'ডক্টর,স্ট্রেঞ্জ,মারভেল,সুপারহিরো,বেনেডিক্ট,কাম্বারব্যাচ'),
(499, 114, '_yoast_wpseo_linkdex', '54'),
(517, 114, '_aioseop_description', 'প্রথম সপ্তাহেই মারভেলের ছবি ডক্টর স্ট্রেঞ্জ যুক্তরাষ্ট্রেরবক্স অফিসে সাড়ে আট কোটি ডলারেরও বেশি আয় করেছে।'),
(518, 114, '_aioseop_noindex', 'on'),
(519, 114, '_aioseop_nofollow', 'on'),
(520, 114, '_aioseop_noodp', 'on'),
(521, 114, '_aioseop_noydir', 'on'),
(522, 130, '_edit_lock', '1480659897:1'),
(523, 131, '_wp_attached_file', '2016/12/af77dc73f31995b457dc2e457ba3fb33-4.jpg'),
(524, 131, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:280;s:6:"height";i:436;s:4:"file";s:46:"2016/12/af77dc73f31995b457dc2e457ba3fb33-4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:46:"af77dc73f31995b457dc2e457ba3fb33-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:46:"af77dc73f31995b457dc2e457ba3fb33-4-193x300.jpg";s:5:"width";i:193;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(525, 130, '_edit_last', '1'),
(546, 130, '_yoast_wpseo_focuskw_text_input', 'ক্যাটরিনা,হাফ,গার্লফ্রেন্ড'),
(547, 130, '_yoast_wpseo_focuskw', 'ক্যাটরিনা,হাফ,গার্লফ্রেন্ড'),
(548, 130, '_yoast_wpseo_linkdex', '36'),
(549, 130, '_yoast_wpseo_content_score', '30'),
(550, 130, '_yoast_wpseo_primary_category', '27'),
(551, 130, '_aioseop_description', 'হাফ গার্লফ্রেন্ড চরিত্রের জন্য নির্মাতা মোহিত সুরি প্রথমে প্রস্তাব দিয়েছিলেন ক্যাটরিনা কাইফকে।'),
(552, 130, '_aioseop_title', 'ক্যাটরিনার ঔদার্য'),
(553, 130, '_aioseop_noindex', 'on'),
(554, 130, '_aioseop_nofollow', 'on'),
(555, 130, '_aioseop_noodp', 'on'),
(556, 130, '_aioseop_noydir', 'on'),
(557, 130, '_stcr@_subscriber1@gmail.com', '2016-12-02 00:26:59|Y'),
(558, 97, '_stcr@_subscriber1@gmail.com', '2016-12-02 12:23:54|Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_posts`
--

CREATE TABLE IF NOT EXISTS `tbl_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=133 ;

--
-- Dumping data for table `tbl_posts`
--

INSERT INTO `tbl_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-12-01 05:51:41', '2016-12-01 05:51:41', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2016-12-01 05:51:41', '2016-12-01 05:51:41', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=1', 0, 'post', '', 1),
(2, 1, '2016-12-01 05:51:41', '2016-12-01 05:51:41', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost:81/wp_mahmuds_pachal/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2016-12-01 05:51:41', '2016-12-01 05:51:41', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?page_id=2', 0, 'page', '', 0),
(3, 1, '2016-12-01 05:52:10', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-12-01 05:52:10', '0000-00-00 00:00:00', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=3', 0, 'post', '', 0),
(4, 1, '2016-12-01 06:03:54', '2016-12-01 06:03:54', 'Mahmud', 'linea_m_logo_metro_de_medellin-svg', 'Mahmud', 'inherit', 'open', 'closed', '', 'linea_m_logo_metro_de_medellin-svg', '', '', '2016-12-01 06:04:18', '2016-12-01 06:04:18', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Linea_M_Logo_Metro_de_Medellin.svg_.png', 0, 'attachment', 'image/png', 0),
(5, 1, '2016-12-01 06:04:24', '2016-12-01 06:04:24', 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/cropped-Linea_M_Logo_Metro_de_Medellin.svg_.png', 'cropped-Linea_M_Logo_Metro_de_Medellin.svg_.png', '', 'inherit', 'open', 'closed', '', 'cropped-linea_m_logo_metro_de_medellin-svg_-png', '', '', '2016-12-01 06:04:24', '2016-12-01 06:04:24', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/cropped-Linea_M_Logo_Metro_de_Medellin.svg_.png', 0, 'attachment', 'image/png', 0),
(6, 1, '2016-12-01 06:07:08', '2016-12-01 06:07:08', 'Follow Your Heart, Chase Your Dream', 'follow-your-herat-chase-your-dreams', 'Follow Your Heart, Chase Your Dream', 'inherit', 'open', 'closed', '', 'follow-your-herat-chase-your-dreams', '', '', '2016-12-01 06:07:47', '2016-12-01 06:07:47', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Follow-your-herat-chase-your-dreams.png', 0, 'attachment', 'image/png', 0),
(7, 1, '2016-12-01 06:08:27', '2016-12-01 06:08:27', 'Mahmud Dhoom 3', 'fb_mhkdhoom3_image', 'Mahmud Dhoom 3', 'inherit', 'open', 'closed', '', 'fb_mhkdhoom3_image', '', '', '2016-12-01 06:08:43', '2016-12-01 06:08:43', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/fb_MHKDhoom3_image.jpg', 0, 'attachment', 'image/jpeg', 0),
(8, 1, '2016-12-01 06:09:22', '2016-12-01 06:09:22', '', '100167', 'Will You Marry Me ?', 'inherit', 'open', 'closed', '', '100167', '', '', '2016-12-01 06:09:49', '2016-12-01 06:09:49', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/100167.gif', 0, 'attachment', 'image/gif', 0),
(9, 1, '2016-12-01 06:10:44', '2016-12-01 06:10:44', 'Looking for Love', '1468618_1378334399081666_1667513437_n', 'Looking for Love', 'inherit', 'open', 'closed', '', '1468618_1378334399081666_1667513437_n', '', '', '2016-12-01 06:11:00', '2016-12-01 06:11:00', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/1468618_1378334399081666_1667513437_n.jpg', 0, 'attachment', 'image/jpeg', 0),
(10, 1, '2016-12-01 06:17:40', '2016-12-01 06:17:40', '', 'Activity', '', 'publish', 'closed', 'closed', '', 'activity', '', '', '2016-12-01 06:17:40', '2016-12-01 06:17:40', '', 0, 'http://localhost:81/wp_mahmuds_pachal/activity/', 0, 'page', '', 0),
(11, 1, '2016-12-01 06:17:41', '2016-12-01 06:17:41', '', 'Members', '', 'publish', 'closed', 'closed', '', 'members', '', '', '2016-12-01 06:17:41', '2016-12-01 06:17:41', '', 0, 'http://localhost:81/wp_mahmuds_pachal/members/', 0, 'page', '', 0),
(12, 1, '2016-12-01 06:17:41', '2016-12-01 06:17:41', ' ', '', '', 'publish', 'closed', 'closed', '', '12', '', '', '2016-12-01 08:36:54', '2016-12-01 14:36:54', '', 0, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/12/', 3, 'nav_menu_item', '', 0),
(13, 1, '2016-12-01 06:17:41', '2016-12-01 06:17:41', ' ', '', '', 'publish', 'closed', 'closed', '', '13', '', '', '2016-12-01 08:36:54', '2016-12-01 14:36:54', '', 0, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/13/', 2, 'nav_menu_item', '', 0),
(14, 1, '2016-12-01 06:17:43', '2016-12-01 06:17:43', '{{poster.name}} replied to one of your updates:\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{thread.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] {{poster.name}} replied to one of your updates', '{{poster.name}} replied to one of your updates:\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{thread.url}}}', 'publish', 'closed', 'closed', '', 'site-name-poster-name-replied-to-one-of-your-updates', '', '', '2016-12-01 06:17:43', '2016-12-01 06:17:43', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=14', 0, 'bp-email', '', 0),
(15, 1, '2016-12-01 06:17:43', '2016-12-01 06:17:43', '{{poster.name}} replied to one of your comments:\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{thread.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] {{poster.name}} replied to one of your comments', '{{poster.name}} replied to one of your comments:\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{thread.url}}}', 'publish', 'closed', 'closed', '', 'site-name-poster-name-replied-to-one-of-your-comments', '', '', '2016-12-01 06:17:43', '2016-12-01 06:17:43', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=15', 0, 'bp-email', '', 0),
(16, 1, '2016-12-01 06:17:47', '2016-12-01 06:17:47', '{{poster.name}} mentioned you in a status update:\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{mentioned.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] {{poster.name}} mentioned you in a status update', '{{poster.name}} mentioned you in a status update:\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{mentioned.url}}}', 'publish', 'closed', 'closed', '', 'site-name-poster-name-mentioned-you-in-a-status-update', '', '', '2016-12-01 06:17:47', '2016-12-01 06:17:47', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=16', 0, 'bp-email', '', 0),
(17, 1, '2016-12-01 06:17:47', '2016-12-01 06:17:47', '{{poster.name}} replied to one of your updates:\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{thread.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] {{poster.name}} replied to one of your updates', '{{poster.name}} replied to one of your updates:\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{thread.url}}}', 'publish', 'closed', 'closed', '', 'site-name-poster-name-replied-to-one-of-your-updates-2', '', '', '2016-12-01 06:17:47', '2016-12-01 06:17:47', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=17', 0, 'bp-email', '', 0),
(18, 1, '2016-12-01 06:17:47', '2016-12-01 06:17:47', '{{poster.name}} mentioned you in the group "{{group.name}}":\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{mentioned.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] {{poster.name}} mentioned you in an update', '{{poster.name}} mentioned you in the group "{{group.name}}":\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{mentioned.url}}}', 'publish', 'closed', 'closed', '', 'site-name-poster-name-mentioned-you-in-an-update', '', '', '2016-12-01 06:17:47', '2016-12-01 06:17:47', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=18', 0, 'bp-email', '', 0),
(19, 1, '2016-12-01 06:17:49', '2016-12-01 06:17:49', '{{poster.name}} replied to one of your comments:\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{thread.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] {{poster.name}} replied to one of your comments', '{{poster.name}} replied to one of your comments:\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{thread.url}}}', 'publish', 'closed', 'closed', '', 'site-name-poster-name-replied-to-one-of-your-comments-2', '', '', '2016-12-01 06:17:49', '2016-12-01 06:17:49', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=19', 0, 'bp-email', '', 0),
(20, 1, '2016-12-01 06:17:49', '2016-12-01 06:17:49', 'Thanks for registering!\n\nTo complete the activation of your account, go to the following link: <a href="{{{activate.url}}}">{{{activate.url}}}</a>', '[{{{site.name}}}] Activate your account', 'Thanks for registering!\n\nTo complete the activation of your account, go to the following link: {{{activate.url}}}', 'publish', 'closed', 'closed', '', 'site-name-activate-your-account', '', '', '2016-12-01 06:17:49', '2016-12-01 06:17:49', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=20', 0, 'bp-email', '', 0),
(21, 1, '2016-12-01 06:17:50', '2016-12-01 06:17:50', '{{poster.name}} mentioned you in a status update:\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{mentioned.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] {{poster.name}} mentioned you in a status update', '{{poster.name}} mentioned you in a status update:\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{mentioned.url}}}', 'publish', 'closed', 'closed', '', 'site-name-poster-name-mentioned-you-in-a-status-update-2', '', '', '2016-12-01 06:17:50', '2016-12-01 06:17:50', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=21', 0, 'bp-email', '', 0),
(22, 1, '2016-12-01 06:17:50', '2016-12-01 06:17:50', '{{poster.name}} mentioned you in the group "{{group.name}}":\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{mentioned.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] {{poster.name}} mentioned you in an update', '{{poster.name}} mentioned you in the group "{{group.name}}":\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{mentioned.url}}}', 'publish', 'closed', 'closed', '', 'site-name-poster-name-mentioned-you-in-an-update-2', '', '', '2016-12-01 06:17:50', '2016-12-01 06:17:50', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=22', 0, 'bp-email', '', 0),
(23, 1, '2016-12-01 06:17:51', '2016-12-01 06:17:51', 'Thanks for registering!\n\nTo complete the activation of your account and site, go to the following link: <a href="{{{activate-site.url}}}">{{{activate-site.url}}}</a>.\n\nAfter you activate, you can visit your site at <a href="{{{user-site.url}}}">{{{user-site.url}}}</a>.', '[{{{site.name}}}] Activate {{{user-site.url}}}', 'Thanks for registering!\n\nTo complete the activation of your account and site, go to the following link: {{{activate-site.url}}}\n\nAfter you activate, you can visit your site at {{{user-site.url}}}.', 'publish', 'closed', 'closed', '', 'site-name-activate-user-site-url', '', '', '2016-12-01 06:17:51', '2016-12-01 06:17:51', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=23', 0, 'bp-email', '', 0),
(24, 1, '2016-12-01 06:17:51', '2016-12-01 06:17:51', 'Thanks for registering!\n\nTo complete the activation of your account, go to the following link: <a href="{{{activate.url}}}">{{{activate.url}}}</a>', '[{{{site.name}}}] Activate your account', 'Thanks for registering!\n\nTo complete the activation of your account, go to the following link: {{{activate.url}}}', 'publish', 'closed', 'closed', '', 'site-name-activate-your-account-2', '', '', '2016-12-01 06:17:51', '2016-12-01 06:17:51', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=24', 0, 'bp-email', '', 0),
(25, 1, '2016-12-01 06:17:52', '2016-12-01 06:17:52', '<a href="{{{initiator.url}}}">{{initiator.name}}</a> wants to add you as a friend.\n\nTo accept this request and manage all of your pending requests, visit: <a href="{{{friend-requests.url}}}">{{{friend-requests.url}}}</a>', '[{{{site.name}}}] New friendship request from {{initiator.name}}', '{{initiator.name}} wants to add you as a friend.\n\nTo accept this request and manage all of your pending requests, visit: {{{friend-requests.url}}}\n\nTo view {{initiator.name}}''s profile, visit: {{{initiator.url}}}', 'publish', 'closed', 'closed', '', 'site-name-new-friendship-request-from-initiator-name', '', '', '2016-12-01 06:17:52', '2016-12-01 06:17:52', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=25', 0, 'bp-email', '', 0),
(26, 1, '2016-12-01 06:17:52', '2016-12-01 06:17:52', 'Thanks for registering!\n\nTo complete the activation of your account and site, go to the following link: <a href="{{{activate-site.url}}}">{{{activate-site.url}}}</a>.\n\nAfter you activate, you can visit your site at <a href="{{{user-site.url}}}">{{{user-site.url}}}</a>.', '[{{{site.name}}}] Activate {{{user-site.url}}}', 'Thanks for registering!\n\nTo complete the activation of your account and site, go to the following link: {{{activate-site.url}}}\n\nAfter you activate, you can visit your site at {{{user-site.url}}}.', 'publish', 'closed', 'closed', '', 'site-name-activate-user-site-url-2', '', '', '2016-12-01 06:17:52', '2016-12-01 06:17:52', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=26', 0, 'bp-email', '', 0),
(27, 1, '2016-12-01 06:17:52', '2016-12-01 06:17:52', '<a href="{{{initiator.url}}}">{{initiator.name}}</a> wants to add you as a friend.\n\nTo accept this request and manage all of your pending requests, visit: <a href="{{{friend-requests.url}}}">{{{friend-requests.url}}}</a>', '[{{{site.name}}}] New friendship request from {{initiator.name}}', '{{initiator.name}} wants to add you as a friend.\n\nTo accept this request and manage all of your pending requests, visit: {{{friend-requests.url}}}\n\nTo view {{initiator.name}}''s profile, visit: {{{initiator.url}}}', 'publish', 'closed', 'closed', '', 'site-name-new-friendship-request-from-initiator-name-2', '', '', '2016-12-01 06:17:52', '2016-12-01 06:17:52', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=27', 0, 'bp-email', '', 0),
(28, 1, '2016-12-01 06:17:52', '2016-12-01 06:17:52', '<a href="{{{friendship.url}}}">{{friend.name}}</a> accepted your friend request.', '[{{{site.name}}}] {{friend.name}} accepted your friendship request', '{{friend.name}} accepted your friend request.\n\nTo learn more about them, visit their profile: {{{friendship.url}}}', 'publish', 'closed', 'closed', '', 'site-name-friend-name-accepted-your-friendship-request', '', '', '2016-12-01 06:17:52', '2016-12-01 06:17:52', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=28', 0, 'bp-email', '', 0),
(29, 1, '2016-12-01 06:17:53', '2016-12-01 06:17:53', '<a href="{{{friendship.url}}}">{{friend.name}}</a> accepted your friend request.', '[{{{site.name}}}] {{friend.name}} accepted your friendship request', '{{friend.name}} accepted your friend request.\n\nTo learn more about them, visit their profile: {{{friendship.url}}}', 'publish', 'closed', 'closed', '', 'site-name-friend-name-accepted-your-friendship-request-2', '', '', '2016-12-01 06:17:53', '2016-12-01 06:17:53', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=29', 0, 'bp-email', '', 0),
(30, 1, '2016-12-01 06:17:53', '2016-12-01 06:17:53', 'Group details for the group &quot;<a href="{{{group.url}}}">{{group.name}}</a>&quot; were updated:\n<blockquote>{{changed_text}}</blockquote>', '[{{{site.name}}}] Group details updated', 'Group details for the group "{{group.name}}" were updated:\n\n{{changed_text}}\n\nTo view the group, visit: {{{group.url}}}', 'publish', 'closed', 'closed', '', 'site-name-group-details-updated', '', '', '2016-12-01 06:17:53', '2016-12-01 06:17:53', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=30', 0, 'bp-email', '', 0),
(31, 1, '2016-12-01 06:17:53', '2016-12-01 06:17:53', 'Group details for the group &quot;<a href="{{{group.url}}}">{{group.name}}</a>&quot; were updated:\n<blockquote>{{changed_text}}</blockquote>', '[{{{site.name}}}] Group details updated', 'Group details for the group "{{group.name}}" were updated:\n\n{{changed_text}}\n\nTo view the group, visit: {{{group.url}}}', 'publish', 'closed', 'closed', '', 'site-name-group-details-updated-2', '', '', '2016-12-01 06:17:53', '2016-12-01 06:17:53', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=31', 0, 'bp-email', '', 0),
(32, 1, '2016-12-01 06:17:54', '2016-12-01 06:17:54', '<a href="{{{inviter.url}}}">{{inviter.name}}</a> has invited you to join the group: &quot;{{group.name}}&quot;.\n<a href="{{{invites.url}}}">Go here to accept your invitation</a> or <a href="{{{group.url}}}">visit the group</a> to learn more.', '[{{{site.name}}}] You have an invitation to the group: "{{group.name}}"', '{{inviter.name}} has invited you to join the group: "{{group.name}}".\n\nTo accept your invitation, visit: {{{invites.url}}}\n\nTo learn more about the group, visit {{{group.url}}}.\nTo view {{inviter.name}}''s profile, visit: {{{inviter.url}}}', 'publish', 'closed', 'closed', '', 'site-name-you-have-an-invitation-to-the-group-group-name', '', '', '2016-12-01 06:17:54', '2016-12-01 06:17:54', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=32', 0, 'bp-email', '', 0),
(33, 1, '2016-12-01 06:17:54', '2016-12-01 06:17:54', '<a href="{{{inviter.url}}}">{{inviter.name}}</a> has invited you to join the group: &quot;{{group.name}}&quot;.\n<a href="{{{invites.url}}}">Go here to accept your invitation</a> or <a href="{{{group.url}}}">visit the group</a> to learn more.', '[{{{site.name}}}] You have an invitation to the group: "{{group.name}}"', '{{inviter.name}} has invited you to join the group: "{{group.name}}".\n\nTo accept your invitation, visit: {{{invites.url}}}\n\nTo learn more about the group, visit {{{group.url}}}.\nTo view {{inviter.name}}''s profile, visit: {{{inviter.url}}}', 'publish', 'closed', 'closed', '', 'site-name-you-have-an-invitation-to-the-group-group-name-2', '', '', '2016-12-01 06:17:54', '2016-12-01 06:17:54', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=33', 0, 'bp-email', '', 0),
(34, 1, '2016-12-01 06:17:55', '2016-12-01 06:17:55', 'You have been promoted to <b>{{promoted_to}}</b> in the group &quot;<a href="{{{group.url}}}">{{group.name}}</a>&quot;.', '[{{{site.name}}}] You have been promoted in the group: "{{group.name}}"', 'You have been promoted to {{promoted_to}} in the group: "{{group.name}}".\n\nTo visit the group, go to: {{{group.url}}}', 'publish', 'closed', 'closed', '', 'site-name-you-have-been-promoted-in-the-group-group-name', '', '', '2016-12-01 06:17:55', '2016-12-01 06:17:55', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=34', 0, 'bp-email', '', 0),
(35, 1, '2016-12-01 06:17:55', '2016-12-01 06:17:55', 'You have been promoted to <b>{{promoted_to}}</b> in the group &quot;<a href="{{{group.url}}}">{{group.name}}</a>&quot;.', '[{{{site.name}}}] You have been promoted in the group: "{{group.name}}"', 'You have been promoted to {{promoted_to}} in the group: "{{group.name}}".\n\nTo visit the group, go to: {{{group.url}}}', 'publish', 'closed', 'closed', '', 'site-name-you-have-been-promoted-in-the-group-group-name-2', '', '', '2016-12-01 06:17:55', '2016-12-01 06:17:55', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=35', 0, 'bp-email', '', 0),
(36, 1, '2016-12-01 06:17:56', '2016-12-01 06:17:56', '<a href="{{{profile.url}}}">{{requesting-user.name}}</a> wants to join the group &quot;{{group.name}}&quot;. As you are an administrator of this group, you must either accept or reject the membership request.\n\n<a href="{{{group-requests.url}}}">Go here to manage this</a> and all other pending requests.', '[{{{site.name}}}] Membership request for group: {{group.name}}', '{{requesting-user.name}} wants to join the group "{{group.name}}". As you are the administrator of this group, you must either accept or reject the membership request.\n\nTo manage this and all other pending requests, visit: {{{group-requests.url}}}\n\nTo view {{requesting-user.name}}''s profile, visit: {{{profile.url}}}', 'publish', 'closed', 'closed', '', 'site-name-membership-request-for-group-group-name', '', '', '2016-12-01 06:17:56', '2016-12-01 06:17:56', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=36', 0, 'bp-email', '', 0),
(37, 1, '2016-12-01 06:17:56', '2016-12-01 06:17:56', '<a href="{{{profile.url}}}">{{requesting-user.name}}</a> wants to join the group &quot;{{group.name}}&quot;. As you are an administrator of this group, you must either accept or reject the membership request.\n\n<a href="{{{group-requests.url}}}">Go here to manage this</a> and all other pending requests.', '[{{{site.name}}}] Membership request for group: {{group.name}}', '{{requesting-user.name}} wants to join the group "{{group.name}}". As you are the administrator of this group, you must either accept or reject the membership request.\n\nTo manage this and all other pending requests, visit: {{{group-requests.url}}}\n\nTo view {{requesting-user.name}}''s profile, visit: {{{profile.url}}}', 'publish', 'closed', 'closed', '', 'site-name-membership-request-for-group-group-name-2', '', '', '2016-12-01 06:17:56', '2016-12-01 06:17:56', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=37', 0, 'bp-email', '', 0),
(38, 1, '2016-12-01 06:17:57', '2016-12-01 06:17:57', '{{sender.name}} sent you a new message: &quot;{{usersubject}}&quot;\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{message.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] New message from {{sender.name}}', '{{sender.name}} sent you a new message: "{{usersubject}}"\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{message.url}}}', 'publish', 'closed', 'closed', '', 'site-name-new-message-from-sender-name', '', '', '2016-12-01 06:17:57', '2016-12-01 06:17:57', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=38', 0, 'bp-email', '', 0),
(39, 1, '2016-12-01 06:17:57', '2016-12-01 06:17:57', '{{sender.name}} sent you a new message: &quot;{{usersubject}}&quot;\n\n<blockquote>&quot;{{usermessage}}&quot;</blockquote>\n\n<a href="{{{message.url}}}">Go to the discussion</a> to reply or catch up on the conversation.', '[{{{site.name}}}] New message from {{sender.name}}', '{{sender.name}} sent you a new message: "{{usersubject}}"\n\n"{{usermessage}}"\n\nGo to the discussion to reply or catch up on the conversation: {{{message.url}}}', 'publish', 'closed', 'closed', '', 'site-name-new-message-from-sender-name-2', '', '', '2016-12-01 06:17:57', '2016-12-01 06:17:57', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=39', 0, 'bp-email', '', 0),
(40, 1, '2016-12-01 06:17:57', '2016-12-01 06:17:57', 'You recently changed the email address associated with your account on {{site.name}} to {{user.email}}. If this is correct, <a href="{{{verify.url}}}">go here to confirm the change</a>.\n\nOtherwise, you can safely ignore and delete this email if you have changed your mind, or if you think you have received this email in error.', '[{{{site.name}}}] Verify your new email address', 'You recently changed the email address associated with your account on {{site.name}} to {{user.email}}. If this is correct, go to the following link to confirm the change: {{{verify.url}}}\n\nOtherwise, you can safely ignore and delete this email if you have changed your mind, or if you think you have received this email in error.', 'publish', 'closed', 'closed', '', 'site-name-verify-your-new-email-address', '', '', '2016-12-01 06:17:57', '2016-12-01 06:17:57', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=40', 0, 'bp-email', '', 0),
(41, 1, '2016-12-01 06:17:58', '2016-12-01 06:17:58', 'You recently changed the email address associated with your account on {{site.name}} to {{user.email}}. If this is correct, <a href="{{{verify.url}}}">go here to confirm the change</a>.\n\nOtherwise, you can safely ignore and delete this email if you have changed your mind, or if you think you have received this email in error.', '[{{{site.name}}}] Verify your new email address', 'You recently changed the email address associated with your account on {{site.name}} to {{user.email}}. If this is correct, go to the following link to confirm the change: {{{verify.url}}}\n\nOtherwise, you can safely ignore and delete this email if you have changed your mind, or if you think you have received this email in error.', 'publish', 'closed', 'closed', '', 'site-name-verify-your-new-email-address-2', '', '', '2016-12-01 06:17:58', '2016-12-01 06:17:58', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=41', 0, 'bp-email', '', 0),
(42, 1, '2016-12-01 06:17:59', '2016-12-01 06:17:59', 'Your membership request for the group &quot;<a href="{{{group.url}}}">{{group.name}}</a>&quot; has been accepted.', '[{{{site.name}}}] Membership request for group "{{group.name}}" accepted', 'Your membership request for the group "{{group.name}}" has been accepted.\n\nTo view the group, visit: {{{group.url}}}', 'publish', 'closed', 'closed', '', 'site-name-membership-request-for-group-group-name-accepted', '', '', '2016-12-01 06:17:59', '2016-12-01 06:17:59', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=42', 0, 'bp-email', '', 0),
(43, 1, '2016-12-01 06:17:59', '2016-12-01 06:17:59', 'Your membership request for the group &quot;<a href="{{{group.url}}}">{{group.name}}</a>&quot; has been accepted.', '[{{{site.name}}}] Membership request for group "{{group.name}}" accepted', 'Your membership request for the group "{{group.name}}" has been accepted.\n\nTo view the group, visit: {{{group.url}}}', 'publish', 'closed', 'closed', '', 'site-name-membership-request-for-group-group-name-accepted-2', '', '', '2016-12-01 06:17:59', '2016-12-01 06:17:59', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=43', 0, 'bp-email', '', 0),
(44, 1, '2016-12-01 06:18:00', '2016-12-01 06:18:00', 'Your membership request for the group &quot;<a href="{{{group.url}}}">{{group.name}}</a>&quot; has been rejected.', '[{{{site.name}}}] Membership request for group "{{group.name}}" rejected', 'Your membership request for the group "{{group.name}}" has been rejected.\n\nTo request membership again, visit: {{{group.url}}}', 'publish', 'closed', 'closed', '', 'site-name-membership-request-for-group-group-name-rejected', '', '', '2016-12-01 06:18:00', '2016-12-01 06:18:00', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=44', 0, 'bp-email', '', 0),
(45, 1, '2016-12-01 06:18:00', '2016-12-01 06:18:00', 'Your membership request for the group &quot;<a href="{{{group.url}}}">{{group.name}}</a>&quot; has been rejected.', '[{{{site.name}}}] Membership request for group "{{group.name}}" rejected', 'Your membership request for the group "{{group.name}}" has been rejected.\n\nTo request membership again, visit: {{{group.url}}}', 'publish', 'closed', 'closed', '', 'site-name-membership-request-for-group-group-name-rejected-2', '', '', '2016-12-01 06:18:00', '2016-12-01 06:18:00', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=bp-email&p=45', 0, 'bp-email', '', 0),
(46, 1, '2016-12-01 06:19:38', '2016-12-01 06:19:38', '', 'Groups', '', 'publish', 'closed', 'closed', '', 'groups', '', '', '2016-12-01 06:19:38', '2016-12-01 06:19:38', '', 0, 'http://localhost:81/wp_mahmuds_pachal/groups/', 0, 'page', '', 0),
(47, 1, '2016-12-01 06:19:38', '2016-12-01 06:19:38', ' ', '', '', 'publish', 'closed', 'closed', '', '47', '', '', '2016-12-01 08:36:54', '2016-12-01 14:36:54', '', 0, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/47/', 4, 'nav_menu_item', '', 0),
(48, 1, '2016-12-01 06:32:51', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGh1bWJuYWlscyIsImVudGl0eV90eXBlcyI6WyJpbWFnZSJdLCJwcmV2aWV3X2ltYWdlX3JlbHBhdGgiOiJcXG5leHRnZW4tZ2FsbGVyeVxccHJvZHVjdHNcXHBob3RvY3JhdGlfbmV4dGdlblxcbW9kdWxlc1xcbmV4dGdlbl9iYXNpY19nYWxsZXJ5XFxzdGF0aWNcXHRodW1iX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAwMCwiYWxpYXNlcyI6WyJiYXNpY190aHVtYm5haWwiLCJiYXNpY190aHVtYm5haWxzIiwibmV4dGdlbl9iYXNpY190aHVtYm5haWxzIl0sIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4xLjYwIiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImltYWdlc19wZXJfcGFnZSI6IjIwIiwibnVtYmVyX29mX2NvbHVtbnMiOjAsInRodW1ibmFpbF93aWR0aCI6MjQwLCJ0aHVtYm5haWxfaGVpZ2h0IjoxNjAsInNob3dfYWxsX2luX2xpZ2h0Ym94IjowLCJhamF4X3BhZ2luYXRpb24iOjAsInVzZV9pbWFnZWJyb3dzZXJfZWZmZWN0IjowLCJ0ZW1wbGF0ZSI6IiIsImRpc3BsYXlfbm9faW1hZ2VzX2Vycm9yIjoxLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInNob3dfc2xpZGVzaG93X2xpbmsiOjEsInNsaWRlc2hvd19saW5rX3RleHQiOiJbU2hvdyBzbGlkZXNob3ddIiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjowLCJ0aHVtYm5haWxfcXVhbGl0eSI6IjEwMCIsInRodW1ibmFpbF9jcm9wIjoxLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'NextGEN Basic Thumbnails', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-12-01 06:32:51', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGh1bWJuYWlscyIsImVudGl0eV90eXBlcyI6WyJpbWFnZSJdLCJwcmV2aWV3X2ltYWdlX3JlbHBhdGgiOiJcXG5leHRnZW4tZ2FsbGVyeVxccHJvZHVjdHNcXHBob3RvY3JhdGlfbmV4dGdlblxcbW9kdWxlc1xcbmV4dGdlbl9iYXNpY19nYWxsZXJ5XFxzdGF0aWNcXHRodW1iX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAwMCwiYWxpYXNlcyI6WyJiYXNpY190aHVtYm5haWwiLCJiYXNpY190aHVtYm5haWxzIiwibmV4dGdlbl9iYXNpY190aHVtYm5haWxzIl0sIm5hbWUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4xLjYwIiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImltYWdlc19wZXJfcGFnZSI6IjIwIiwibnVtYmVyX29mX2NvbHVtbnMiOjAsInRodW1ibmFpbF93aWR0aCI6MjQwLCJ0aHVtYm5haWxfaGVpZ2h0IjoxNjAsInNob3dfYWxsX2luX2xpZ2h0Ym94IjowLCJhamF4X3BhZ2luYXRpb24iOjAsInVzZV9pbWFnZWJyb3dzZXJfZWZmZWN0IjowLCJ0ZW1wbGF0ZSI6IiIsImRpc3BsYXlfbm9faW1hZ2VzX2Vycm9yIjoxLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInNob3dfc2xpZGVzaG93X2xpbmsiOjEsInNsaWRlc2hvd19saW5rX3RleHQiOiJbU2hvdyBzbGlkZXNob3ddIiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjowLCJ0aHVtYm5haWxfcXVhbGl0eSI6IjEwMCIsInRodW1ibmFpbF9jcm9wIjoxLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=display_type&p=48', 0, 'display_type', '', 0),
(49, 1, '2016-12-01 06:32:51', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2xpZGVzaG93IiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlxcbmV4dGdlbi1nYWxsZXJ5XFxwcm9kdWN0c1xccGhvdG9jcmF0aV9uZXh0Z2VuXFxtb2R1bGVzXFxuZXh0Z2VuX2Jhc2ljX2dhbGxlcnlcXHN0YXRpY1xcc2xpZGVzaG93X3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAxMCwiYWxpYXNlcyI6WyJiYXNpY19zbGlkZXNob3ciLCJuZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4xLjYwIiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImdhbGxlcnlfd2lkdGgiOjYwMCwiZ2FsbGVyeV9oZWlnaHQiOjQwMCwidGh1bWJuYWlsX3dpZHRoIjoyNDAsInRodW1ibmFpbF9oZWlnaHQiOjE2MCwiY3ljbGVfaW50ZXJ2YWwiOjEwLCJjeWNsZV9lZmZlY3QiOiJmYWRlIiwiZWZmZWN0X2NvZGUiOiJjbGFzcz1cIm5nZy1mYW5jeWJveFwiIHJlbD1cIiVHQUxMRVJZX05BTUUlXCIiLCJzaG93X3RodW1ibmFpbF9saW5rIjoxLCJ0aHVtYm5haWxfbGlua190ZXh0IjoiW1Nob3cgdGh1bWJuYWlsc10iLCJ0ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 'NextGEN Basic Slideshow', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-12-01 06:32:51', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2xpZGVzaG93IiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlxcbmV4dGdlbi1nYWxsZXJ5XFxwcm9kdWN0c1xccGhvdG9jcmF0aV9uZXh0Z2VuXFxtb2R1bGVzXFxuZXh0Z2VuX2Jhc2ljX2dhbGxlcnlcXHN0YXRpY1xcc2xpZGVzaG93X3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAxMCwiYWxpYXNlcyI6WyJiYXNpY19zbGlkZXNob3ciLCJuZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMi4xLjYwIiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7InVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImdhbGxlcnlfd2lkdGgiOjYwMCwiZ2FsbGVyeV9oZWlnaHQiOjQwMCwidGh1bWJuYWlsX3dpZHRoIjoyNDAsInRodW1ibmFpbF9oZWlnaHQiOjE2MCwiY3ljbGVfaW50ZXJ2YWwiOjEwLCJjeWNsZV9lZmZlY3QiOiJmYWRlIiwiZWZmZWN0X2NvZGUiOiJjbGFzcz1cIm5nZy1mYW5jeWJveFwiIHJlbD1cIiVHQUxMRVJZX05BTUUlXCIiLCJzaG93X3RodW1ibmFpbF9saW5rIjoxLCJ0aHVtYm5haWxfbGlua190ZXh0IjoiW1Nob3cgdGh1bWJuYWlsc10iLCJ0ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=display_type&p=49', 0, 'display_type', '', 0),
(50, 1, '2016-12-01 06:32:52', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgSW1hZ2VCcm93c2VyIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlxcbmV4dGdlbi1nYWxsZXJ5XFxwcm9kdWN0c1xccGhvdG9jcmF0aV9uZXh0Z2VuXFxtb2R1bGVzXFxuZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3Nlclxcc3RhdGljXFxwcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwMjAsImFsaWFzZXMiOlsiYmFzaWNfaW1hZ2Vicm93c2VyIiwiaW1hZ2Vicm93c2VyIiwibmV4dGdlbl9iYXNpY19pbWFnZWJyb3dzZXIiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19pbWFnZWJyb3dzZXIiLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjIuMS42MCIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ0ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 'NextGEN Basic ImageBrowser', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-12-01 06:32:52', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgSW1hZ2VCcm93c2VyIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlxcbmV4dGdlbi1nYWxsZXJ5XFxwcm9kdWN0c1xccGhvdG9jcmF0aV9uZXh0Z2VuXFxtb2R1bGVzXFxuZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3Nlclxcc3RhdGljXFxwcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwMjAsImFsaWFzZXMiOlsiYmFzaWNfaW1hZ2Vicm93c2VyIiwiaW1hZ2Vicm93c2VyIiwibmV4dGdlbl9iYXNpY19pbWFnZWJyb3dzZXIiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19pbWFnZWJyb3dzZXIiLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjIuMS42MCIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ0ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=display_type&p=50', 0, 'display_type', '', 0),
(51, 1, '2016-12-01 06:32:52', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2luZ2xlUGljIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlxcbmV4dGdlbi1nYWxsZXJ5XFxwcm9kdWN0c1xccGhvdG9jcmF0aV9uZXh0Z2VuXFxtb2R1bGVzXFxuZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpY1xcc3RhdGljXFxwcmV2aWV3LmdpZiIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwNjAsImhpZGRlbl9mcm9tX3VpIjp0cnVlLCJoaWRkZW5fZnJvbV9pZ3ciOnRydWUsImFsaWFzZXMiOlsiYmFzaWNfc2luZ2xlcGljIiwic2luZ2xlcGljIiwibmV4dGdlbl9iYXNpY19zaW5nbGVwaWMiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19zaW5nbGVwaWMiLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjIuMS42MCIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ3aWR0aCI6IiIsImhlaWdodCI6IiIsIm1vZGUiOiIiLCJkaXNwbGF5X3dhdGVybWFyayI6MCwiZGlzcGxheV9yZWZsZWN0aW9uIjowLCJmbG9hdCI6IiIsImxpbmsiOiIiLCJsaW5rX3RhcmdldCI6Il9ibGFuayIsInF1YWxpdHkiOjEwMCwiY3JvcCI6MCwidGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 'NextGEN Basic SinglePic', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-12-01 06:32:52', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgU2luZ2xlUGljIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlxcbmV4dGdlbi1nYWxsZXJ5XFxwcm9kdWN0c1xccGhvdG9jcmF0aV9uZXh0Z2VuXFxtb2R1bGVzXFxuZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpY1xcc3RhdGljXFxwcmV2aWV3LmdpZiIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwNjAsImhpZGRlbl9mcm9tX3VpIjp0cnVlLCJoaWRkZW5fZnJvbV9pZ3ciOnRydWUsImFsaWFzZXMiOlsiYmFzaWNfc2luZ2xlcGljIiwic2luZ2xlcGljIiwibmV4dGdlbl9iYXNpY19zaW5nbGVwaWMiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19zaW5nbGVwaWMiLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjIuMS42MCIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJ3aWR0aCI6IiIsImhlaWdodCI6IiIsIm1vZGUiOiIiLCJkaXNwbGF5X3dhdGVybWFyayI6MCwiZGlzcGxheV9yZWZsZWN0aW9uIjowLCJmbG9hdCI6IiIsImxpbmsiOiIiLCJsaW5rX3RhcmdldCI6Il9ibGFuayIsInF1YWxpdHkiOjEwMCwiY3JvcCI6MCwidGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=display_type&p=51', 0, 'display_type', '', 0),
(52, 1, '2016-12-01 06:32:53', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGFnQ2xvdWQiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXFxuZXh0Z2VuLWdhbGxlcnlcXHByb2R1Y3RzXFxwaG90b2NyYXRpX25leHRnZW5cXG1vZHVsZXNcXG5leHRnZW5fYmFzaWNfdGFnY2xvdWRcXHN0YXRpY1xccHJldmlldy5naWYiLCJkZWZhdWx0X3NvdXJjZSI6InRhZ3MiLCJ2aWV3X29yZGVyIjoxMDEwMCwiYWxpYXNlcyI6WyJiYXNpY190YWdjbG91ZCIsInRhZ2Nsb3VkIiwibmV4dGdlbl9iYXNpY190YWdjbG91ZCJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RhZ2Nsb3VkIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIyLjEuNjAiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsIm51bWJlciI6NDUsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 'NextGEN Basic TagCloud', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-12-01 06:32:53', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGFnQ2xvdWQiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXFxuZXh0Z2VuLWdhbGxlcnlcXHByb2R1Y3RzXFxwaG90b2NyYXRpX25leHRnZW5cXG1vZHVsZXNcXG5leHRnZW5fYmFzaWNfdGFnY2xvdWRcXHN0YXRpY1xccHJldmlldy5naWYiLCJkZWZhdWx0X3NvdXJjZSI6InRhZ3MiLCJ2aWV3X29yZGVyIjoxMDEwMCwiYWxpYXNlcyI6WyJiYXNpY190YWdjbG91ZCIsInRhZ2Nsb3VkIiwibmV4dGdlbl9iYXNpY190YWdjbG91ZCJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RhZ2Nsb3VkIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIyLjEuNjAiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsIm51bWJlciI6NDUsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=display_type&p=52', 0, 'display_type', '', 0),
(53, 1, '2016-12-01 06:32:53', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgQ29tcGFjdCBBbGJ1bSIsImVudGl0eV90eXBlcyI6WyJhbGJ1bSIsImdhbGxlcnkiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXFxuZXh0Z2VuLWdhbGxlcnlcXHByb2R1Y3RzXFxwaG90b2NyYXRpX25leHRnZW5cXG1vZHVsZXNcXG5leHRnZW5fYmFzaWNfYWxidW1cXHN0YXRpY1xcY29tcGFjdF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMDAsImFsaWFzZXMiOlsiYmFzaWNfY29tcGFjdF9hbGJ1bSIsIm5leHRnZW5fYmFzaWNfYWxidW0iLCJiYXNpY19hbGJ1bV9jb21wYWN0IiwiY29tcGFjdF9hbGJ1bSJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2NvbXBhY3RfYWxidW0iLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjIuMS42MCIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOjAsImVuYWJsZV9icmVhZGNydW1icyI6MSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJlbmFibGVfZGVzY3JpcHRpb25zIjowLCJ0ZW1wbGF0ZSI6IiIsIm9wZW5fZ2FsbGVyeV9pbl9saWdodGJveCI6MCwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 'NextGEN Basic Compact Album', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-12-01 06:32:53', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgQ29tcGFjdCBBbGJ1bSIsImVudGl0eV90eXBlcyI6WyJhbGJ1bSIsImdhbGxlcnkiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXFxuZXh0Z2VuLWdhbGxlcnlcXHByb2R1Y3RzXFxwaG90b2NyYXRpX25leHRnZW5cXG1vZHVsZXNcXG5leHRnZW5fYmFzaWNfYWxidW1cXHN0YXRpY1xcY29tcGFjdF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMDAsImFsaWFzZXMiOlsiYmFzaWNfY29tcGFjdF9hbGJ1bSIsIm5leHRnZW5fYmFzaWNfYWxidW0iLCJiYXNpY19hbGJ1bV9jb21wYWN0IiwiY29tcGFjdF9hbGJ1bSJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2NvbXBhY3RfYWxidW0iLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjIuMS42MCIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOjAsImVuYWJsZV9icmVhZGNydW1icyI6MSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJlbmFibGVfZGVzY3JpcHRpb25zIjowLCJ0ZW1wbGF0ZSI6IiIsIm9wZW5fZ2FsbGVyeV9pbl9saWdodGJveCI6MCwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIifSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=display_type&p=53', 0, 'display_type', '', 0),
(54, 1, '2016-12-01 06:32:54', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgRXh0ZW5kZWQgQWxidW0iLCJlbnRpdHlfdHlwZXMiOlsiYWxidW0iLCJnYWxsZXJ5Il0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlxcbmV4dGdlbi1nYWxsZXJ5XFxwcm9kdWN0c1xccGhvdG9jcmF0aV9uZXh0Z2VuXFxtb2R1bGVzXFxuZXh0Z2VuX2Jhc2ljX2FsYnVtXFxzdGF0aWNcXGV4dGVuZGVkX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJhbGJ1bXMiLCJ2aWV3X29yZGVyIjoxMDIxMCwiYWxpYXNlcyI6WyJiYXNpY19leHRlbmRlZF9hbGJ1bSIsIm5leHRnZW5fYmFzaWNfZXh0ZW5kZWRfYWxidW0iLCJleHRlbmRlZF9hbGJ1bSJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2V4dGVuZGVkX2FsYnVtIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIyLjEuNjAiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZ2FsbGVyaWVzX3Blcl9wYWdlIjowLCJlbmFibGVfYnJlYWRjcnVtYnMiOjEsImRpc2FibGVfcGFnaW5hdGlvbiI6MCwiZW5hYmxlX2Rlc2NyaXB0aW9ucyI6MCwidGVtcGxhdGUiOiIiLCJvcGVuX2dhbGxlcnlfaW5fbGlnaHRib3giOjAsIm92ZXJyaWRlX3RodW1ibmFpbF9zZXR0aW5ncyI6MCwidGh1bWJuYWlsX3dpZHRoIjoyNDAsInRodW1ibmFpbF9oZWlnaHQiOjE2MCwidGh1bWJuYWlsX3F1YWxpdHkiOjEwMCwidGh1bWJuYWlsX2Nyb3AiOnRydWUsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJnYWxsZXJ5X2Rpc3BsYXlfdGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'NextGEN Basic Extended Album', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-12-01 06:32:54', '0000-00-00 00:00:00', 'eyJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgRXh0ZW5kZWQgQWxidW0iLCJlbnRpdHlfdHlwZXMiOlsiYWxidW0iLCJnYWxsZXJ5Il0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlxcbmV4dGdlbi1nYWxsZXJ5XFxwcm9kdWN0c1xccGhvdG9jcmF0aV9uZXh0Z2VuXFxtb2R1bGVzXFxuZXh0Z2VuX2Jhc2ljX2FsYnVtXFxzdGF0aWNcXGV4dGVuZGVkX3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJhbGJ1bXMiLCJ2aWV3X29yZGVyIjoxMDIxMCwiYWxpYXNlcyI6WyJiYXNpY19leHRlbmRlZF9hbGJ1bSIsIm5leHRnZW5fYmFzaWNfZXh0ZW5kZWRfYWxidW0iLCJleHRlbmRlZF9hbGJ1bSJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2V4dGVuZGVkX2FsYnVtIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIyLjEuNjAiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZ2FsbGVyaWVzX3Blcl9wYWdlIjowLCJlbmFibGVfYnJlYWRjcnVtYnMiOjEsImRpc2FibGVfcGFnaW5hdGlvbiI6MCwiZW5hYmxlX2Rlc2NyaXB0aW9ucyI6MCwidGVtcGxhdGUiOiIiLCJvcGVuX2dhbGxlcnlfaW5fbGlnaHRib3giOjAsIm92ZXJyaWRlX3RodW1ibmFpbF9zZXR0aW5ncyI6MCwidGh1bWJuYWlsX3dpZHRoIjoyNDAsInRodW1ibmFpbF9oZWlnaHQiOjE2MCwidGh1bWJuYWlsX3F1YWxpdHkiOjEwMCwidGh1bWJuYWlsX2Nyb3AiOnRydWUsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJnYWxsZXJ5X2Rpc3BsYXlfdGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIn0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=display_type&p=54', 0, 'display_type', '', 0),
(55, 1, '2016-12-01 06:39:46', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_gallery', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:39:46', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=55', 0, 'ngg_gallery', '', 0),
(56, 1, '2016-12-01 06:39:48', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:39:48', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=56', 0, 'ngg_pictures', '', 0),
(57, 1, '2016-12-01 06:39:50', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:39:50', '2016-12-01 06:39:50', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=57', 0, 'ngg_pictures', '', 0),
(58, 1, '2016-12-01 06:39:51', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_gallery', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:39:51', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=58', 0, 'ngg_gallery', '', 0),
(59, 1, '2016-12-01 06:39:54', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:39:54', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=59', 0, 'ngg_pictures', '', 0),
(60, 1, '2016-12-01 06:39:57', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:39:57', '2016-12-01 06:39:57', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=60', 0, 'ngg_pictures', '', 0),
(61, 1, '2016-12-01 06:40:00', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:40:00', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=61', 0, 'ngg_pictures', '', 0),
(62, 1, '2016-12-01 06:40:03', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:40:03', '2016-12-01 06:40:03', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=62', 0, 'ngg_pictures', '', 0),
(63, 1, '2016-12-01 06:40:09', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:40:09', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=63', 0, 'ngg_pictures', '', 0),
(64, 1, '2016-12-01 06:40:11', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:40:11', '2016-12-01 06:40:11', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=64', 0, 'ngg_pictures', '', 0);
INSERT INTO `tbl_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(65, 1, '2016-12-01 06:40:13', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:40:13', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=65', 0, 'ngg_pictures', '', 0),
(66, 1, '2016-12-01 06:40:14', '0000-00-00 00:00:00', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 'Untitled ngg_pictures', '', 'draft', 'closed', 'closed', '', 'mixin_nextgen_table_extras', '', '', '2016-12-01 06:40:14', '2016-12-01 06:40:14', 'eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=66', 0, 'ngg_pictures', '', 0),
(67, 1, '2016-12-01 06:42:20', '2016-12-01 06:42:20', '', '13662028_1109900409055524_5232681174920285749_o', '', 'inherit', 'open', 'closed', '', '13662028_1109900409055524_5232681174920285749_o', '', '', '2016-12-01 06:42:20', '2016-12-01 06:42:20', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13662028_1109900409055524_5232681174920285749_o.jpg', 0, 'attachment', 'image/jpeg', 0),
(68, 1, '2016-12-01 06:42:22', '2016-12-01 06:42:22', '', '13680665_1109900405722191_2777831404448902692_n', '', 'inherit', 'open', 'closed', '', '13680665_1109900405722191_2777831404448902692_n', '', '', '2016-12-01 06:42:22', '2016-12-01 06:42:22', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13680665_1109900405722191_2777831404448902692_n.jpg', 0, 'attachment', 'image/jpeg', 0),
(69, 1, '2016-12-01 06:42:24', '2016-12-01 06:42:24', '', '13697997_1109900402388858_7743577443761806408_o', '', 'inherit', 'open', 'closed', '', '13697997_1109900402388858_7743577443761806408_o', '', '', '2016-12-01 08:33:28', '2016-12-01 14:33:28', '', 80, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13697997_1109900402388858_7743577443761806408_o.jpg', 0, 'attachment', 'image/jpeg', 0),
(70, 1, '2016-12-01 06:42:26', '2016-12-01 06:42:26', '', '13767410_1109900399055525_2705110579242990808_o', '', 'inherit', 'open', 'closed', '', '13767410_1109900399055525_2705110579242990808_o', '', '', '2016-12-01 06:42:26', '2016-12-01 06:42:26', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13767410_1109900399055525_2705110579242990808_o.jpg', 0, 'attachment', 'image/jpeg', 0),
(71, 1, '2016-12-01 06:42:28', '2016-12-01 06:42:28', '', '13872769_1109900412388857_897054101226765220_n', '', 'inherit', 'open', 'closed', '', '13872769_1109900412388857_897054101226765220_n', '', '', '2016-12-01 06:42:28', '2016-12-01 06:42:28', '', 0, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13872769_1109900412388857_897054101226765220_n.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2016-12-01 00:54:47', '2016-12-01 06:54:47', '', 'Register', '', 'publish', 'closed', 'closed', '', 'register', '', '', '2016-12-01 00:54:47', '2016-12-01 06:54:47', '', 0, 'http://localhost:81/wp_mahmuds_pachal/register/', 0, 'page', '', 0),
(73, 1, '2016-12-01 00:54:47', '2016-12-01 06:54:47', ' ', '', '', 'publish', 'closed', 'closed', '', '73', '', '', '2016-12-01 08:36:54', '2016-12-01 14:36:54', '', 0, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/73/', 6, 'nav_menu_item', '', 0),
(74, 1, '2016-12-01 00:54:48', '2016-12-01 06:54:48', '', 'Activate', '', 'publish', 'closed', 'closed', '', 'activate', '', '', '2016-12-01 00:54:48', '2016-12-01 06:54:48', '', 0, 'http://localhost:81/wp_mahmuds_pachal/activate/', 0, 'page', '', 0),
(75, 1, '2016-12-01 00:54:49', '2016-12-01 06:54:49', ' ', '', '', 'publish', 'closed', 'closed', '', '75', '', '', '2016-12-01 08:36:54', '2016-12-01 14:36:54', '', 0, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/75/', 7, 'nav_menu_item', '', 0),
(76, 1, '2016-12-01 01:05:11', '2016-12-01 07:05:11', '[ngg_images source="galleries" container_ids="1" display_type="photocrati-nextgen_basic_slideshow" gallery_width="600" gallery_height="400" cycle_effect="fade" cycle_interval="10" show_thumbnail_link="1" thumbnail_link_text="[Show thumbnails]" order_by="sortorder" order_direction="ASC" returns="included" maximum_entity_count="500"]\r\n<a href="http://localhost:81/wp_mahmuds_pachal/about/">View My Profile</a>\r\n<h3>Welcome to my Blog . You can view all of &nbsp;my writings, favorite news and tutorials.</h3>\r\n<h3>আমার ব্লগে সবাইকে স্বাগতম । এখান থেকে আমার লেখা, প্রিয় সংবাদ এবং টিউটোরিয়াল দেখা যাবে ।</h3>', 'Welcome', '', 'publish', 'closed', 'closed', '', 'welcome', '', '', '2016-12-01 12:02:21', '2016-12-01 18:02:21', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?page_id=76', 0, 'page', '', 0),
(77, 1, '2016-12-01 01:05:11', '2016-12-01 07:05:11', ' ', '', '', 'publish', 'closed', 'closed', '', '77', '', '', '2016-12-01 08:36:54', '2016-12-01 14:36:54', '', 0, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/77/', 1, 'nav_menu_item', '', 0),
(78, 1, '2016-12-01 01:05:11', '2016-12-01 07:05:11', '[ngg_images source="galleries" container_ids="1" display_type="photocrati-nextgen_basic_slideshow" gallery_width="600" gallery_height="400" cycle_effect="fade" cycle_interval="10" show_thumbnail_link="1" thumbnail_link_text="[Show thumbnails]" order_by="sortorder" order_direction="ASC" returns="included" maximum_entity_count="500"]Welcome to my Blog . You can view all of &nbsp;my writings, favorite news and tutorials.\r\n\r\nআমার ব্লগে সবাইকে স্বাগতম । এখান থেকে আমার লেখা, প্রিয় সংবাদ এবং টিউটোরিয়াল দেখা যাবে ।', 'Welcome', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2016-12-01 01:05:11', '2016-12-01 07:05:11', '', 76, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/76-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2016-12-01 08:34:21', '2016-12-01 14:34:21', '<div id="topheader" class="panel-heading">\r\n<div class="row-fluid">\r\n<div class="col-lg-5 span5">\r\n<h3 id="headerAJS" class="fa fa-2x">Developed&nbsp;By :-</h3>\r\n</div>\r\n<div class="col-lg-7 span7">&nbsp;<img class="aligncenter size-medium wp-image-69" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13697997_1109900402388858_7743577443761806408_o-300x300.jpg" alt="13697997_1109900402388858_7743577443761806408_o" width="300" height="300"></div>\r\n</div>\r\n</div>\r\n<div id="row1" class="panel-body">\r\n<div class="row-fluid">\r\n<div class="col-lg-4 span4">&nbsp;</div>\r\n<div class="col-lg-8 span8">\r\n<table class="table table-responsive table-bordered table-condensed table-striped table-hover">\r\n<tbody>\r\n<tr>\r\n<td><span class="fa"><strong>Name</strong></span></td>\r\n<td>:</td>\r\n<td><span class="fa fa-2x"><i>MAHMUDUL HASAN KHAN</i></span></td>\r\n</tr>\r\n<tr>\r\n<td><span class="fa"><strong>Email</strong></span></td>\r\n<td>:</td>\r\n<td><span class="fa">cse.mahmudul@gmail.com</span>, <span class="fa">hasan417@diu.edu.bd</span></td>\r\n</tr>\r\n<tr>\r\n<td><span class="fa"><strong>Phone</strong></span></td>\r\n<td>:</td>\r\n<td><span class="fa">+8801879995812</span></td>\r\n</tr>\r\n<tr>\r\n<td><span class="fa"><strong>Address</strong></span></td>\r\n<td>:</td>\r\n<td><span class="fa">New-Market City Complex, C – Tower, Floor no:- 12, Flat no:- 12/C-1, Biswas Builders Limited, 44/1 Rahim Square, New-Market, Dhaka :- 1205, Bangladesh</span></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>\r\n<div id="row2" class="panel-body">\r\n<div class="row-fluid">\r\n<div class="span12">\r\n<h3>Skills :</h3>\r\n<ol class="skills">\r\n 	<li>ASP.Net,</li>\r\n 	<li>PHP CodeIgniter Framework,</li>\r\n 	<li>UML,</li>\r\n 	<li>Basic Concept About SDLC,</li>\r\n 	<li>JAVA SE,</li>\r\n 	<li>C++</li>\r\n</ol>\r\n</div>\r\n</div>\r\n</div>\r\n<div id="row3" class="box panel-body sortable">\r\n<div class="box row-fluid sortable">\r\n<div class="box-content span12">\r\n<h3><span class="fa">Academic Qualification</span></h3>\r\n<table class="table table-responsive table-bordered table-condensed table-striped table-hover">\r\n<tbody>\r\n<tr>\r\n<th>Degree</th>\r\n<th>Institute</th>\r\n<th>CGPA</th>\r\n<th>Pass. Year</th>\r\n<th>Duration</th>\r\n</tr>\r\n<tr>\r\n<td><abbr title="Master of Science">M.Sc. </abbr>in <abbr title="Computer Science &amp; Engineering">CSE</abbr></td>\r\n<td><a href="http://www.daffodilvarsity.edu.bd/" target="_blank">Daffodil International University</a></td>\r\n<td>3.96 out of 4.0</td>\r\n<td>2015</td>\r\n<td>1 year ( 36 credits )</td>\r\n</tr>\r\n<tr>\r\n<td><abbr title="Bachelor of Science in Engineering">B.Sc.(Engg.) </abbr>in <abbr title="Computer Science &amp; Engineering">CSE</abbr></td>\r\n<td><a href="http://mbstu.ac.bd/index.html" target="_blank">Mawlana Bhashani Science &amp; Technology University</a></td>\r\n<td>3.28 out of 4.0</td>\r\n<td>2014</td>\r\n<td>4 years ( 160 credits )</td>\r\n</tr>\r\n<tr>\r\n<td><abbr title="Higher Secondary School Certificate">H.S.C. </abbr>( Science Group )</td>\r\n<td>Udayan Uchcha Madhyamik Bidyalay</td>\r\n<td>4.60 out of 5.0</td>\r\n<td>2007</td>\r\n<td>2 years</td>\r\n</tr>\r\n<tr>\r\n<td><abbr title="Secondary School Certificate">S.S.C. </abbr>( Science Group )</td>\r\n<td>Udayan Bidyalaya</td>\r\n<td>5.0 out of 5.0</td>\r\n<td>2005</td>\r\n<td>10 years</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>\r\n<div id="row4" class="box panel-body sortable">\r\n<div class="box row-fluid sortable">\r\n<div class="box-content span12">\r\n<h3><span class="fa">Training Summary</span></h3>\r\n<table class="table table-responsive table-bordered table-condensed table-striped table-hover">\r\n<tbody>\r\n<tr>\r\n<th>Training Title</th>\r\n<th>Topic</th>\r\n<th>Institute</th>\r\n<th>Location</th>\r\n<th>Year</th>\r\n<th>Duration</th>\r\n</tr>\r\n<tr>\r\n<td>Object Oriented Programming (OOP) - ASP.Net (C#) Track (43rd Batch)</td>\r\n<td>OOP, C#, ASP.Net and ASP.Net with MVC</td>\r\n<td><abbr title="Bangladesh Institute of Technology &amp; Management"><a href="https://www.facebook.com/pages/BITM/532151840156223" target="_blank">BITM </a></abbr>under<abbr title="Bangladesh Association of Software and Information Service"><a href="http://www.basis.org.bd/" target="_blank">BASIS</a></abbr></td>\r\n<td>12, Kawran-Bazar, Dhaka-1215, Bangladesh</td>\r\n<td>2013</td>\r\n<td>150 Hours</td>\r\n</tr>\r\n<tr>\r\n<td>OOP (MVC) PHP with CodeIgniter Framework (Batch:12)</td>\r\n<td>HTML 5, CSS 3, PHP, CodeIgniter Framework</td>\r\n<td><abbr title="Bangladesh Institute of Technology &amp; Management"><a href="https://www.facebook.com/pages/BITM/532151840156223" target="_blank">BITM </a></abbr>under<abbr title="Bangladesh Association of Software and Information Service"><a href="http://www.basis.org.bd/" target="_blank">BASIS</a></abbr></td>\r\n<td>12, Kawran-Bazar, Dhaka-1215, Bangladesh</td>\r\n<td>2014</td>\r\n<td>120 Hours</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2016-12-01 08:34:21', '2016-12-01 14:34:21', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?page_id=80', 0, 'page', '', 0),
(81, 1, '2016-12-01 08:34:21', '2016-12-01 14:34:21', ' ', '', '', 'publish', 'closed', 'closed', '', '81', '', '', '2016-12-01 08:36:54', '2016-12-01 14:36:54', '', 0, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/81/', 5, 'nav_menu_item', '', 0),
(82, 1, '2016-12-01 08:34:21', '2016-12-01 14:34:21', '<div id="topheader" class="panel-heading">\r\n<div class="row-fluid">\r\n<div class="col-lg-5 span5">\r\n<h3 id="headerAJS" class="fa fa-2x">Developed&nbsp;By :-</h3>\r\n</div>\r\n<div class="col-lg-7 span7">&nbsp;<img class="aligncenter size-medium wp-image-69" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/13697997_1109900402388858_7743577443761806408_o-300x300.jpg" alt="13697997_1109900402388858_7743577443761806408_o" width="300" height="300"></div>\r\n</div>\r\n</div>\r\n<div id="row1" class="panel-body">\r\n<div class="row-fluid">\r\n<div class="col-lg-4 span4">&nbsp;</div>\r\n<div class="col-lg-8 span8">\r\n<table class="table table-responsive table-bordered table-condensed table-striped table-hover">\r\n<tbody>\r\n<tr>\r\n<td><span class="fa"><strong>Name</strong></span></td>\r\n<td>:</td>\r\n<td><span class="fa fa-2x"><i>MAHMUDUL HASAN KHAN</i></span></td>\r\n</tr>\r\n<tr>\r\n<td><span class="fa"><strong>Email</strong></span></td>\r\n<td>:</td>\r\n<td><span class="fa">cse.mahmudul@gmail.com</span>, <span class="fa">hasan417@diu.edu.bd</span></td>\r\n</tr>\r\n<tr>\r\n<td><span class="fa"><strong>Phone</strong></span></td>\r\n<td>:</td>\r\n<td><span class="fa">+8801879995812</span></td>\r\n</tr>\r\n<tr>\r\n<td><span class="fa"><strong>Address</strong></span></td>\r\n<td>:</td>\r\n<td><span class="fa">New-Market City Complex, C – Tower, Floor no:- 12, Flat no:- 12/C-1, Biswas Builders Limited, 44/1 Rahim Square, New-Market, Dhaka :- 1205, Bangladesh</span></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>\r\n<div id="row2" class="panel-body">\r\n<div class="row-fluid">\r\n<div class="span12">\r\n<h3>Skills :</h3>\r\n<ol class="skills">\r\n 	<li>ASP.Net,</li>\r\n 	<li>PHP CodeIgniter Framework,</li>\r\n 	<li>UML,</li>\r\n 	<li>Basic Concept About SDLC,</li>\r\n 	<li>JAVA SE,</li>\r\n 	<li>C++</li>\r\n</ol>\r\n</div>\r\n</div>\r\n</div>\r\n<div id="row3" class="box panel-body sortable">\r\n<div class="box row-fluid sortable">\r\n<div class="box-content span12">\r\n<h3><span class="fa">Academic Qualification</span></h3>\r\n<table class="table table-responsive table-bordered table-condensed table-striped table-hover">\r\n<tbody>\r\n<tr>\r\n<th>Degree</th>\r\n<th>Institute</th>\r\n<th>CGPA</th>\r\n<th>Pass. Year</th>\r\n<th>Duration</th>\r\n</tr>\r\n<tr>\r\n<td><abbr title="Master of Science">M.Sc. </abbr>in <abbr title="Computer Science &amp; Engineering">CSE</abbr></td>\r\n<td><a href="http://www.daffodilvarsity.edu.bd/" target="_blank">Daffodil International University</a></td>\r\n<td>3.96 out of 4.0</td>\r\n<td>2015</td>\r\n<td>1 year ( 36 credits )</td>\r\n</tr>\r\n<tr>\r\n<td><abbr title="Bachelor of Science in Engineering">B.Sc.(Engg.) </abbr>in <abbr title="Computer Science &amp; Engineering">CSE</abbr></td>\r\n<td><a href="http://mbstu.ac.bd/index.html" target="_blank">Mawlana Bhashani Science &amp; Technology University</a></td>\r\n<td>3.28 out of 4.0</td>\r\n<td>2014</td>\r\n<td>4 years ( 160 credits )</td>\r\n</tr>\r\n<tr>\r\n<td><abbr title="Higher Secondary School Certificate">H.S.C. </abbr>( Science Group )</td>\r\n<td>Udayan Uchcha Madhyamik Bidyalay</td>\r\n<td>4.60 out of 5.0</td>\r\n<td>2007</td>\r\n<td>2 years</td>\r\n</tr>\r\n<tr>\r\n<td><abbr title="Secondary School Certificate">S.S.C. </abbr>( Science Group )</td>\r\n<td>Udayan Bidyalaya</td>\r\n<td>5.0 out of 5.0</td>\r\n<td>2005</td>\r\n<td>10 years</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>\r\n<div id="row4" class="box panel-body sortable">\r\n<div class="box row-fluid sortable">\r\n<div class="box-content span12">\r\n<h3><span class="fa">Training Summary</span></h3>\r\n<table class="table table-responsive table-bordered table-condensed table-striped table-hover">\r\n<tbody>\r\n<tr>\r\n<th>Training Title</th>\r\n<th>Topic</th>\r\n<th>Institute</th>\r\n<th>Location</th>\r\n<th>Year</th>\r\n<th>Duration</th>\r\n</tr>\r\n<tr>\r\n<td>Object Oriented Programming (OOP) - ASP.Net (C#) Track (43rd Batch)</td>\r\n<td>OOP, C#, ASP.Net and ASP.Net with MVC</td>\r\n<td><abbr title="Bangladesh Institute of Technology &amp; Management"><a href="https://www.facebook.com/pages/BITM/532151840156223" target="_blank">BITM </a></abbr>under<abbr title="Bangladesh Association of Software and Information Service"><a href="http://www.basis.org.bd/" target="_blank">BASIS</a></abbr></td>\r\n<td>12, Kawran-Bazar, Dhaka-1215, Bangladesh</td>\r\n<td>2013</td>\r\n<td>150 Hours</td>\r\n</tr>\r\n<tr>\r\n<td>OOP (MVC) PHP with CodeIgniter Framework (Batch:12)</td>\r\n<td>HTML 5, CSS 3, PHP, CodeIgniter Framework</td>\r\n<td><abbr title="Bangladesh Institute of Technology &amp; Management"><a href="https://www.facebook.com/pages/BITM/532151840156223" target="_blank">BITM </a></abbr>under<abbr title="Bangladesh Association of Software and Information Service"><a href="http://www.basis.org.bd/" target="_blank">BASIS</a></abbr></td>\r\n<td>12, Kawran-Bazar, Dhaka-1215, Bangladesh</td>\r\n<td>2014</td>\r\n<td>120 Hours</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>', 'About', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2016-12-01 08:34:21', '2016-12-01 14:34:21', '', 80, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/80-revision-v1/', 0, 'revision', '', 0),
(83, 2, '2016-12-01 09:17:16', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-12-01 09:17:16', '0000-00-00 00:00:00', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=83', 0, 'post', '', 0),
(84, 3, '2016-12-01 09:18:10', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-12-01 09:18:10', '0000-00-00 00:00:00', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=84', 0, 'post', '', 0),
(85, 4, '2016-12-01 09:18:50', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-12-01 09:18:50', '0000-00-00 00:00:00', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=85', 0, 'post', '', 0),
(86, 1, '2016-12-01 11:58:37', '2016-12-01 17:58:37', '[ngg_images source="galleries" container_ids="1" display_type="photocrati-nextgen_basic_slideshow" gallery_width="600" gallery_height="400" cycle_effect="fade" cycle_interval="10" show_thumbnail_link="1" thumbnail_link_text="[Show thumbnails]" order_by="sortorder" order_direction="ASC" returns="included" maximum_entity_count="500"]\n<h1>Welcome to my Blog . You can view all of &nbsp;my writings, favorite news and tutorials.</h1>\n\n<h1>আমার ব্লগে সবাইকে স্বাগতম । এখান থেকে আমার লেখা, প্রিয় সংবাদ এবং টিউটোরিয়াল দেখা যাবে ।</1', 'Welcome', '', 'inherit', 'closed', 'closed', '', '76-autosave-v1', '', '', '2016-12-01 11:58:37', '2016-12-01 17:58:37', '', 76, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/76-autosave-v1/', 0, 'revision', '', 0),
(87, 1, '2016-12-01 11:59:43', '2016-12-01 17:59:43', '[ngg_images source="galleries" container_ids="1" display_type="photocrati-nextgen_basic_slideshow" gallery_width="600" gallery_height="400" cycle_effect="fade" cycle_interval="10" show_thumbnail_link="1" thumbnail_link_text="[Show thumbnails]" order_by="sortorder" order_direction="ASC" returns="included" maximum_entity_count="500"]\r\n<h1>Welcome to my Blog . You can view all of &nbsp;my writings, favorite news and tutorials.</h1>\r\n<h1>আমার ব্লগে সবাইকে স্বাগতম । এখান থেকে আমার লেখা, প্রিয় সংবাদ এবং টিউটোরিয়াল দেখা যাবে ।</h1>\r\n<a href="http://localhost:81/wp_mahmuds_pachal/about/">View My Profile</a>', 'Welcome', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2016-12-01 11:59:43', '2016-12-01 17:59:43', '', 76, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/76-revision-v1/', 0, 'revision', '', 0),
(88, 1, '2016-12-01 12:00:28', '2016-12-01 18:00:28', '[ngg_images source="galleries" container_ids="1" display_type="photocrati-nextgen_basic_slideshow" gallery_width="600" gallery_height="400" cycle_effect="fade" cycle_interval="10" show_thumbnail_link="1" thumbnail_link_text="[Show thumbnails]" order_by="sortorder" order_direction="ASC" returns="included" maximum_entity_count="500"]\r\n<a href="http://localhost:81/wp_mahmuds_pachal/about/">View My Profile</a>\r\n<h1>Welcome to my Blog . You can view all of &nbsp;my writings, favorite news and tutorials.</h1>\r\n<h1>আমার ব্লগে সবাইকে স্বাগতম । এখান থেকে আমার লেখা, প্রিয় সংবাদ এবং টিউটোরিয়াল দেখা যাবে ।</h1>', 'Welcome', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2016-12-01 12:00:28', '2016-12-01 18:00:28', '', 76, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/76-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2016-12-01 12:02:21', '2016-12-01 18:02:21', '[ngg_images source="galleries" container_ids="1" display_type="photocrati-nextgen_basic_slideshow" gallery_width="600" gallery_height="400" cycle_effect="fade" cycle_interval="10" show_thumbnail_link="1" thumbnail_link_text="[Show thumbnails]" order_by="sortorder" order_direction="ASC" returns="included" maximum_entity_count="500"]\r\n<a href="http://localhost:81/wp_mahmuds_pachal/about/">View My Profile</a>\r\n<h3>Welcome to my Blog . You can view all of &nbsp;my writings, favorite news and tutorials.</h3>\r\n<h3>আমার ব্লগে সবাইকে স্বাগতম । এখান থেকে আমার লেখা, প্রিয় সংবাদ এবং টিউটোরিয়াল দেখা যাবে ।</h3>', 'Welcome', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2016-12-01 12:02:21', '2016-12-01 18:02:21', '', 76, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/76-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2016-12-01 12:11:13', '2016-12-01 18:11:13', '', 'CALENDAR 1', '', 'publish', 'closed', 'closed', '', 'calendar-1', '', '', '2016-12-01 12:11:13', '2016-12-01 18:11:13', '', 0, 'http://localhost:81/wp_mahmuds_pachal/ecwd_calendar/calendar-1/', 0, 'ecwd_calendar', '', 0),
(91, 1, '2016-12-01 12:11:22', '2016-12-01 18:11:22', '', 'VENUE 1', '', 'publish', 'closed', 'closed', '', 'venue-1', '', '', '2016-12-01 12:11:22', '2016-12-01 18:11:22', '', 0, 'http://localhost:81/wp_mahmuds_pachal/venue/venue-1/', 0, 'ecwd_venue', '', 0),
(92, 1, '2016-12-01 12:11:24', '2016-12-01 18:11:24', '', 'ORGANIZER 1', '', 'publish', 'closed', 'closed', '', 'organizer-1', '', '', '2016-12-01 12:11:24', '2016-12-01 18:11:24', '', 0, 'http://localhost:81/wp_mahmuds_pachal/organizer/organizer-1/', 0, 'ecwd_organizer', '', 0),
(93, 1, '2016-12-01 12:11:26', '2016-12-01 18:11:26', '', 'ORGANIZER 2', '', 'publish', 'closed', 'closed', '', 'organizer-2', '', '', '2016-12-01 12:11:26', '2016-12-01 18:11:26', '', 0, 'http://localhost:81/wp_mahmuds_pachal/organizer/organizer-2/', 0, 'ecwd_organizer', '', 0),
(94, 1, '2016-12-01 12:11:27', '2016-12-01 18:11:27', '', 'EVENT 1', '', 'publish', 'closed', 'closed', '', 'event-1', '', '', '2016-12-01 12:11:27', '2016-12-01 18:11:27', '', 0, 'http://localhost:81/wp_mahmuds_pachal/event/event-1/', 0, 'ecwd_event', '', 0),
(95, 1, '2016-12-01 12:11:35', '2016-12-01 18:11:35', '', 'EVENT 2', '', 'publish', 'closed', 'closed', '', 'event-2', '', '', '2016-12-01 12:11:35', '2016-12-01 18:11:35', '', 0, 'http://localhost:81/wp_mahmuds_pachal/event/event-2/', 0, 'ecwd_event', '', 0),
(96, 1, '2016-12-01 12:13:48', '2016-12-01 18:13:48', '', 'Archives Date', '', 'publish', 'closed', 'closed', '', 'archives-date', '', '', '2016-12-01 12:13:48', '2016-12-01 18:13:48', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?post_type=ecwd_calendar&#038;p=96', 0, 'ecwd_calendar', '', 0),
(97, 2, '2016-12-01 13:18:59', '2016-12-01 19:18:59', '<img class="alignnone size-medium wp-image-103" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/e44e8b9dd2fad481529192093124067f-nasa-europa-300x187.jpg" alt="e44e8b9dd2fad481529192093124067f-nasa-europa" width="300" height="187" />\r\n\r\nমার্কিন মহাকাশ গবেষণা সংস্থা নাসার বিজ্ঞানীরা শিগগিরই নতুন একটি ‘চমক’ হাজির করতে যাচ্ছেন। এমন আভাস দিয়ে বলা হচ্ছে, এ চমক হতে পারে আমাদের এই সৌরজগতে এলিয়েন বা ভিনগ্রহের প্রাণীর গতিবিধি আবিষ্কারের তথ্য।<!--more-->\r\nবৃহস্পতির চাঁদ ইউরোপার ছবি বিশ্লেষণ করে নাসার গবেষকেরা আসছে সোমবার নাগাদ ওই উপগ্রহপৃষ্ঠের নিচে থাকা সমুদ্র সম্পর্কে তথ্য জানাতে পারেন। ১ হাজার ৯০০ মাইল প্রশস্ত এই উপগ্রহের বরফাছাওয়া খোলসের নিচে বিশাল সমুদ্র থাকতে পারে বলে মনে করছেন গবেষকেরা। এই সমুদ্র গবেষকেদের আরও বেশি আকৃষ্ট করছে ইউরোপার পাথুরে আবরণ। যার মধ্যে রাসায়নিক বিক্রিয়া ঘটানোর মতো উপাদান থাকতে পারে।\r\nহাবল টেলিস্কোপ ব্যবহার করে ইউরোপার নতুন এই ছবিগুলো তোলা হয়েছে। এর পাশাপাশি ইউরোপার রহস্য উদ্‌ঘাটনে সেখানে নভোযান পাঠানোর পরিকল্পনা নিয়ে কাজ করছেন গবেষকেরা। ওই মিশনে নভোযান ১ হাজার ৭০০ মাইল থেকে শুরু করে ১৬ মাইল উচ্চতায় ৪৫ বার ইউরোপাকে চক্কর দেবে। ওই মিশনের ফলেই ইউরোপার বর্তমান অবস্থার কথা জানা যাবে।\r\nগত মে মাসে নাসার প্লানেটারি ভূপ্রকৃতিবিদ স্টিভ ভ্যান্স বলেন, পৃথিবীর মতোই ইউরোপার সমুদ্রে অক্সিজেন ও হাইড্রোজেন চক্র সেখানকার সামুদ্রিক রসায়ন ও সেখানকার সম্ভাব্য জীবনের জন্য মূল চালিকা রূপ হতে পারে। তথ্যসূত্র: আইবিটাইমস', 'নাসার নতুন ‘চমক’ কি এলিয়েন?', '', 'publish', 'open', 'open', '', '%e0%a6%a8%e0%a6%be%e0%a6%b8%e0%a6%be%e0%a6%b0-%e0%a6%a8%e0%a6%a4%e0%a7%81%e0%a6%a8-%e0%a6%9a%e0%a6%ae%e0%a6%95-%e0%a6%95%e0%a6%bf-%e0%a6%8f%e0%a6%b2%e0%a6%bf%e0%a7%9f%e0%a7%87', '', '', '2016-12-01 23:25:58', '2016-12-02 05:25:58', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=97', 0, 'post', '', 1),
(98, 2, '2016-12-01 12:59:30', '2016-12-01 18:59:30', 'মার্কিন মহাকাশ গবেষণা সংস্থা নাসার বিজ্ঞানীরা শিগগিরই নতুন একটি ‘চমক’ হাজির করতে যাচ্ছেন। এমন আভাস দিয়ে বলা হচ্ছে, এ চমক হতে পারে আমাদের এই সৌরজগতে এলিয়েন বা ভিনগ্রহের প্রাণীর গতিবিধি আবিষ্কারের তথ্য।\r\nবৃহস্পতির চাঁদ ইউরোপার ছবি বিশ্লেষণ করে নাসার গবেষকেরা আসছে সোমবার নাগাদ ওই উপগ্রহপৃষ্ঠের নিচে থাকা সমুদ্র সম্পর্কে তথ্য জানাতে পারেন। ১ হাজার ৯০০ মাইল প্রশস্ত এই উপগ্রহের বরফাছাওয়া খোলসের নিচে বিশাল সমুদ্র থাকতে পারে বলে মনে করছেন গবেষকেরা। এই সমুদ্র গবেষকেদের আরও বেশি আকৃষ্ট করছে ইউরোপার পাথুরে আবরণ। যার মধ্যে রাসায়নিক বিক্রিয়া ঘটানোর মতো উপাদান থাকতে পারে।\r\nহাবল টেলিস্কোপ ব্যবহার করে ইউরোপার নতুন এই ছবিগুলো তোলা হয়েছে। এর পাশাপাশি ইউরোপার রহস্য উদ্‌ঘাটনে সেখানে নভোযান পাঠানোর পরিকল্পনা নিয়ে কাজ করছেন গবেষকেরা। ওই মিশনে নভোযান ১ হাজার ৭০০ মাইল থেকে শুরু করে ১৬ মাইল উচ্চতায় ৪৫ বার ইউরোপাকে চক্কর দেবে। ওই মিশনের ফলেই ইউরোপার বর্তমান অবস্থার কথা জানা যাবে।\r\nগত মে মাসে নাসার প্লানেটারি ভূপ্রকৃতিবিদ স্টিভ ভ্যান্স বলেন, পৃথিবীর মতোই ইউরোপার সমুদ্রে অক্সিজেন ও হাইড্রোজেন চক্র সেখানকার সামুদ্রিক রসায়ন ও সেখানকার সম্ভাব্য জীবনের জন্য মূল চালিকা রূপ হতে পারে। তথ্যসূত্র: আইবিটাইমস', 'নাসার নতুন ‘চমক’ কি এলিয়েন?', '', 'inherit', 'closed', 'closed', '', '97-revision-v1', '', '', '2016-12-01 12:59:30', '2016-12-01 18:59:30', '', 97, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/97-revision-v1/', 0, 'revision', '', 0),
(99, 3, '2016-12-01 13:04:27', '2016-12-01 19:04:27', '', '1pes12-android', '', 'inherit', 'open', 'closed', '', '1pes12-android', '', '', '2016-12-01 13:50:43', '2016-12-01 19:50:43', '', 120, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/1pes12-android.png', 0, 'attachment', 'image/png', 0),
(100, 3, '2016-12-01 13:04:30', '2016-12-01 19:04:30', '', '753ae8936f3768920a6b6fa235603507-7', '', 'inherit', 'open', 'closed', '', '753ae8936f3768920a6b6fa235603507-7', '', '', '2016-12-01 13:25:42', '2016-12-01 19:25:42', '', 117, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/753ae8936f3768920a6b6fa235603507-7.jpg', 0, 'attachment', 'image/jpeg', 0),
(101, 3, '2016-12-01 13:04:32', '2016-12-01 19:04:32', '', 'a85e33a58106a8db419e7cb8145c4696-untitled-17', '', 'inherit', 'open', 'closed', '', 'a85e33a58106a8db419e7cb8145c4696-untitled-17', '', '', '2016-12-01 13:08:48', '2016-12-01 19:08:48', '', 114, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/a85e33a58106a8db419e7cb8145c4696-Untitled-17.jpg', 0, 'attachment', 'image/jpeg', 0),
(102, 3, '2016-12-01 13:04:33', '2016-12-01 19:04:33', '', 'amazing-spiderman-galaxy-s3', '', 'inherit', 'open', 'closed', '', 'amazing-spiderman-galaxy-s3', '', '', '2016-12-01 13:53:34', '2016-12-01 19:53:34', '', 120, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/amazing-spiderman-galaxy-s3.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 3, '2016-12-01 13:04:36', '2016-12-01 19:04:36', '', 'e44e8b9dd2fad481529192093124067f-nasa-europa', '', 'inherit', 'open', 'closed', '', 'e44e8b9dd2fad481529192093124067f-nasa-europa', '', '', '2016-12-01 13:18:52', '2016-12-01 19:18:52', '', 97, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/e44e8b9dd2fad481529192093124067f-nasa-europa.jpg', 0, 'attachment', 'image/jpeg', 0),
(104, 3, '2016-12-01 13:04:37', '2016-12-01 19:04:37', '', 'grand-theft-auto-iii-screenshot', '', 'inherit', 'open', 'closed', '', 'grand-theft-auto-iii-screenshot', '', '', '2016-12-01 13:46:39', '2016-12-01 19:46:39', '', 120, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Grand-Theft-Auto-III-screenshot.jpg', 0, 'attachment', 'image/jpeg', 0),
(105, 3, '2016-12-01 13:04:40', '2016-12-01 19:04:40', '', 'modern-combat-4-zero-hour-screen1', '', 'inherit', 'open', 'closed', '', 'modern-combat-4-zero-hour-screen1', '', '', '2016-12-01 13:34:10', '2016-12-01 19:34:10', '', 119, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/modern-combat-4-zero-hour-screen1.jpg', 0, 'attachment', 'image/jpeg', 0),
(106, 3, '2016-12-01 13:04:42', '2016-12-01 19:04:42', '', 'n-o-v-a-3-screenshot', '', 'inherit', 'open', 'closed', '', 'n-o-v-a-3-screenshot', '', '', '2016-12-01 13:49:13', '2016-12-01 19:49:13', '', 120, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/N.O.V.A.-3-screenshot.jpg', 0, 'attachment', 'image/jpeg', 0),
(108, 3, '2016-12-01 13:04:45', '2016-12-01 19:04:45', '', 'the-dark-knight-rises-galaxy-s3', '', 'inherit', 'open', 'closed', '', 'the-dark-knight-rises-galaxy-s3', '', '', '2016-12-01 13:45:26', '2016-12-01 19:45:26', '', 120, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/The-Dark-Knight-Rises-galaxy-s3.jpg', 0, 'attachment', 'image/jpeg', 0),
(109, 3, '2016-12-01 13:04:50', '2016-12-01 19:04:50', '', 'unnamed-1', '', 'inherit', 'open', 'closed', '', 'unnamed-1', '', '', '2016-12-01 13:52:17', '2016-12-01 19:52:17', '', 120, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(110, 3, '2016-12-01 13:04:52', '2016-12-01 19:04:52', '', 'unnamed', '', 'inherit', 'open', 'closed', '', 'unnamed', '', '', '2016-12-01 13:47:28', '2016-12-01 19:47:28', '', 120, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed.jpg', 0, 'attachment', 'image/jpeg', 0),
(111, 3, '2016-12-01 13:04:54', '2016-12-01 19:04:54', '', 'wild-blood-apk-download', '', 'inherit', 'open', 'closed', '', 'wild-blood-apk-download', '', '', '2016-12-01 13:48:13', '2016-12-01 19:48:13', '', 120, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Wild-Blood-apk-download.jpg', 0, 'attachment', 'image/jpeg', 0),
(113, 3, '2016-12-01 13:07:13', '2016-12-01 19:07:13', '', 'need-for-speed-most-wanted-screens', '', 'inherit', 'open', 'closed', '', 'need-for-speed-most-wanted-screens', '', '', '2016-12-01 13:49:49', '2016-12-01 19:49:49', '', 120, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Need-for-Speed-Most-Wanted-screens.jpg', 0, 'attachment', 'image/jpeg', 0),
(114, 3, '2016-12-01 13:13:45', '2016-12-01 19:13:45', '<img class="alignnone size-medium wp-image-101" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/a85e33a58106a8db419e7cb8145c4696-Untitled-17-300x264.jpg" alt="a85e33a58106a8db419e7cb8145c4696-untitled-17" width="300" height="264" />\r\n\r\nপ্রথম সপ্তাহেই মারভেলের ছবি <em>ডক্টর স্ট্রেঞ্জ </em>যুক্তরাষ্ট্রেরবক্স অফিসে সাড়ে আট কোটি ডলারেরও বেশি আয় করেছে। নয় অঙ্কের যুগে এ সাফল্য কম মনে হতে পারে, কিন্তু এই নভেম্বরে মুক্তি পাওয়া ছবির জন্য এ সাফল্য বেশ বড়ই। মার্কিনরা এখন ব্যস্ত প্রেসিডেন্ট নির্বাচন নিয়ে, সিনেমা দেখা এখন অগ্রাধিকারের তালিকায় নেই। তাঁদের এবারের নির্বাচনই তো সিনেমাটিক উপাদানে ভরপুর!<!--more-->\r\n<p class="TEXT">তার ওপর এটি চিরাচরিত সুপারহিরো ছবিও নয়। মারভেলের এই কমিক বই সিরিজ তাদের অন্য সুপারহিরোদের মতো সুপরিচিত নয়। সে হিসেবে <em>ডক্টর স্ট্রেঞ্জ </em>শুধুবক্স অফিসের প্রত্যাশা বেশ ভালোভাবেই মিটিয়েছে। সিনেমা রেটিংয়ের সাইট রোটেন টমেটোসে দেখা যাচ্ছে, শীর্ষ চলচ্চিত্র সমালোচকদের মধ্যে ৮৭ ভাগ এ ছবি পছন্দ করেছেন।</p>\r\n<p class="TEXT">এই সাফল্যের অনেকটা কৃতিত্ব বেনেডিক্ট কাম্বারব্যাচকে দেওয়া যেতেই পারে। শার্লক হোমস চরিত্রে অভিনয় করে তুমুল জনপ্রিয়তা পাওয়া এ অভিনেতাই এই ছবির ডক্টর স্ট্রেঞ্জ। তাঁর অভিনয় সমালোচকদেরও প্রশংসা কুড়িয়েছে। খল অভিনেতার চরিত্রে শিওটেল এজিওফরও দারুণ অভিনয় করেছেন। বলা হচ্ছে, <em>থর </em>ছবির লোকির (টম হিডলস্টোন অভিনয় করেছিলেন এ চরিত্রে) পর আর কোনো ভিলেন এমন করে দর্শক ও সমালোচক হৃদয় জয় করতে পারেননি।</p>\r\n<p class="TEXT">এই ছবির সাফল্য আরও প্রমাণ করছে হলিউডে ভিন্নধর্মী সুপারহিরোর ছবির কদর বাড়ছে। <em>ব্যাটম্যান</em>, <em>সুপারম্যান</em>, <em>আয়রনম্যান</em>-এর মতো ভরপুর অ্যাকশন ও অতিমানবিক সুপারহিরোদের দর্শকেরা আর পছন্দ করছেন না। <em>ডক্টর স্ট্রেঞ্জ</em>-এ অস্ত্রের ঝনঝনানি নেই, অন্য মারভেল ছবির মতো শেষ দৃশ্যে নায়ক-খলনায়কের মারামারিতে একটি গোটা শহর ধ্বংসস্তূপে পরিণত হয় না। ছবিতে পৃথিবীর অন্য দিক উন্মোচিত হয় দর্শকের সামনে।</p>\r\n<p class="TEXT">২০১৫ সালে <em>অ্যান্ট-ম্যান </em>নামের আরেকটি ভিন্নধর্মী হলিউড ছবিও বক্স অফিসে সাফল্য পেয়েছিল। <em>ডক্টর স্ট্রেঞ্জ</em>-এর সাফল্য তাকে ছাড়িয়ে গেছে। আশা করা হচ্ছে, <em>অ্যান্ট-ম্যান অ্যান্ড দ্য ওয়াসপ </em>আরও ভালো ব্যবসা করবে। এরই মধ্যে <em>ডক্টর স্ট্রেঞ্জ</em>-এর সিক্যুয়েল ছবি নির্মাণের কথা ভাবা শুরু করেছেন নির্মাতা স্কট ডেরিকসন। বলা যেতে পারে, এমন ছবির সাফল্যকে নিবিড়ভাবে পর্যবেক্ষণ করছেন হলিউডের বাণিজ্য বিশ্লেষকেরা।</p>\r\n<p class="TEXT"><strong>প্রণব ভৌমিক</strong></p>\r\n<p class="TEXT">এবিসি নিউজ, সিনেমাব্লেন্ড, অয়ারড, দ্য ভার্জ অবলম্বনে।</p>', 'ডক্টর স্ট্রেঞ্জের ‘স্ট্রেঞ্জ’ সাফল্য!', '', 'publish', 'open', 'open', '', '%e0%a6%a1%e0%a6%95%e0%a7%8d%e0%a6%9f%e0%a6%b0-%e0%a6%b8%e0%a7%8d%e0%a6%9f%e0%a7%8d%e0%a6%b0%e0%a7%87%e0%a6%9e%e0%a7%8d%e0%a6%9c%e0%a7%87%e0%a6%b0-%e0%a6%b8%e0%a7%8d%e0%a6%9f%e0%a7%8d%e0%a6%b0', '', '', '2016-12-01 23:31:48', '2016-12-02 05:31:48', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=114', 0, 'post', '', 0),
(115, 3, '2016-12-01 13:13:45', '2016-12-01 19:13:45', '<img class="alignnone size-medium wp-image-101" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/a85e33a58106a8db419e7cb8145c4696-Untitled-17-300x264.jpg" alt="a85e33a58106a8db419e7cb8145c4696-untitled-17" width="300" height="264" />\r\n\r\nপ্রথম সপ্তাহেই মারভেলের ছবি <em>ডক্টর স্ট্রেঞ্জ </em>যুক্তরাষ্ট্রেরবক্স অফিসে সাড়ে আট কোটি ডলারেরও বেশি আয় করেছে। নয় অঙ্কের যুগে এ সাফল্য কম মনে হতে পারে, কিন্তু এই নভেম্বরে মুক্তি পাওয়া ছবির জন্য এ সাফল্য বেশ বড়ই। মার্কিনরা এখন ব্যস্ত প্রেসিডেন্ট নির্বাচন নিয়ে, সিনেমা দেখা এখন অগ্রাধিকারের তালিকায় নেই। তাঁদের এবারের নির্বাচনই তো সিনেমাটিক উপাদানে ভরপুর!\r\n<div class="fb-quote fb_iframe_widget"></div>\r\n<p class="TEXT">তার ওপর এটি চিরাচরিত সুপারহিরো ছবিও নয়। মারভেলের এই কমিক বই সিরিজ তাদের অন্য সুপারহিরোদের মতো সুপরিচিত নয়। সে হিসেবে <em>ডক্টর স্ট্রেঞ্জ </em>শুধুবক্স অফিসের প্রত্যাশা বেশ ভালোভাবেই মিটিয়েছে। সিনেমা রেটিংয়ের সাইট রোটেন টমেটোসে দেখা যাচ্ছে, শীর্ষ চলচ্চিত্র সমালোচকদের মধ্যে ৮৭ ভাগ এ ছবি পছন্দ করেছেন।</p>\r\n<p class="TEXT">এই সাফল্যের অনেকটা কৃতিত্ব বেনেডিক্ট কাম্বারব্যাচকে দেওয়া যেতেই পারে। শার্লক হোমস চরিত্রে অভিনয় করে তুমুল জনপ্রিয়তা পাওয়া এ অভিনেতাই এই ছবির ডক্টর স্ট্রেঞ্জ। তাঁর অভিনয় সমালোচকদেরও প্রশংসা কুড়িয়েছে। খল অভিনেতার চরিত্রে শিওটেল এজিওফরও দারুণ অভিনয় করেছেন। বলা হচ্ছে, <em>থর </em>ছবির লোকির (টম হিডলস্টোন অভিনয় করেছিলেন এ চরিত্রে) পর আর কোনো ভিলেন এমন করে দর্শক ও সমালোচক হৃদয় জয় করতে পারেননি।</p>\r\n<p class="TEXT">এই ছবির সাফল্য আরও প্রমাণ করছে হলিউডে ভিন্নধর্মী সুপারহিরোর ছবির কদর বাড়ছে। <em>ব্যাটম্যান</em>, <em>সুপারম্যান</em>, <em>আয়রনম্যান</em>-এর মতো ভরপুর অ্যাকশন ও অতিমানবিক সুপারহিরোদের দর্শকেরা আর পছন্দ করছেন না। <em>ডক্টর স্ট্রেঞ্জ</em>-এ অস্ত্রের ঝনঝনানি নেই, অন্য মারভেল ছবির মতো শেষ দৃশ্যে নায়ক-খলনায়কের মারামারিতে একটি গোটা শহর ধ্বংসস্তূপে পরিণত হয় না। ছবিতে পৃথিবীর অন্য দিক উন্মোচিত হয় দর্শকের সামনে।</p>\r\n<p class="TEXT">২০১৫ সালে <em>অ্যান্ট-ম্যান </em>নামের আরেকটি ভিন্নধর্মী হলিউড ছবিও বক্স অফিসে সাফল্য পেয়েছিল। <em>ডক্টর স্ট্রেঞ্জ</em>-এর সাফল্য তাকে ছাড়িয়ে গেছে। আশা করা হচ্ছে, <em>অ্যান্ট-ম্যান অ্যান্ড দ্য ওয়াসপ </em>আরও ভালো ব্যবসা করবে। এরই মধ্যে <em>ডক্টর স্ট্রেঞ্জ</em>-এর সিক্যুয়েল ছবি নির্মাণের কথা ভাবা শুরু করেছেন নির্মাতা স্কট ডেরিকসন। বলা যেতে পারে, এমন ছবির সাফল্যকে নিবিড়ভাবে পর্যবেক্ষণ করছেন হলিউডের বাণিজ্য বিশ্লেষকেরা।</p>\r\n<p class="TEXT"><strong>প্রণব ভৌমিক</strong></p>\r\n<p class="TEXT">এবিসি নিউজ, সিনেমাব্লেন্ড, অয়ারড, দ্য ভার্জ অবলম্বনে।</p>', 'ডক্টর স্ট্রেঞ্জের ‘স্ট্রেঞ্জ’ সাফল্য!', '', 'inherit', 'closed', 'closed', '', '114-revision-v1', '', '', '2016-12-01 13:13:45', '2016-12-01 19:13:45', '', 114, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/114-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `tbl_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(116, 4, '2016-12-01 13:18:59', '2016-12-01 19:18:59', '<img class="alignnone size-medium wp-image-103" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/e44e8b9dd2fad481529192093124067f-nasa-europa-300x187.jpg" alt="e44e8b9dd2fad481529192093124067f-nasa-europa" width="300" height="187" />\r\n\r\nমার্কিন মহাকাশ গবেষণা সংস্থা নাসার বিজ্ঞানীরা শিগগিরই নতুন একটি ‘চমক’ হাজির করতে যাচ্ছেন। এমন আভাস দিয়ে বলা হচ্ছে, এ চমক হতে পারে আমাদের এই সৌরজগতে এলিয়েন বা ভিনগ্রহের প্রাণীর গতিবিধি আবিষ্কারের তথ্য।\r\nবৃহস্পতির চাঁদ ইউরোপার ছবি বিশ্লেষণ করে নাসার গবেষকেরা আসছে সোমবার নাগাদ ওই উপগ্রহপৃষ্ঠের নিচে থাকা সমুদ্র সম্পর্কে তথ্য জানাতে পারেন। ১ হাজার ৯০০ মাইল প্রশস্ত এই উপগ্রহের বরফাছাওয়া খোলসের নিচে বিশাল সমুদ্র থাকতে পারে বলে মনে করছেন গবেষকেরা। এই সমুদ্র গবেষকেদের আরও বেশি আকৃষ্ট করছে ইউরোপার পাথুরে আবরণ। যার মধ্যে রাসায়নিক বিক্রিয়া ঘটানোর মতো উপাদান থাকতে পারে।\r\nহাবল টেলিস্কোপ ব্যবহার করে ইউরোপার নতুন এই ছবিগুলো তোলা হয়েছে। এর পাশাপাশি ইউরোপার রহস্য উদ্‌ঘাটনে সেখানে নভোযান পাঠানোর পরিকল্পনা নিয়ে কাজ করছেন গবেষকেরা। ওই মিশনে নভোযান ১ হাজার ৭০০ মাইল থেকে শুরু করে ১৬ মাইল উচ্চতায় ৪৫ বার ইউরোপাকে চক্কর দেবে। ওই মিশনের ফলেই ইউরোপার বর্তমান অবস্থার কথা জানা যাবে।\r\nগত মে মাসে নাসার প্লানেটারি ভূপ্রকৃতিবিদ স্টিভ ভ্যান্স বলেন, পৃথিবীর মতোই ইউরোপার সমুদ্রে অক্সিজেন ও হাইড্রোজেন চক্র সেখানকার সামুদ্রিক রসায়ন ও সেখানকার সম্ভাব্য জীবনের জন্য মূল চালিকা রূপ হতে পারে। তথ্যসূত্র: আইবিটাইমস', 'নাসার নতুন ‘চমক’ কি এলিয়েন?', '', 'inherit', 'closed', 'closed', '', '97-revision-v1', '', '', '2016-12-01 13:18:59', '2016-12-01 19:18:59', '', 97, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/97-revision-v1/', 0, 'revision', '', 0),
(117, 4, '2016-12-01 13:27:57', '2016-12-01 19:27:57', '<img class="alignnone size-medium wp-image-100" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/753ae8936f3768920a6b6fa235603507-7-278x300.jpg" alt="753ae8936f3768920a6b6fa235603507-7" width="278" height="300" />\r\n\r\nশুক্রবার মুক্তি পেয়েছে শাহরুখ খান ও আলিয়া ভাট অভিনীত ডিয়ার জিন্দেগি। মাত্র পাঁচ দিনেই অল্প বাজেটে তৈরি এ ছবি আয় করেছে প্রায় ৫০ কোটি রুপি। শাহরুখ আর আলিয়া যে বলিউডের বক্স অফিস মাত করতে যাচ্ছেন, তা আগেই কিছুটা আঁচ করা গিয়েছিল। অথচ ছবির শুটিং শুরুর আগে এমন গুজবও শোনা গিয়েছিল যে শাহরুখের বয়স বেশি হওয়ার গৌরী শিন্ডের এই ছবিটির প্রস্তাব প্রথমে ফিরিয়ে দিয়েছিলেন ভাট-কন্যা। যদিও তাঁরা এখানে প্রেমিক-প্রেমিকার চরিত্রে অভিনয় করেননি, কিন্তু পর্দায় এই জুটির রসায়ন দারুণ জমেছে। ‘কিং খান’ আরও একবার আলিয়ার সঙ্গে জুটি বাঁধতে রাজি, তবে এর সঙ্গে একটি শর্ত জুড়ে দিয়েছেন তিনি।<!--more-->\r\nডিয়ার জিন্দেগি মুক্তির পর এক অনুষ্ঠানে হাজির হয়েছিলেন শাহরুখ খান। সেখানে তাঁর কাছে জানতে চাওয়া হয়, আলিয়ার সঙ্গে আবারও কোনো ছবিতে অভিনয় করার কথা ভাবছেন কি না? শাহরুখ তখন রসিকতা করে বলেন, ‘যদি বয়সে বড় এক মেয়ের সঙ্গে ছোট কোনো ছেলের প্রেমের গল্প নিয়ে ছবি হয় তাহলে হয়তো করব।’\r\nশাহরুখ আর আলিয়ার বয়সে বিশাল ফারাক। ডিয়ার জিন্দেগির কাহিনির প্রয়োজনে অবশ্য অসম বয়সের দুই অভিনেতা ও অভিনেত্রীকেই দরকার ছিল। এ জন্যই মজা করে এই মন্তব্যটি করেছেন কিং খান।\r\nঅবশ্য একটি সূত্র থেকে জানা গেছে, শুটিং চলাকালে নাকি প্রায়ই শাহরুখ-আলিয়া নিজেদের মধ্যে ছবির আইডিয়া বিনিময় করতেন। তাই ভবিষ্যতে তাঁদের জুটি হওয়ার সম্ভাবনাকে কিন্তু একেবারে উড়িয়ে দেওয়া যাচ্ছে না। দ্য ইন্ডিয়ান এক্সপ্রেস।', 'আলিয়ার সঙ্গে জুটি বাঁধতে শাহরুখের শর্ত...', '', 'publish', 'open', 'open', '', '%e0%a6%86%e0%a6%b2%e0%a6%bf%e0%a7%9f%e0%a6%be%e0%a6%b0-%e0%a6%b8%e0%a6%99%e0%a7%8d%e0%a6%97%e0%a7%87-%e0%a6%9c%e0%a7%81%e0%a6%9f%e0%a6%bf-%e0%a6%ac%e0%a6%be%e0%a6%81%e0%a6%a7%e0%a6%a4%e0%a7%87', '', '', '2016-12-01 23:20:55', '2016-12-02 05:20:55', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=117', 0, 'post', '', 0),
(118, 4, '2016-12-01 13:27:57', '2016-12-01 19:27:57', '<img class="alignnone size-medium wp-image-100" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/753ae8936f3768920a6b6fa235603507-7-278x300.jpg" alt="753ae8936f3768920a6b6fa235603507-7" width="278" height="300" />\r\n\r\nশুক্রবার মুক্তি পেয়েছে শাহরুখ খান ও আলিয়া ভাট অভিনীত ডিয়ার জিন্দেগি। মাত্র পাঁচ দিনেই অল্প বাজেটে তৈরি এ ছবি আয় করেছে প্রায় ৫০ কোটি রুপি। শাহরুখ আর আলিয়া যে বলিউডের বক্স অফিস মাত করতে যাচ্ছেন, তা আগেই কিছুটা আঁচ করা গিয়েছিল। অথচ ছবির শুটিং শুরুর আগে এমন গুজবও শোনা গিয়েছিল যে শাহরুখের বয়স বেশি হওয়ার গৌরী শিন্ডের এই ছবিটির প্রস্তাব প্রথমে ফিরিয়ে দিয়েছিলেন ভাট-কন্যা। যদিও তাঁরা এখানে প্রেমিক-প্রেমিকার চরিত্রে অভিনয় করেননি, কিন্তু পর্দায় এই জুটির রসায়ন দারুণ জমেছে। ‘কিং খান’ আরও একবার আলিয়ার সঙ্গে জুটি বাঁধতে রাজি, তবে এর সঙ্গে একটি শর্ত জুড়ে দিয়েছেন তিনি।\r\nডিয়ার জিন্দেগি মুক্তির পর এক অনুষ্ঠানে হাজির হয়েছিলেন শাহরুখ খান। সেখানে তাঁর কাছে জানতে চাওয়া হয়, আলিয়ার সঙ্গে আবারও কোনো ছবিতে অভিনয় করার কথা ভাবছেন কি না? শাহরুখ তখন রসিকতা করে বলেন, ‘যদি বয়সে বড় এক মেয়ের সঙ্গে ছোট কোনো ছেলের প্রেমের গল্প নিয়ে ছবি হয় তাহলে হয়তো করব।’\r\nশাহরুখ আর আলিয়ার বয়সে বিশাল ফারাক। ডিয়ার জিন্দেগির কাহিনির প্রয়োজনে অবশ্য অসম বয়সের দুই অভিনেতা ও অভিনেত্রীকেই দরকার ছিল। এ জন্যই মজা করে এই মন্তব্যটি করেছেন কিং খান।\r\nঅবশ্য একটি সূত্র থেকে জানা গেছে, শুটিং চলাকালে নাকি প্রায়ই শাহরুখ-আলিয়া নিজেদের মধ্যে ছবির আইডিয়া বিনিময় করতেন। তাই ভবিষ্যতে তাঁদের জুটি হওয়ার সম্ভাবনাকে কিন্তু একেবারে উড়িয়ে দেওয়া যাচ্ছে না। দ্য ইন্ডিয়ান এক্সপ্রেস।', 'আলিয়ার সঙ্গে জুটি বাঁধতে শাহরুখের শর্ত...', '', 'inherit', 'closed', 'closed', '', '117-revision-v1', '', '', '2016-12-01 13:27:57', '2016-12-01 19:27:57', '', 117, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/117-revision-v1/', 0, 'revision', '', 0),
(119, 1, '2016-12-01 13:34:07', '0000-00-00 00:00:00', '২০১২-১৩ সালের এন্ড্রয়েড সেরা ১০টি এন্ড্রয়েড এইচডি গেমস নিয়ে সাজান হয়েছে এ পোস্ট টি। এ থেকে জানতে পারবেন কোন গেম কি ধরনের, কে বানিয়েছে, মূল্য কত, কিভাবে কোথা থেকে কিনবেন এবং সবচেয়ে গুরুত্বপূর্ণ ফ্রী ডাউনলোড লিঙ্কস!!! পোস্ট টিতে লিখার খুব বেশি কিছু নেই। তাই শুরু করে দিলাম। দেখুন আর নামিয়ে নিন আপনার এন্ড্রয়েড ফোনের জন্য!!!\n\n1) Modern Combat 4: Zero Hour\n', 'সেরা ১০ এন্ড্রয়েড HD গেমস [ফ্রী ডাউনলোড]', '', 'draft', 'open', 'open', '', '', '', '', '2016-12-01 13:34:07', '2016-12-01 19:34:07', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=119', 0, 'post', '', 0),
(120, 1, '2016-12-01 13:56:59', '2016-12-01 19:56:59', '২০১২-১৩ সালের এন্ড্রয়েড সেরা ১০টি এন্ড্রয়েড এইচডি গেমস নিয়ে সাজান হয়েছে এ পোস্ট টি। এ থেকে জানতে পারবেন কোন গেম কি ধরনের, কে বানিয়েছে, মূল্য কত, কিভাবে কোথা থেকে কিনবেন এবং সবচেয়ে গুরুত্বপূর্ণ ফ্রী ডাউনলোড লিঙ্কস!!! পোস্ট টিতে লিখার খুব বেশি কিছু নেই। তাই শুরু করে দিলাম। দেখুন আর নামিয়ে নিন আপনার এন্ড্রয়েড ফোনের জন্য!!!<!--more-->\r\n<h2>1) Modern Combat 4: Zero Hour</h2>\r\n<img class="aligncenter size-medium wp-image-105" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/modern-combat-4-zero-hour-screen1-300x146.jpg" alt="modern-combat-4-zero-hour-screen1" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> First Person Shooter/War/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong>  <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftM4HM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftM4HM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.directmirror.com/files/S6LEUA2G" target="_blank">Apk</a> | Sd data [<a href="http://www52.zippyshare.com/v/74470629/file.html" target="_blank">Part1</a>] [<a href="http://www33.zippyshare.com/v/11228029/file.html" target="_blank">Part2</a>] [<a href="http://www72.zippyshare.com/v/33846434/file.html" target="_blank">Part3</a>] [<a href="http://www38.zippyshare.com/v/8527974/file.html" target="_blank">Part4</a>] [<a href="http://www53.zippyshare.com/v/88168860/file.html" target="_blank">Part5</a>] [<a href="http://www31.zippyshare.com/v/799085/file.html" target="_blank">Part6</a>] [<a href="http://www54.zippyshare.com/v/16122242/file.html" target="_blank">Patch</a>]</li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন [Patch টির জন্যও একই কাজ করুন]</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>2) The Dark Knight Rises</h2>\r\n<img class="aligncenter size-medium wp-image-108" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/The-Dark-Knight-Rises-galaxy-s3-300x146.jpg" alt="the-dark-knight-rises-galaxy-s3" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Movie/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftKRHM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftKRHM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/the-dark-knight-rises-v1-1-2-working-final-sd-files-and-patch-android-t6875284.html" target="_blank">Apk | Sd data [Torrent]</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>3) Grand Theft Auto III</h2>\r\n<img class="aligncenter size-medium wp-image-104" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Grand-Theft-Auto-III-screenshot-300x150.jpg" alt="grand-theft-auto-iii-screenshot" width="300" height="150" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Free Roaming/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Rockstar Games, Inc.</li>\r\n 	<li><strong>মূল্যঃ</strong> $4.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a class="seoquake-nofollow" href="https://play.google.com/store/apps/details?id=com.rockstar.gta3aus" rel="nofollow">https://play.google.com/store/apps/details?id=com.rockstar.gta3aus</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.kat.ph/gta-3-android-qvga-hvga-apk-and-sd-files-from-lycanbd-rar-t6061720.html" target="_blank">Apk | Sd data [Armv6]</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sd card/Android/data/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>4) Asphalt 7: Heat</h2>\r\n<img class="aligncenter size-medium wp-image-110" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed-300x147.jpg" alt="unnamed" width="300" height="147" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Racing/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $0.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="http://https//play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftA7HM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftA7HM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/asphalt-7-heat-v1-0-4-build-1041-sd-data-android-game-t6921076.html" target="_blank">Apk | Sd data [Torrent]</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android.obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>5) Wild Blood</h2>\r\n<img class="aligncenter size-medium wp-image-111" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Wild-Blood-apk-download-300x146.jpg" alt="wild-blood-apk-download" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Action/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftWBHM&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftWBHM&amp;hl=en</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/wild-blood-v1-0-7-the-best-game-for-android-sd-data-bobiras2009-t6721387.html" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li><a href="http://kat.ph/wild-blood-v1-0-7-the-best-game-for-android-sd-data-bobiras2009-t6721387.html" target="_blank">Follow the link</a></li>\r\n</ul>\r\n<h2>6) N.O.V.A. 3</h2>\r\n<img class="aligncenter size-medium wp-image-106" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/N.O.V.A.-3-screenshot-300x146.jpg" alt="n-o-v-a-3-screenshot" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> FPS/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftN3HM&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftN3HM&amp;hl=en</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/n-o-v-a-3-1-0-4-apk-sd-data-android-r4in-t6877151.html" target="_blank">Apk | Sd data</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>7) NFS: Most Wanted</h2>\r\n<img class="aligncenter size-medium wp-image-113" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Need-for-Speed-Most-Wanted-screens-300x146.jpg" alt="need-for-speed-most-wanted-screens" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Racing/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> EA Sports</li>\r\n 	<li><strong>মূল্যঃ</strong> $5.61</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.ea.games.nfs13_row" target="_blank">https://play.google.com/store/apps/details?id=com.ea.games.nfs13_row</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/need-for-speed-most-wanted-apk-sd-data-t7158049.html" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/data/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>8) PES 2012</h2>\r\n<img class="aligncenter size-medium wp-image-99" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/1pes12-android-300x169.png" alt="1pes12-android" width="300" height="169" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Sports/Simulation</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Konami</li>\r\n 	<li><strong>মূল্যঃ</strong> N/A</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> N/A</li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.mediafire.com/error.php?errno=320" target="_blank">Apk</a> |<a href="http://www.mediafire.com/?t9yyfqu1unv8bvc" target="_blank"> Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>9) Shadow Gun</h2>\r\n<img class="aligncenter size-medium wp-image-109" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed-1-300x147.jpg" alt="unnamed-1" width="300" height="147" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> FPS/Action/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> MADFINGER Games</li>\r\n 	<li><strong>মূল্যঃ</strong> $4.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.madfingergames.shadowgun&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.madfingergames.shadowgun&amp;hl=en</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://thepiratebay.sx/torrent/7532084/SHADOWGUN_v2.1.0_Final___SD_Data_By_bobiras2009" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li><a href="http://thepiratebay.sx/torrent/7532084/SHADOWGUN_v2.1.0_Final___SD_Data_By_bobiras2009" target="_blank">Click the link</a></li>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android.obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>10) The Amazing Spiderman</h2>\r\n<img class="aligncenter size-medium wp-image-102" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/amazing-spiderman-galaxy-s3-300x146.jpg" alt="amazing-spiderman-galaxy-s3" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Action/Adventure/Movie</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftAMHM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftAMHM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/the-amazing-spider-man-v1-1-7-working-final-sd-data-android-t6854880.html" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/gameloft/games/..পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!\r\n\r\n<hr />\r\n\r\n</li>\r\n</ul>\r\n&nbsp;\r\n<blockquote><strong>যেকোন অ্যান্ড্রয়েড গেমস এর জন্য ভিসিট করুন আমাদের সাইট</strong>\r\n\r\n<strong><a href="http://www.lycanbd.net/2011/11/android-dvds-by-lycanbd.html" target="_blank">http://www.lycanbd.net</a>- To Download All Android Games, Apps, Wallpapers, Rigntones etc\r\n</strong>\r\n\r\n<strong><a href="http://apkgiant.com/" target="_blank">http://www.apkGiant.com</a>- Cracked Android Games &amp; Apps Apk</strong></blockquote>\r\n&nbsp;', 'সেরা ১০ এন্ড্রয়েড HD গেমস [ফ্রী ডাউনলোড]', '', 'publish', 'open', 'open', '', '%e0%a6%b8%e0%a7%87%e0%a6%b0%e0%a6%be-%e0%a7%a7%e0%a7%a6-%e0%a6%8f%e0%a6%a8%e0%a7%8d%e0%a6%a1%e0%a7%8d%e0%a6%b0%e0%a6%af%e0%a6%bc%e0%a7%87%e0%a6%a1-hd-%e0%a6%97%e0%a7%87%e0%a6%ae%e0%a6%b8-%e0%a6%ab', '', '', '2016-12-01 23:13:40', '2016-12-02 05:13:40', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=120', 0, 'post', '', 1),
(121, 1, '2016-12-01 13:56:59', '2016-12-01 19:56:59', '২০১২-১৩ সালের এন্ড্রয়েড সেরা ১০টি এন্ড্রয়েড এইচডি গেমস নিয়ে সাজান হয়েছে এ পোস্ট টি। এ থেকে জানতে পারবেন কোন গেম কি ধরনের, কে বানিয়েছে, মূল্য কত, কিভাবে কোথা থেকে কিনবেন এবং সবচেয়ে গুরুত্বপূর্ণ ফ্রী ডাউনলোড লিঙ্কস!!! পোস্ট টিতে লিখার খুব বেশি কিছু নেই। তাই শুরু করে দিলাম। দেখুন আর নামিয়ে নিন আপনার এন্ড্রয়েড ফোনের জন্য!!!\r\n<h2>1) Modern Combat 4: Zero Hour</h2>\r\n<img class="aligncenter size-medium wp-image-105" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/modern-combat-4-zero-hour-screen1-300x146.jpg" alt="modern-combat-4-zero-hour-screen1" width="300" height="146">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> First Person Shooter/War/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong>&nbsp; <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftM4HM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftM4HM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.directmirror.com/files/S6LEUA2G" target="_blank">Apk</a> | Sd data [<a href="http://www52.zippyshare.com/v/74470629/file.html" target="_blank">Part1</a>] [<a href="http://www33.zippyshare.com/v/11228029/file.html" target="_blank">Part2</a>] [<a href="http://www72.zippyshare.com/v/33846434/file.html" target="_blank">Part3</a>] [<a href="http://www38.zippyshare.com/v/8527974/file.html" target="_blank">Part4</a>] [<a href="http://www53.zippyshare.com/v/88168860/file.html" target="_blank">Part5</a>] [<a href="http://www31.zippyshare.com/v/799085/file.html" target="_blank">Part6</a>] [<a href="http://www54.zippyshare.com/v/16122242/file.html" target="_blank">Patch</a>]</li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন [Patch টির জন্যও একই কাজ করুন]</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>2) The Dark Knight Rises</h2>\r\n<img class="aligncenter size-medium wp-image-108" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/The-Dark-Knight-Rises-galaxy-s3-300x146.jpg" alt="the-dark-knight-rises-galaxy-s3" width="300" height="146">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Movie/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftKRHM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftKRHM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/the-dark-knight-rises-v1-1-2-working-final-sd-files-and-patch-android-t6875284.html" target="_blank">Apk | Sd data [Torrent]</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>3) Grand Theft Auto III</h2>\r\n<img class="aligncenter size-medium wp-image-104" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Grand-Theft-Auto-III-screenshot-300x150.jpg" alt="grand-theft-auto-iii-screenshot" width="300" height="150">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Free Roaming/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Rockstar Games, Inc.</li>\r\n 	<li><strong>মূল্যঃ</strong> $4.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a class="seoquake-nofollow" href="https://play.google.com/store/apps/details?id=com.rockstar.gta3aus" rel="nofollow">https://play.google.com/store/apps/details?id=com.rockstar.gta3aus</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.kat.ph/gta-3-android-qvga-hvga-apk-and-sd-files-from-lycanbd-rar-t6061720.html" target="_blank">Apk | Sd data [Armv6]</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sd card/Android/data/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>4) Asphalt 7: Heat</h2>\r\n<img class="aligncenter size-medium wp-image-110" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed-300x147.jpg" alt="unnamed" width="300" height="147">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Racing/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $0.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="http://https//play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftA7HM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftA7HM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/asphalt-7-heat-v1-0-4-build-1041-sd-data-android-game-t6921076.html" target="_blank">Apk | Sd data [Torrent]</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android.obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>5) Wild Blood</h2>\r\n<img class="aligncenter size-medium wp-image-111" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Wild-Blood-apk-download-300x146.jpg" alt="wild-blood-apk-download" width="300" height="146">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Action/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftWBHM&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftWBHM&amp;hl=en</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/wild-blood-v1-0-7-the-best-game-for-android-sd-data-bobiras2009-t6721387.html" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li><a href="http://kat.ph/wild-blood-v1-0-7-the-best-game-for-android-sd-data-bobiras2009-t6721387.html" target="_blank">Follow the link</a></li>\r\n</ul>\r\n<h2>6) N.O.V.A. 3</h2>\r\n<img class="aligncenter size-medium wp-image-106" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/N.O.V.A.-3-screenshot-300x146.jpg" alt="n-o-v-a-3-screenshot" width="300" height="146">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> FPS/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftN3HM&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftN3HM&amp;hl=en</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/n-o-v-a-3-1-0-4-apk-sd-data-android-r4in-t6877151.html" target="_blank">Apk | Sd data</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>7) NFS: Most Wanted</h2>\r\n<img class="aligncenter size-medium wp-image-113" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Need-for-Speed-Most-Wanted-screens-300x146.jpg" alt="need-for-speed-most-wanted-screens" width="300" height="146">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Racing/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> EA Sports</li>\r\n 	<li><strong>মূল্যঃ</strong> $5.61</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.ea.games.nfs13_row" target="_blank">https://play.google.com/store/apps/details?id=com.ea.games.nfs13_row</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/need-for-speed-most-wanted-apk-sd-data-t7158049.html" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/data/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>8) PES 2012</h2>\r\n<img class="aligncenter size-medium wp-image-99" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/1pes12-android-300x169.png" alt="1pes12-android" width="300" height="169">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Sports/Simulation</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Konami</li>\r\n 	<li><strong>মূল্যঃ</strong> N/A</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> N/A</li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.mediafire.com/error.php?errno=320" target="_blank">Apk</a> |<a href="http://www.mediafire.com/?t9yyfqu1unv8bvc" target="_blank"> Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>9) Shadow Gun</h2>\r\n<img class="aligncenter size-medium wp-image-109" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed-1-300x147.jpg" alt="unnamed-1" width="300" height="147">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> FPS/Action/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> MADFINGER Games</li>\r\n 	<li><strong>মূল্যঃ</strong> $4.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.madfingergames.shadowgun&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.madfingergames.shadowgun&amp;hl=en</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://thepiratebay.sx/torrent/7532084/SHADOWGUN_v2.1.0_Final___SD_Data_By_bobiras2009" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li><a href="http://thepiratebay.sx/torrent/7532084/SHADOWGUN_v2.1.0_Final___SD_Data_By_bobiras2009" target="_blank">Click the link</a></li>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android.obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>10) The Amazing Spiderman</h2>\r\n<img class="aligncenter size-medium wp-image-102" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/amazing-spiderman-galaxy-s3-300x146.jpg" alt="amazing-spiderman-galaxy-s3" width="300" height="146">\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Action/Adventure/Movie</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftAMHM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftAMHM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/the-amazing-spider-man-v1-1-7-working-final-sd-data-android-t6854880.html" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/gameloft/games/..পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!\r\n\r\n<hr>\r\n\r\n</li>\r\n</ul>\r\n&nbsp;\r\n<blockquote><strong>যেকোন অ্যান্ড্রয়েড গেমস এর জন্য ভিসিট করুন আমাদের সাইট</strong>\r\n\r\n<strong><a href="http://www.lycanbd.net/2011/11/android-dvds-by-lycanbd.html" target="_blank">http://www.lycanbd.net</a>- To Download All Android Games, Apps, Wallpapers, Rigntones etc\r\n</strong>\r\n\r\n<strong><a href="http://apkgiant.com/" target="_blank">http://www.apkGiant.com</a>- Cracked Android Games &amp; Apps Apk</strong></blockquote>\r\n&nbsp;', 'সেরা ১০ এন্ড্রয়েড HD গেমস [ফ্রী ডাউনলোড]', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2016-12-01 13:56:59', '2016-12-01 19:56:59', '', 120, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/120-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `tbl_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(122, 4, '2016-12-01 23:05:38', '2016-12-02 05:05:38', '২০১২-১৩ সালের এন্ড্রয়েড সেরা ১০টি এন্ড্রয়েড এইচডি গেমস নিয়ে সাজান হয়েছে এ পোস্ট টি। এ থেকে জানতে পারবেন কোন গেম কি ধরনের, কে বানিয়েছে, মূল্য কত, কিভাবে কোথা থেকে কিনবেন এবং সবচেয়ে গুরুত্বপূর্ণ ফ্রী ডাউনলোড লিঙ্কস!!! পোস্ট টিতে লিখার খুব বেশি কিছু নেই। তাই শুরু করে দিলাম। দেখুন আর নামিয়ে নিন আপনার এন্ড্রয়েড ফোনের জন্য!!!<!--more-->\n<h2>1) Modern Combat 4: Zero Hour</h2>\n<img class="aligncenter size-medium wp-image-105" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/modern-combat-4-zero-hour-screen1-300x146.jpg" alt="modern-combat-4-zero-hour-screen1" width="300" height="146" />\n<ul>\n 	<li><strong>ধরনঃ</strong> First Person Shooter/War/Action</li>\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong>  <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftM4HM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftM4HM</a></li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.directmirror.com/files/S6LEUA2G" target="_blank">Apk</a> | Sd data [<a href="http://www52.zippyshare.com/v/74470629/file.html" target="_blank">Part1</a>] [<a href="http://www33.zippyshare.com/v/11228029/file.html" target="_blank">Part2</a>] [<a href="http://www72.zippyshare.com/v/33846434/file.html" target="_blank">Part3</a>] [<a href="http://www38.zippyshare.com/v/8527974/file.html" target="_blank">Part4</a>] [<a href="http://www53.zippyshare.com/v/88168860/file.html" target="_blank">Part5</a>] [<a href="http://www31.zippyshare.com/v/799085/file.html" target="_blank">Part6</a>] [<a href="http://www54.zippyshare.com/v/16122242/file.html" target="_blank">Patch</a>]</li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li>১) Apk ইন্সটল করুন</li>\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন [Patch টির জন্যও একই কাজ করুন]</li>\n 	<li>৩) এখন খেলুন!</li>\n</ul>\n<h2>2) The Dark Knight Rises</h2>\n<img class="aligncenter size-medium wp-image-108" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/The-Dark-Knight-Rises-galaxy-s3-300x146.jpg" alt="the-dark-knight-rises-galaxy-s3" width="300" height="146" />\n<ul>\n 	<li><strong>ধরনঃ</strong> Movie/Action</li>\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftKRHM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftKRHM</a></li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/the-dark-knight-rises-v1-1-2-working-final-sd-files-and-patch-android-t6875284.html" target="_blank">Apk | Sd data [Torrent]</a></li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li>১) Apk ইন্সটল করুন</li>\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\n 	<li>৩) এখন খেলুন!</li>\n</ul>\n<h2>3) Grand Theft Auto III</h2>\n<img class="aligncenter size-medium wp-image-104" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Grand-Theft-Auto-III-screenshot-300x150.jpg" alt="grand-theft-auto-iii-screenshot" width="300" height="150" />\n<ul>\n 	<li><strong>ধরনঃ</strong> Free Roaming/Action</li>\n 	<li><strong>ডেভেলপারঃ</strong> Rockstar Games, Inc.</li>\n 	<li><strong>মূল্যঃ</strong> $4.99</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a class="seoquake-nofollow" href="https://play.google.com/store/apps/details?id=com.rockstar.gta3aus" rel="nofollow">https://play.google.com/store/apps/details?id=com.rockstar.gta3aus</a></li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.kat.ph/gta-3-android-qvga-hvga-apk-and-sd-files-from-lycanbd-rar-t6061720.html" target="_blank">Apk | Sd data [Armv6]</a></li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li>১) Apk ইন্সটল করুন</li>\n 	<li>২) Sd data নিয়ে sd card/Android/data/...পেস্ট করুন</li>\n 	<li>৩) এখন খেলুন!</li>\n</ul>\n<h2>4) Asphalt 7: Heat</h2>\n<img class="aligncenter size-medium wp-image-110" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed-300x147.jpg" alt="unnamed" width="300" height="147" />\n<ul>\n 	<li><strong>ধরনঃ</strong> Racing/Adventure</li>\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\n 	<li><strong>মূল্যঃ</strong> $0.99</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="http://https//play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftA7HM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftA7HM</a></li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/asphalt-7-heat-v1-0-4-build-1041-sd-data-android-game-t6921076.html" target="_blank">Apk | Sd data [Torrent]</a></li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li>১) Apk ইন্সটল করুন</li>\n 	<li>২) Sd data নিয়ে sdcard/Android.obb/...পেস্ট করুন</li>\n 	<li>৩) এখন খেলুন!</li>\n</ul>\n<h2>5) Wild Blood</h2>\n<img class="aligncenter size-medium wp-image-111" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Wild-Blood-apk-download-300x146.jpg" alt="wild-blood-apk-download" width="300" height="146" />\n<ul>\n 	<li><strong>ধরনঃ</strong> Action/Adventure</li>\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftWBHM&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftWBHM&amp;hl=en</a></li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/wild-blood-v1-0-7-the-best-game-for-android-sd-data-bobiras2009-t6721387.html" target="_blank">Apk | Sd data </a></li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li><a href="http://kat.ph/wild-blood-v1-0-7-the-best-game-for-android-sd-data-bobiras2009-t6721387.html" target="_blank">Follow the link</a></li>\n</ul>\n<h2>6) N.O.V.A. 3</h2>\n<img class="aligncenter size-medium wp-image-106" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/N.O.V.A.-3-screenshot-300x146.jpg" alt="n-o-v-a-3-screenshot" width="300" height="146" />\n<ul>\n 	<li><strong>ধরনঃ</strong> FPS/Action</li>\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftN3HM&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftN3HM&amp;hl=en</a></li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/n-o-v-a-3-1-0-4-apk-sd-data-android-r4in-t6877151.html" target="_blank">Apk | Sd data</a></li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li>১) Apk ইন্সটল করুন</li>\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\n 	<li>৩) এখন খেলুন!</li>\n</ul>\n<h2>7) NFS: Most Wanted</h2>\n<img class="aligncenter size-medium wp-image-113" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Need-for-Speed-Most-Wanted-screens-300x146.jpg" alt="need-for-speed-most-wanted-screens" width="300" height="146" />\n<ul>\n 	<li><strong>ধরনঃ</strong> Racing/Adventure</li>\n 	<li><strong>ডেভেলপারঃ</strong> EA Sports</li>\n 	<li><strong>মূল্যঃ</strong> $5.61</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.ea.games.nfs13_row" target="_blank">https://play.google.com/store/apps/details?id=com.ea.games.nfs13_row</a></li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/need-for-speed-most-wanted-apk-sd-data-t7158049.html" target="_blank">Apk | Sd data </a></li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li>১) Apk ইন্সটল করুন</li>\n 	<li>২) Sd data নিয়ে sdcard/Android/data/...পেস্ট করুন</li>\n 	<li>৩) এখন খেলুন!</li>\n</ul>\n<h2>8) PES 2012</h2>\n<img class="aligncenter size-medium wp-image-99" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/1pes12-android-300x169.png" alt="1pes12-android" width="300" height="169" />\n<ul>\n 	<li><strong>ধরনঃ</strong> Sports/Simulation</li>\n 	<li><strong>ডেভেলপারঃ</strong> Konami</li>\n 	<li><strong>মূল্যঃ</strong> N/A</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> N/A</li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.mediafire.com/error.php?errno=320" target="_blank">Apk</a> |<a href="http://www.mediafire.com/?t9yyfqu1unv8bvc" target="_blank"> Sd data </a></li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li>১) Apk ইন্সটল করুন</li>\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\n 	<li>৩) এখন খেলুন!</li>\n</ul>\n<h2>9) Shadow Gun</h2>\n<img class="aligncenter size-medium wp-image-109" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed-1-300x147.jpg" alt="unnamed-1" width="300" height="147" />\n<ul>\n 	<li><strong>ধরনঃ</strong> FPS/Action/Adventure</li>\n 	<li><strong>ডেভেলপারঃ</strong> MADFINGER Games</li>\n 	<li><strong>মূল্যঃ</strong> $4.99</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.madfingergames.shadowgun&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.madfingergames.shadowgun&amp;hl=en</a></li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://thepiratebay.sx/torrent/7532084/SHADOWGUN_v2.1.0_Final___SD_Data_By_bobiras2009" target="_blank">Apk | Sd data </a></li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li><a href="http://thepiratebay.sx/torrent/7532084/SHADOWGUN_v2.1.0_Final___SD_Data_By_bobiras2009" target="_blank">Click the link</a></li>\n 	<li>১) Apk ইন্সটল করুন</li>\n 	<li>২) Sd data নিয়ে sdcard/Android.obb/...পেস্ট করুন</li>\n 	<li>৩) এখন খেলুন!</li>\n</ul>\n<h2>10) The Amazing Spiderman</h2>\n<img class="aligncenter size-medium wp-image-102" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/amazing-spiderman-galaxy-s3-300x146.jpg" alt="amazing-spiderman-galaxy-s3" width="300" height="146" />\n<ul>\n 	<li><strong>ধরনঃ</strong> Action/Adventure/Movie</li>\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftAMHM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftAMHM</a></li>\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/the-amazing-spider-man-v1-1-7-working-final-sd-data-android-t6854880.html" target="_blank">Apk | Sd data </a></li>\n</ul>\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\n<ul>\n 	<li>১) Apk ইন্সটল করুন</li>\n 	<li>২) Sd data নিয়ে sdcard/gameloft/games/..পেস্ট করুন</li>\n 	<li>৩) এখন খেলুন!\n\n<hr />\n\n</li>\n</ul>\n&nbsp;\n<blockquote><strong>যেকোন অ্যান্ড্রয়েড গেমস এর জন্য ভিসিট করুন আমাদের সাইট</strong>\n\n<strong><a href="http://www.lycanbd.net/2011/11/android-dvds-by-lycanbd.html" target="_blank">http://www.lycanbd.net</a>- To Download All Android Games, Apps, Wallpapers, Rigntones etc\n</strong>\n\n<strong><a href="http://apkgiant.com/" target="_blank">http://www.apkGiant.com</a>- Cracked Android Games &amp; Apps Apk</strong></blockquote>\n&nbsp;', 'সেরা ১০ এন্ড্রয়েড HD গেমস [ফ্রী ডাউনলোড]', '', 'inherit', 'closed', 'closed', '', '120-autosave-v1', '', '', '2016-12-01 23:05:38', '2016-12-02 05:05:38', '', 120, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/120-autosave-v1/', 0, 'revision', '', 0),
(123, 4, '2016-12-01 23:09:19', '2016-12-02 05:09:19', '২০১২-১৩ সালের এন্ড্রয়েড সেরা ১০টি এন্ড্রয়েড এইচডি গেমস নিয়ে সাজান হয়েছে এ পোস্ট টি। এ থেকে জানতে পারবেন কোন গেম কি ধরনের, কে বানিয়েছে, মূল্য কত, কিভাবে কোথা থেকে কিনবেন এবং সবচেয়ে গুরুত্বপূর্ণ ফ্রী ডাউনলোড লিঙ্কস!!! পোস্ট টিতে লিখার খুব বেশি কিছু নেই। তাই শুরু করে দিলাম। দেখুন আর নামিয়ে নিন আপনার এন্ড্রয়েড ফোনের জন্য!!!<!--more-->\r\n<h2>1) Modern Combat 4: Zero Hour</h2>\r\n<img class="aligncenter size-medium wp-image-105" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/modern-combat-4-zero-hour-screen1-300x146.jpg" alt="modern-combat-4-zero-hour-screen1" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> First Person Shooter/War/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong>  <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftM4HM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftM4HM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.directmirror.com/files/S6LEUA2G" target="_blank">Apk</a> | Sd data [<a href="http://www52.zippyshare.com/v/74470629/file.html" target="_blank">Part1</a>] [<a href="http://www33.zippyshare.com/v/11228029/file.html" target="_blank">Part2</a>] [<a href="http://www72.zippyshare.com/v/33846434/file.html" target="_blank">Part3</a>] [<a href="http://www38.zippyshare.com/v/8527974/file.html" target="_blank">Part4</a>] [<a href="http://www53.zippyshare.com/v/88168860/file.html" target="_blank">Part5</a>] [<a href="http://www31.zippyshare.com/v/799085/file.html" target="_blank">Part6</a>] [<a href="http://www54.zippyshare.com/v/16122242/file.html" target="_blank">Patch</a>]</li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন [Patch টির জন্যও একই কাজ করুন]</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>2) The Dark Knight Rises</h2>\r\n<img class="aligncenter size-medium wp-image-108" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/The-Dark-Knight-Rises-galaxy-s3-300x146.jpg" alt="the-dark-knight-rises-galaxy-s3" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Movie/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftKRHM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftKRHM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/the-dark-knight-rises-v1-1-2-working-final-sd-files-and-patch-android-t6875284.html" target="_blank">Apk | Sd data [Torrent]</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>3) Grand Theft Auto III</h2>\r\n<img class="aligncenter size-medium wp-image-104" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Grand-Theft-Auto-III-screenshot-300x150.jpg" alt="grand-theft-auto-iii-screenshot" width="300" height="150" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Free Roaming/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Rockstar Games, Inc.</li>\r\n 	<li><strong>মূল্যঃ</strong> $4.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a class="seoquake-nofollow" href="https://play.google.com/store/apps/details?id=com.rockstar.gta3aus" rel="nofollow">https://play.google.com/store/apps/details?id=com.rockstar.gta3aus</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.kat.ph/gta-3-android-qvga-hvga-apk-and-sd-files-from-lycanbd-rar-t6061720.html" target="_blank">Apk | Sd data [Armv6]</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sd card/Android/data/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>4) Asphalt 7: Heat</h2>\r\n<img class="aligncenter size-medium wp-image-110" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed-300x147.jpg" alt="unnamed" width="300" height="147" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Racing/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $0.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="http://https//play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftA7HM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftA7HM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/asphalt-7-heat-v1-0-4-build-1041-sd-data-android-game-t6921076.html" target="_blank">Apk | Sd data [Torrent]</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android.obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>5) Wild Blood</h2>\r\n<img class="aligncenter size-medium wp-image-111" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Wild-Blood-apk-download-300x146.jpg" alt="wild-blood-apk-download" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Action/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftWBHM&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftWBHM&amp;hl=en</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/wild-blood-v1-0-7-the-best-game-for-android-sd-data-bobiras2009-t6721387.html" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li><a href="http://kat.ph/wild-blood-v1-0-7-the-best-game-for-android-sd-data-bobiras2009-t6721387.html" target="_blank">Follow the link</a></li>\r\n</ul>\r\n<h2>6) N.O.V.A. 3</h2>\r\n<img class="aligncenter size-medium wp-image-106" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/N.O.V.A.-3-screenshot-300x146.jpg" alt="n-o-v-a-3-screenshot" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> FPS/Action</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftN3HM&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftN3HM&amp;hl=en</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/n-o-v-a-3-1-0-4-apk-sd-data-android-r4in-t6877151.html" target="_blank">Apk | Sd data</a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>7) NFS: Most Wanted</h2>\r\n<img class="aligncenter size-medium wp-image-113" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/Need-for-Speed-Most-Wanted-screens-300x146.jpg" alt="need-for-speed-most-wanted-screens" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Racing/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> EA Sports</li>\r\n 	<li><strong>মূল্যঃ</strong> $5.61</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.ea.games.nfs13_row" target="_blank">https://play.google.com/store/apps/details?id=com.ea.games.nfs13_row</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/need-for-speed-most-wanted-apk-sd-data-t7158049.html" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/data/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>8) PES 2012</h2>\r\n<img class="aligncenter size-medium wp-image-99" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/1pes12-android-300x169.png" alt="1pes12-android" width="300" height="169" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Sports/Simulation</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Konami</li>\r\n 	<li><strong>মূল্যঃ</strong> N/A</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> N/A</li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://www.mediafire.com/error.php?errno=320" target="_blank">Apk</a> |<a href="http://www.mediafire.com/?t9yyfqu1unv8bvc" target="_blank"> Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android/obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>9) Shadow Gun</h2>\r\n<img class="aligncenter size-medium wp-image-109" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/unnamed-1-300x147.jpg" alt="unnamed-1" width="300" height="147" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> FPS/Action/Adventure</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> MADFINGER Games</li>\r\n 	<li><strong>মূল্যঃ</strong> $4.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.madfingergames.shadowgun&amp;hl=en" target="_blank">https://play.google.com/store/apps/details?id=com.madfingergames.shadowgun&amp;hl=en</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://thepiratebay.sx/torrent/7532084/SHADOWGUN_v2.1.0_Final___SD_Data_By_bobiras2009" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li><a href="http://thepiratebay.sx/torrent/7532084/SHADOWGUN_v2.1.0_Final___SD_Data_By_bobiras2009" target="_blank">Click the link</a></li>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/Android.obb/...পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!</li>\r\n</ul>\r\n<h2>10) The Amazing Spiderman</h2>\r\n<img class="aligncenter size-medium wp-image-102" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/amazing-spiderman-galaxy-s3-300x146.jpg" alt="amazing-spiderman-galaxy-s3" width="300" height="146" />\r\n<ul>\r\n 	<li><strong>ধরনঃ</strong> Action/Adventure/Movie</li>\r\n 	<li><strong>ডেভেলপারঃ</strong> Gameloft</li>\r\n 	<li><strong>মূল্যঃ</strong> $6.99</li>\r\n 	<li><strong>গুগল প্লে লিঙ্কঃ</strong> <a href="https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftAMHM" target="_blank">https://play.google.com/store/apps/details?id=com.gameloft.android.ANMP.GloftAMHM</a></li>\r\n 	<li><strong>ফ্রী ডাউনলোড লিঙ্কঃ</strong> <a href="http://kat.ph/the-amazing-spider-man-v1-1-7-working-final-sd-data-android-t6854880.html" target="_blank">Apk | Sd data </a></li>\r\n</ul>\r\n<strong>কিভাবে ইন্সটল করবেনঃ</strong>\r\n<ul>\r\n 	<li>১) Apk ইন্সটল করুন</li>\r\n 	<li>২) Sd data নিয়ে sdcard/gameloft/games/..পেস্ট করুন</li>\r\n 	<li>৩) এখন খেলুন!\r\n\r\n<hr />\r\n\r\n</li>\r\n</ul>\r\n&nbsp;\r\n<blockquote><strong>যেকোন অ্যান্ড্রয়েড গেমস এর জন্য ভিসিট করুন আমাদের সাইট</strong>\r\n\r\n<strong><a href="http://www.lycanbd.net/2011/11/android-dvds-by-lycanbd.html" target="_blank">http://www.lycanbd.net</a>- To Download All Android Games, Apps, Wallpapers, Rigntones etc\r\n</strong>\r\n\r\n<strong><a href="http://apkgiant.com/" target="_blank">http://www.apkGiant.com</a>- Cracked Android Games &amp; Apps Apk</strong></blockquote>\r\n&nbsp;', 'সেরা ১০ এন্ড্রয়েড HD গেমস [ফ্রী ডাউনলোড]', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2016-12-01 23:09:19', '2016-12-02 05:09:19', '', 120, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/120-revision-v1/', 0, 'revision', '', 0),
(124, 4, '2016-12-01 23:15:50', '2016-12-02 05:15:50', '<img class="alignnone size-medium wp-image-100" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/753ae8936f3768920a6b6fa235603507-7-278x300.jpg" alt="753ae8936f3768920a6b6fa235603507-7" width="278" height="300" />\n\nশুক্রবার মুক্তি পেয়েছে শাহরুখ খান ও আলিয়া ভাট অভিনীত ডিয়ার জিন্দেগি। মাত্র পাঁচ দিনেই অল্প বাজেটে তৈরি এ ছবি আয় করেছে প্রায় ৫০ কোটি রুপি। শাহরুখ আর আলিয়া যে বলিউডের বক্স অফিস মাত করতে যাচ্ছেন, তা আগেই কিছুটা আঁচ করা গিয়েছিল। অথচ ছবির শুটিং শুরুর আগে এমন গুজবও শোনা গিয়েছিল যে শাহরুখের বয়স বেশি হওয়ার গৌরী শিন্ডের এই ছবিটির প্রস্তাব প্রথমে ফিরিয়ে দিয়েছিলেন ভাট-কন্যা। যদিও তাঁরা এখানে প্রেমিক-প্রেমিকার চরিত্রে অভিনয় করেননি, কিন্তু পর্দায় এই জুটির রসায়ন দারুণ জমেছে। ‘কিং খান’ আরও একবার আলিয়ার সঙ্গে জুটি বাঁধতে রাজি, তবে এর সঙ্গে একটি শর্ত জুড়ে দিয়েছেন তিনি।<!--more-->\nডিয়ার জিন্দেগি মুক্তির পর এক অনুষ্ঠানে হাজির হয়েছিলেন শাহরুখ খান। সেখানে তাঁর কাছে জানতে চাওয়া হয়, আলিয়ার সঙ্গে আবারও কোনো ছবিতে অভিনয় করার কথা ভাবছেন কি না? শাহরুখ তখন রসিকতা করে বলেন, ‘যদি বয়সে বড় এক মেয়ের সঙ্গে ছোট কোনো ছেলের প্রেমের গল্প নিয়ে ছবি হয় তাহলে হয়তো করব।’\nশাহরুখ আর আলিয়ার বয়সে বিশাল ফারাক। ডিয়ার জিন্দেগির কাহিনির প্রয়োজনে অবশ্য অসম বয়সের দুই অভিনেতা ও অভিনেত্রীকেই দরকার ছিল। এ জন্যই মজা করে এই মন্তব্যটি করেছেন কিং খান।\nঅবশ্য একটি সূত্র থেকে জানা গেছে, শুটিং চলাকালে নাকি প্রায়ই শাহরুখ-আলিয়া নিজেদের মধ্যে ছবির আইডিয়া বিনিময় করতেন। তাই ভবিষ্যতে তাঁদের জুটি হওয়ার সম্ভাবনাকে কিন্তু একেবারে উড়িয়ে দেওয়া যাচ্ছে না। দ্য ইন্ডিয়ান এক্সপ্রেস।', 'আলিয়ার সঙ্গে জুটি বাঁধতে শাহরুখের শর্ত...', '', 'inherit', 'closed', 'closed', '', '117-autosave-v1', '', '', '2016-12-01 23:15:50', '2016-12-02 05:15:50', '', 117, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/117-autosave-v1/', 0, 'revision', '', 0),
(125, 4, '2016-12-01 23:19:03', '2016-12-02 05:19:03', '<img class="alignnone size-medium wp-image-100" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/753ae8936f3768920a6b6fa235603507-7-278x300.jpg" alt="753ae8936f3768920a6b6fa235603507-7" width="278" height="300" />\r\n\r\nশুক্রবার মুক্তি পেয়েছে শাহরুখ খান ও আলিয়া ভাট অভিনীত ডিয়ার জিন্দেগি। মাত্র পাঁচ দিনেই অল্প বাজেটে তৈরি এ ছবি আয় করেছে প্রায় ৫০ কোটি রুপি। শাহরুখ আর আলিয়া যে বলিউডের বক্স অফিস মাত করতে যাচ্ছেন, তা আগেই কিছুটা আঁচ করা গিয়েছিল। অথচ ছবির শুটিং শুরুর আগে এমন গুজবও শোনা গিয়েছিল যে শাহরুখের বয়স বেশি হওয়ার গৌরী শিন্ডের এই ছবিটির প্রস্তাব প্রথমে ফিরিয়ে দিয়েছিলেন ভাট-কন্যা। যদিও তাঁরা এখানে প্রেমিক-প্রেমিকার চরিত্রে অভিনয় করেননি, কিন্তু পর্দায় এই জুটির রসায়ন দারুণ জমেছে। ‘কিং খান’ আরও একবার আলিয়ার সঙ্গে জুটি বাঁধতে রাজি, তবে এর সঙ্গে একটি শর্ত জুড়ে দিয়েছেন তিনি।<!--more-->\r\nডিয়ার জিন্দেগি মুক্তির পর এক অনুষ্ঠানে হাজির হয়েছিলেন শাহরুখ খান। সেখানে তাঁর কাছে জানতে চাওয়া হয়, আলিয়ার সঙ্গে আবারও কোনো ছবিতে অভিনয় করার কথা ভাবছেন কি না? শাহরুখ তখন রসিকতা করে বলেন, ‘যদি বয়সে বড় এক মেয়ের সঙ্গে ছোট কোনো ছেলের প্রেমের গল্প নিয়ে ছবি হয় তাহলে হয়তো করব।’\r\nশাহরুখ আর আলিয়ার বয়সে বিশাল ফারাক। ডিয়ার জিন্দেগির কাহিনির প্রয়োজনে অবশ্য অসম বয়সের দুই অভিনেতা ও অভিনেত্রীকেই দরকার ছিল। এ জন্যই মজা করে এই মন্তব্যটি করেছেন কিং খান।\r\nঅবশ্য একটি সূত্র থেকে জানা গেছে, শুটিং চলাকালে নাকি প্রায়ই শাহরুখ-আলিয়া নিজেদের মধ্যে ছবির আইডিয়া বিনিময় করতেন। তাই ভবিষ্যতে তাঁদের জুটি হওয়ার সম্ভাবনাকে কিন্তু একেবারে উড়িয়ে দেওয়া যাচ্ছে না। দ্য ইন্ডিয়ান এক্সপ্রেস।', 'আলিয়ার সঙ্গে জুটি বাঁধতে শাহরুখের শর্ত...', '', 'inherit', 'closed', 'closed', '', '117-revision-v1', '', '', '2016-12-01 23:19:03', '2016-12-02 05:19:03', '', 117, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/117-revision-v1/', 0, 'revision', '', 0),
(126, 4, '2016-12-01 23:22:39', '2016-12-02 05:22:39', '<img class="alignnone size-medium wp-image-103" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/e44e8b9dd2fad481529192093124067f-nasa-europa-300x187.jpg" alt="e44e8b9dd2fad481529192093124067f-nasa-europa" width="300" height="187" />\n\nমার্কিন মহাকাশ গবেষণা সংস্থা নাসার বিজ্ঞানীরা শিগগিরই নতুন একটি ‘চমক’ হাজির করতে যাচ্ছেন। এমন আভাস দিয়ে বলা হচ্ছে, এ চমক হতে পারে আমাদের এই সৌরজগতে এলিয়েন বা ভিনগ্রহের প্রাণীর গতিবিধি আবিষ্কারের তথ্য।<!--more-->\nবৃহস্পতির চাঁদ ইউরোপার ছবি বিশ্লেষণ করে নাসার গবেষকেরা আসছে সোমবার নাগাদ ওই উপগ্রহপৃষ্ঠের নিচে থাকা সমুদ্র সম্পর্কে তথ্য জানাতে পারেন। ১ হাজার ৯০০ মাইল প্রশস্ত এই উপগ্রহের বরফাছাওয়া খোলসের নিচে বিশাল সমুদ্র থাকতে পারে বলে মনে করছেন গবেষকেরা। এই সমুদ্র গবেষকেদের আরও বেশি আকৃষ্ট করছে ইউরোপার পাথুরে আবরণ। যার মধ্যে রাসায়নিক বিক্রিয়া ঘটানোর মতো উপাদান থাকতে পারে।\nহাবল টেলিস্কোপ ব্যবহার করে ইউরোপার নতুন এই ছবিগুলো তোলা হয়েছে। এর পাশাপাশি ইউরোপার রহস্য উদ্‌ঘাটনে সেখানে নভোযান পাঠানোর পরিকল্পনা নিয়ে কাজ করছেন গবেষকেরা। ওই মিশনে নভোযান ১ হাজার ৭০০ মাইল থেকে শুরু করে ১৬ মাইল উচ্চতায় ৪৫ বার ইউরোপাকে চক্কর দেবে। ওই মিশনের ফলেই ইউরোপার বর্তমান অবস্থার কথা জানা যাবে।\nগত মে মাসে নাসার প্লানেটারি ভূপ্রকৃতিবিদ স্টিভ ভ্যান্স বলেন, পৃথিবীর মতোই ইউরোপার সমুদ্রে অক্সিজেন ও হাইড্রোজেন চক্র সেখানকার সামুদ্রিক রসায়ন ও সেখানকার সম্ভাব্য জীবনের জন্য মূল চালিকা রূপ হতে পারে। তথ্যসূত্র: আইবিটাইমস', 'নাসার নতুন ‘চমক’ কি এলিয়েন?', '', 'inherit', 'closed', 'closed', '', '97-autosave-v1', '', '', '2016-12-01 23:22:39', '2016-12-02 05:22:39', '', 97, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/97-autosave-v1/', 0, 'revision', '', 0),
(127, 4, '2016-12-01 23:24:50', '2016-12-02 05:24:50', '<img class="alignnone size-medium wp-image-103" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/e44e8b9dd2fad481529192093124067f-nasa-europa-300x187.jpg" alt="e44e8b9dd2fad481529192093124067f-nasa-europa" width="300" height="187" />\r\n\r\nমার্কিন মহাকাশ গবেষণা সংস্থা নাসার বিজ্ঞানীরা শিগগিরই নতুন একটি ‘চমক’ হাজির করতে যাচ্ছেন। এমন আভাস দিয়ে বলা হচ্ছে, এ চমক হতে পারে আমাদের এই সৌরজগতে এলিয়েন বা ভিনগ্রহের প্রাণীর গতিবিধি আবিষ্কারের তথ্য।<!--more-->\r\nবৃহস্পতির চাঁদ ইউরোপার ছবি বিশ্লেষণ করে নাসার গবেষকেরা আসছে সোমবার নাগাদ ওই উপগ্রহপৃষ্ঠের নিচে থাকা সমুদ্র সম্পর্কে তথ্য জানাতে পারেন। ১ হাজার ৯০০ মাইল প্রশস্ত এই উপগ্রহের বরফাছাওয়া খোলসের নিচে বিশাল সমুদ্র থাকতে পারে বলে মনে করছেন গবেষকেরা। এই সমুদ্র গবেষকেদের আরও বেশি আকৃষ্ট করছে ইউরোপার পাথুরে আবরণ। যার মধ্যে রাসায়নিক বিক্রিয়া ঘটানোর মতো উপাদান থাকতে পারে।\r\nহাবল টেলিস্কোপ ব্যবহার করে ইউরোপার নতুন এই ছবিগুলো তোলা হয়েছে। এর পাশাপাশি ইউরোপার রহস্য উদ্‌ঘাটনে সেখানে নভোযান পাঠানোর পরিকল্পনা নিয়ে কাজ করছেন গবেষকেরা। ওই মিশনে নভোযান ১ হাজার ৭০০ মাইল থেকে শুরু করে ১৬ মাইল উচ্চতায় ৪৫ বার ইউরোপাকে চক্কর দেবে। ওই মিশনের ফলেই ইউরোপার বর্তমান অবস্থার কথা জানা যাবে।\r\nগত মে মাসে নাসার প্লানেটারি ভূপ্রকৃতিবিদ স্টিভ ভ্যান্স বলেন, পৃথিবীর মতোই ইউরোপার সমুদ্রে অক্সিজেন ও হাইড্রোজেন চক্র সেখানকার সামুদ্রিক রসায়ন ও সেখানকার সম্ভাব্য জীবনের জন্য মূল চালিকা রূপ হতে পারে। তথ্যসূত্র: আইবিটাইমস', 'নাসার নতুন ‘চমক’ কি এলিয়েন?', '', 'inherit', 'closed', 'closed', '', '97-revision-v1', '', '', '2016-12-01 23:24:50', '2016-12-02 05:24:50', '', 97, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/97-revision-v1/', 0, 'revision', '', 0),
(128, 4, '2016-12-01 23:27:35', '2016-12-02 05:27:35', '<img class="alignnone size-medium wp-image-101" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/a85e33a58106a8db419e7cb8145c4696-Untitled-17-300x264.jpg" alt="a85e33a58106a8db419e7cb8145c4696-untitled-17" width="300" height="264" />\n\nপ্রথম সপ্তাহেই মারভেলের ছবি <em>ডক্টর স্ট্রেঞ্জ </em>যুক্তরাষ্ট্রেরবক্স অফিসে সাড়ে আট কোটি ডলারেরও বেশি আয় করেছে। নয় অঙ্কের যুগে এ সাফল্য কম মনে হতে পারে, কিন্তু এই নভেম্বরে মুক্তি পাওয়া ছবির জন্য এ সাফল্য বেশ বড়ই। মার্কিনরা এখন ব্যস্ত প্রেসিডেন্ট নির্বাচন নিয়ে, সিনেমা দেখা এখন অগ্রাধিকারের তালিকায় নেই। তাঁদের এবারের নির্বাচনই তো সিনেমাটিক উপাদানে ভরপুর!<!--more-->\n<p class="TEXT">তার ওপর এটি চিরাচরিত সুপারহিরো ছবিও নয়। মারভেলের এই কমিক বই সিরিজ তাদের অন্য সুপারহিরোদের মতো সুপরিচিত নয়। সে হিসেবে <em>ডক্টর স্ট্রেঞ্জ </em>শুধুবক্স অফিসের প্রত্যাশা বেশ ভালোভাবেই মিটিয়েছে। সিনেমা রেটিংয়ের সাইট রোটেন টমেটোসে দেখা যাচ্ছে, শীর্ষ চলচ্চিত্র সমালোচকদের মধ্যে ৮৭ ভাগ এ ছবি পছন্দ করেছেন।</p>\n<p class="TEXT">এই সাফল্যের অনেকটা কৃতিত্ব বেনেডিক্ট কাম্বারব্যাচকে দেওয়া যেতেই পারে। শার্লক হোমস চরিত্রে অভিনয় করে তুমুল জনপ্রিয়তা পাওয়া এ অভিনেতাই এই ছবির ডক্টর স্ট্রেঞ্জ। তাঁর অভিনয় সমালোচকদেরও প্রশংসা কুড়িয়েছে। খল অভিনেতার চরিত্রে শিওটেল এজিওফরও দারুণ অভিনয় করেছেন। বলা হচ্ছে, <em>থর </em>ছবির লোকির (টম হিডলস্টোন অভিনয় করেছিলেন এ চরিত্রে) পর আর কোনো ভিলেন এমন করে দর্শক ও সমালোচক হৃদয় জয় করতে পারেননি।</p>\n<p class="TEXT">এই ছবির সাফল্য আরও প্রমাণ করছে হলিউডে ভিন্নধর্মী সুপারহিরোর ছবির কদর বাড়ছে। <em>ব্যাটম্যান</em>, <em>সুপারম্যান</em>, <em>আয়রনম্যান</em>-এর মতো ভরপুর অ্যাকশন ও অতিমানবিক সুপারহিরোদের দর্শকেরা আর পছন্দ করছেন না। <em>ডক্টর স্ট্রেঞ্জ</em>-এ অস্ত্রের ঝনঝনানি নেই, অন্য মারভেল ছবির মতো শেষ দৃশ্যে নায়ক-খলনায়কের মারামারিতে একটি গোটা শহর ধ্বংসস্তূপে পরিণত হয় না। ছবিতে পৃথিবীর অন্য দিক উন্মোচিত হয় দর্শকের সামনে।</p>\n<p class="TEXT">২০১৫ সালে <em>অ্যান্ট-ম্যান </em>নামের আরেকটি ভিন্নধর্মী হলিউড ছবিও বক্স অফিসে সাফল্য পেয়েছিল। <em>ডক্টর স্ট্রেঞ্জ</em>-এর সাফল্য তাকে ছাড়িয়ে গেছে। আশা করা হচ্ছে, <em>অ্যান্ট-ম্যান অ্যান্ড দ্য ওয়াসপ </em>আরও ভালো ব্যবসা করবে। এরই মধ্যে <em>ডক্টর স্ট্রেঞ্জ</em>-এর সিক্যুয়েল ছবি নির্মাণের কথা ভাবা শুরু করেছেন নির্মাতা স্কট ডেরিকসন। বলা যেতে পারে, এমন ছবির সাফল্যকে নিবিড়ভাবে পর্যবেক্ষণ করছেন হলিউডের বাণিজ্য বিশ্লেষকেরা।</p>\n<p class="TEXT"><strong>প্রণব ভৌমিক</strong></p>\n<p class="TEXT">এবিসি নিউজ, সিনেমাব্লেন্ড, অয়ারড, দ্য ভার্জ অবলম্বনে।</p>', 'ডক্টর স্ট্রেঞ্জের ‘স্ট্রেঞ্জ’ সাফল্য!', '', 'inherit', 'closed', 'closed', '', '114-autosave-v1', '', '', '2016-12-01 23:27:35', '2016-12-02 05:27:35', '', 114, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/114-autosave-v1/', 0, 'revision', '', 0);
INSERT INTO `tbl_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(129, 4, '2016-12-01 23:31:08', '2016-12-02 05:31:08', '<img class="alignnone size-medium wp-image-101" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/a85e33a58106a8db419e7cb8145c4696-Untitled-17-300x264.jpg" alt="a85e33a58106a8db419e7cb8145c4696-untitled-17" width="300" height="264" />\r\n\r\nপ্রথম সপ্তাহেই মারভেলের ছবি <em>ডক্টর স্ট্রেঞ্জ </em>যুক্তরাষ্ট্রেরবক্স অফিসে সাড়ে আট কোটি ডলারেরও বেশি আয় করেছে। নয় অঙ্কের যুগে এ সাফল্য কম মনে হতে পারে, কিন্তু এই নভেম্বরে মুক্তি পাওয়া ছবির জন্য এ সাফল্য বেশ বড়ই। মার্কিনরা এখন ব্যস্ত প্রেসিডেন্ট নির্বাচন নিয়ে, সিনেমা দেখা এখন অগ্রাধিকারের তালিকায় নেই। তাঁদের এবারের নির্বাচনই তো সিনেমাটিক উপাদানে ভরপুর!<!--more-->\r\n<p class="TEXT">তার ওপর এটি চিরাচরিত সুপারহিরো ছবিও নয়। মারভেলের এই কমিক বই সিরিজ তাদের অন্য সুপারহিরোদের মতো সুপরিচিত নয়। সে হিসেবে <em>ডক্টর স্ট্রেঞ্জ </em>শুধুবক্স অফিসের প্রত্যাশা বেশ ভালোভাবেই মিটিয়েছে। সিনেমা রেটিংয়ের সাইট রোটেন টমেটোসে দেখা যাচ্ছে, শীর্ষ চলচ্চিত্র সমালোচকদের মধ্যে ৮৭ ভাগ এ ছবি পছন্দ করেছেন।</p>\r\n<p class="TEXT">এই সাফল্যের অনেকটা কৃতিত্ব বেনেডিক্ট কাম্বারব্যাচকে দেওয়া যেতেই পারে। শার্লক হোমস চরিত্রে অভিনয় করে তুমুল জনপ্রিয়তা পাওয়া এ অভিনেতাই এই ছবির ডক্টর স্ট্রেঞ্জ। তাঁর অভিনয় সমালোচকদেরও প্রশংসা কুড়িয়েছে। খল অভিনেতার চরিত্রে শিওটেল এজিওফরও দারুণ অভিনয় করেছেন। বলা হচ্ছে, <em>থর </em>ছবির লোকির (টম হিডলস্টোন অভিনয় করেছিলেন এ চরিত্রে) পর আর কোনো ভিলেন এমন করে দর্শক ও সমালোচক হৃদয় জয় করতে পারেননি।</p>\r\n<p class="TEXT">এই ছবির সাফল্য আরও প্রমাণ করছে হলিউডে ভিন্নধর্মী সুপারহিরোর ছবির কদর বাড়ছে। <em>ব্যাটম্যান</em>, <em>সুপারম্যান</em>, <em>আয়রনম্যান</em>-এর মতো ভরপুর অ্যাকশন ও অতিমানবিক সুপারহিরোদের দর্শকেরা আর পছন্দ করছেন না। <em>ডক্টর স্ট্রেঞ্জ</em>-এ অস্ত্রের ঝনঝনানি নেই, অন্য মারভেল ছবির মতো শেষ দৃশ্যে নায়ক-খলনায়কের মারামারিতে একটি গোটা শহর ধ্বংসস্তূপে পরিণত হয় না। ছবিতে পৃথিবীর অন্য দিক উন্মোচিত হয় দর্শকের সামনে।</p>\r\n<p class="TEXT">২০১৫ সালে <em>অ্যান্ট-ম্যান </em>নামের আরেকটি ভিন্নধর্মী হলিউড ছবিও বক্স অফিসে সাফল্য পেয়েছিল। <em>ডক্টর স্ট্রেঞ্জ</em>-এর সাফল্য তাকে ছাড়িয়ে গেছে। আশা করা হচ্ছে, <em>অ্যান্ট-ম্যান অ্যান্ড দ্য ওয়াসপ </em>আরও ভালো ব্যবসা করবে। এরই মধ্যে <em>ডক্টর স্ট্রেঞ্জ</em>-এর সিক্যুয়েল ছবি নির্মাণের কথা ভাবা শুরু করেছেন নির্মাতা স্কট ডেরিকসন। বলা যেতে পারে, এমন ছবির সাফল্যকে নিবিড়ভাবে পর্যবেক্ষণ করছেন হলিউডের বাণিজ্য বিশ্লেষকেরা।</p>\r\n<p class="TEXT"><strong>প্রণব ভৌমিক</strong></p>\r\n<p class="TEXT">এবিসি নিউজ, সিনেমাব্লেন্ড, অয়ারড, দ্য ভার্জ অবলম্বনে।</p>', 'ডক্টর স্ট্রেঞ্জের ‘স্ট্রেঞ্জ’ সাফল্য!', '', 'inherit', 'closed', 'closed', '', '114-revision-v1', '', '', '2016-12-01 23:31:08', '2016-12-02 05:31:08', '', 114, 'http://localhost:81/wp_mahmuds_pachal/2016/12/01/114-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2016-12-02 00:22:13', '2016-12-02 06:22:13', '<img class="aligncenter size-medium wp-image-131" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/af77dc73f31995b457dc2e457ba3fb33-4-193x300.jpg" alt="af77dc73f31995b457dc2e457ba3fb33-4" width="193" height="300">\r\n\r\nমোহিত সুরির হাফ গার্লফ্রেন্ড ছবির প্রধান অভিনেত্রী শ্রদ্ধা কাপুর। কিন্তু এই চরিত্রের জন্য নির্মাতা প্রথমে প্রস্তাব দিয়েছিলেন ক্যাটরিনা কাইফকে। ছবির গল্প বেশ পছন্দও হয়েছিল ক্যাটের। কিন্তু তিনিই নাকি মোহিতকে তাঁর পরিবর্তে অন্য কোনো নায়িকা নেওয়ার পরামর্শ দেন। ছবির চিত্রনাট্য ভালো লাগার পরও ক্যাট কেন এই ছবিতে অভিনয় করলেন না? সম্প্রতি পাওয়া গেছে সেই প্রশ্নের উত্তর।<!--more-->\r\n\r\nহাফ গার্লফ্রেন্ড ছবির অভিনেতা অর্জুন কাপুর। ক্যাটরিনার ধারণা, পর্দায় অর্জুনের পাশে তাঁকে বেশি বয়স্ক দেখাবে। যদিও বাস্তবে ক্যাট এই নায়কের থেকে দুই বছরের বড়। সম্প্রতি মুক্তি পাওয়া বার বার দেখো ছবিতে সিদ্ধার্থ মালহোত্রাকে ক্যাটের পাশে বেশি ছোট লেগেছে বলে মনে করছেন অনেকেই। অর্জুন আর সিদ্ধার্থ সমবয়সী তারকা।\r\n\r\nআর তাই ছবির স্বার্থে ক্যাটরিনা নিজে থেকেই নির্মাতাকে নায়িকা বদলের পরামর্শ দেন। ক্যাটরিনার এমন ঔদার্যে মুগ্ধ হয়ে গেছেন মোহিত। আর মুগ্ধ হবেনই বা না কেন? পছন্দের চরিত্রে কাজ করার লোভ সংবরণ করে যে অভিনেত্রী তাঁর জায়গায় অন্য কোনো অভিনেত্রীকে নেওয়ার পরামর্শ দেন, তিনি তো অবশ্যই বড় মনের মানুষ।\r\n\r\nমোহিত সুরিও অবশ্য নায়িকার এই আচরণে মুগ্ধ হয়ে তাঁকে কথা দিয়ে এসেছেন যে তাঁর পরবর্তী ছবিতে আকর্ষণীয় কোনো চরিত্রে ক্যাটরিনাকে নেবেন। হাফ গার্লফ্রেন্ড ছবিটি চেতন ভগতের একই নামের উপন্যাস অবলম্বনে তৈরি হচ্ছে। এটি মুক্তি পাবে ২০১৭ সালের মে মাসে। বলিউড বাবল।', 'ক্যাটরিনার ঔদার্য', '', 'publish', 'open', 'open', '', '%e0%a6%95%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%9f%e0%a6%b0%e0%a6%bf%e0%a6%a8%e0%a6%be%e0%a6%b0-%e0%a6%94%e0%a6%a6%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%af', '', '', '2016-12-02 00:22:13', '2016-12-02 06:22:13', '', 0, 'http://localhost:81/wp_mahmuds_pachal/?p=130', 0, 'post', '', 1),
(131, 1, '2016-12-02 00:16:18', '2016-12-02 06:16:18', '', 'af77dc73f31995b457dc2e457ba3fb33-4', '', 'inherit', 'open', 'closed', '', 'af77dc73f31995b457dc2e457ba3fb33-4', '', '', '2016-12-02 00:16:18', '2016-12-02 06:16:18', '', 130, 'http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/af77dc73f31995b457dc2e457ba3fb33-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(132, 1, '2016-12-02 00:22:13', '2016-12-02 06:22:13', '<img class="aligncenter size-medium wp-image-131" src="http://localhost:81/wp_mahmuds_pachal/wp-content/uploads/2016/12/af77dc73f31995b457dc2e457ba3fb33-4-193x300.jpg" alt="af77dc73f31995b457dc2e457ba3fb33-4" width="193" height="300">\r\n\r\nমোহিত সুরির হাফ গার্লফ্রেন্ড ছবির প্রধান অভিনেত্রী শ্রদ্ধা কাপুর। কিন্তু এই চরিত্রের জন্য নির্মাতা প্রথমে প্রস্তাব দিয়েছিলেন ক্যাটরিনা কাইফকে। ছবির গল্প বেশ পছন্দও হয়েছিল ক্যাটের। কিন্তু তিনিই নাকি মোহিতকে তাঁর পরিবর্তে অন্য কোনো নায়িকা নেওয়ার পরামর্শ দেন। ছবির চিত্রনাট্য ভালো লাগার পরও ক্যাট কেন এই ছবিতে অভিনয় করলেন না? সম্প্রতি পাওয়া গেছে সেই প্রশ্নের উত্তর।<!--more-->\r\n\r\nহাফ গার্লফ্রেন্ড ছবির অভিনেতা অর্জুন কাপুর। ক্যাটরিনার ধারণা, পর্দায় অর্জুনের পাশে তাঁকে বেশি বয়স্ক দেখাবে। যদিও বাস্তবে ক্যাট এই নায়কের থেকে দুই বছরের বড়। সম্প্রতি মুক্তি পাওয়া বার বার দেখো ছবিতে সিদ্ধার্থ মালহোত্রাকে ক্যাটের পাশে বেশি ছোট লেগেছে বলে মনে করছেন অনেকেই। অর্জুন আর সিদ্ধার্থ সমবয়সী তারকা।\r\n\r\nআর তাই ছবির স্বার্থে ক্যাটরিনা নিজে থেকেই নির্মাতাকে নায়িকা বদলের পরামর্শ দেন। ক্যাটরিনার এমন ঔদার্যে মুগ্ধ হয়ে গেছেন মোহিত। আর মুগ্ধ হবেনই বা না কেন? পছন্দের চরিত্রে কাজ করার লোভ সংবরণ করে যে অভিনেত্রী তাঁর জায়গায় অন্য কোনো অভিনেত্রীকে নেওয়ার পরামর্শ দেন, তিনি তো অবশ্যই বড় মনের মানুষ।\r\n\r\nমোহিত সুরিও অবশ্য নায়িকার এই আচরণে মুগ্ধ হয়ে তাঁকে কথা দিয়ে এসেছেন যে তাঁর পরবর্তী ছবিতে আকর্ষণীয় কোনো চরিত্রে ক্যাটরিনাকে নেবেন। হাফ গার্লফ্রেন্ড ছবিটি চেতন ভগতের একই নামের উপন্যাস অবলম্বনে তৈরি হচ্ছে। এটি মুক্তি পাবে ২০১৭ সালের মে মাসে। বলিউড বাবল।', 'ক্যাটরিনার ঔদার্য', '', 'inherit', 'closed', 'closed', '', '130-revision-v1', '', '', '2016-12-02 00:22:13', '2016-12-02 06:22:13', '', 130, 'http://localhost:81/wp_mahmuds_pachal/2016/12/02/130-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_signups`
--

CREATE TABLE IF NOT EXISTS `tbl_signups` (
  `signup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activation_key` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `meta` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`signup_id`),
  KEY `activation_key` (`activation_key`),
  KEY `user_email` (`user_email`),
  KEY `user_login_email` (`user_login`,`user_email`),
  KEY `domain_path` (`domain`(140),`path`(51))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_signups`
--

INSERT INTO `tbl_signups` (`signup_id`, `domain`, `path`, `title`, `user_login`, `user_email`, `registered`, `activated`, `active`, `activation_key`, `meta`) VALUES
(1, '', '', '', 'subscriber1', 'subscriber1@gmail.com', '2016-12-01 20:24:00', '2016-12-01 20:27:00', 1, 'X4EMVNQA5K2QKo0GiPC9WEGtDgXWEEOf', 'a:4:{s:7:"field_1";s:10:"Subscriber";s:18:"field_1_visibility";s:6:"public";s:17:"profile_field_ids";s:1:"1";s:8:"password";s:34:"$P$B9ajFzBpChuRXrqhCK4iGynA8ywnRi1";}'),
(2, '', '', '', 'subscriber2', 'subscriber2@gmail.com', '2016-12-01 20:25:19', '0000-00-00 00:00:00', 0, 'tXnIS0dVuHWaRZsr4F64BHV1kLk1Eojl', 'a:4:{s:7:"field_1";s:10:"Subscriber";s:18:"field_1_visibility";s:6:"public";s:17:"profile_field_ids";s:1:"1";s:8:"password";s:34:"$P$BcwEg6UslUhg.Oybz2Loc5SR1vluVI/";}');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subscribe_reloaded_subscribers`
--

CREATE TABLE IF NOT EXISTS `tbl_subscribe_reloaded_subscribers` (
  `stcr_id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `salt` int(15) NOT NULL,
  `subscriber_unique_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`stcr_id`),
  UNIQUE KEY `uk_subscriber_email` (`subscriber_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_subscribe_reloaded_subscribers`
--

INSERT INTO `tbl_subscribe_reloaded_subscribers` (`stcr_id`, `subscriber_email`, `salt`, `subscriber_unique_id`, `add_date`) VALUES
(1, 'subscriber1@gmail.com', 1480624326, 'f5d0e36d9104ca730edff992624f9e32', '2016-12-01 20:32:06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_termmeta`
--

CREATE TABLE IF NOT EXISTS `tbl_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_terms`
--

CREATE TABLE IF NOT EXISTS `tbl_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tbl_terms`
--

INSERT INTO `tbl_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Menu', 'menu', 0),
(3, 'activity-comment', 'activity-comment', 0),
(4, 'activity-comment-author', 'activity-comment-author', 0),
(5, 'activity-at-message', 'activity-at-message', 0),
(6, 'groups-at-message', 'groups-at-message', 0),
(7, 'core-user-registration', 'core-user-registration', 0),
(8, 'core-user-registration-with-blog', 'core-user-registration-with-blog', 0),
(9, 'friends-request', 'friends-request', 0),
(10, 'friends-request-accepted', 'friends-request-accepted', 0),
(11, 'groups-details-updated', 'groups-details-updated', 0),
(12, 'groups-invitation', 'groups-invitation', 0),
(13, 'groups-member-promoted', 'groups-member-promoted', 0),
(15, 'groups-membership-request', 'groups-membership-request', 0),
(17, 'messages-unread', 'messages-unread', 0),
(18, 'settings-verify-email-change', 'settings-verify-email-change', 0),
(20, 'groups-membership-request-accepted', 'groups-membership-request-accepted', 0),
(22, 'groups-membership-request-rejected', 'groups-membership-request-rejected', 0),
(23, 'আমার কথা', 'me', 0),
(24, 'বিজ্ঞান ও প্রযুক্তি', 'science', 0),
(25, 'তথ্য- প্রযুক্তি', 'it', 0),
(26, 'বিনোদন', 'entertainment', 0),
(27, 'বলিউড', 'bollywood', 0),
(28, 'মহাকাশ বিজ্ঞান', 'astronomy', 0),
(29, 'হলিউড', 'hollywood', 0),
(30, 'ছবি', 'photo', 0),
(31, 'নাসা', '%e0%a6%a8%e0%a6%be%e0%a6%b8%e0%a6%be', 0),
(32, 'এলিয়েন', '%e0%a6%8f%e0%a6%b2%e0%a6%bf%e0%a7%9f%e0%a7%87%e0%a6%a8', 0),
(33, 'মারভেল', '%e0%a6%ae%e0%a6%be%e0%a6%b0%e0%a6%ad%e0%a7%87%e0%a6%b2', 0),
(34, 'ডক্টর', '%e0%a6%a1%e0%a6%95%e0%a7%8d%e0%a6%9f%e0%a6%b0', 0),
(35, 'স্ট্রেঞ্জ', '%e0%a6%b8%e0%a7%8d%e0%a6%9f%e0%a7%8d%e0%a6%b0%e0%a7%87%e0%a6%9e%e0%a7%8d%e0%a6%9c', 0),
(36, 'সুপারহিরো', '%e0%a6%b8%e0%a7%81%e0%a6%aa%e0%a6%be%e0%a6%b0%e0%a6%b9%e0%a6%bf%e0%a6%b0%e0%a7%8b', 0),
(37, 'সিনেমা', '%e0%a6%b8%e0%a6%bf%e0%a6%a8%e0%a7%87%e0%a6%ae%e0%a6%be', 0),
(38, 'বেনেডিক্ট', '%e0%a6%ac%e0%a7%87%e0%a6%a8%e0%a7%87%e0%a6%a1%e0%a6%bf%e0%a6%95%e0%a7%8d%e0%a6%9f', 0),
(39, 'কাম্বারব্যাচ', '%e0%a6%95%e0%a6%be%e0%a6%ae%e0%a7%8d%e0%a6%ac%e0%a6%be%e0%a6%b0%e0%a6%ac%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%9a', 0),
(40, 'শাহরুখ', '%e0%a6%b6%e0%a6%be%e0%a6%b9%e0%a6%b0%e0%a7%81%e0%a6%96', 0),
(41, 'আলিয়া', '%e0%a6%86%e0%a6%b2%e0%a6%bf%e0%a7%9f%e0%a6%be', 0),
(42, 'ডিয়ার', '%e0%a6%a1%e0%a6%bf%e0%a7%9f%e0%a6%be%e0%a6%b0', 0),
(43, 'জিন্দেগি', '%e0%a6%9c%e0%a6%bf%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%87%e0%a6%97%e0%a6%bf', 0),
(44, 'এন্ড্রয়েড', '%e0%a6%8f%e0%a6%a8%e0%a7%8d%e0%a6%a1%e0%a7%8d%e0%a6%b0%e0%a7%9f%e0%a7%87%e0%a6%a1', 0),
(45, 'এইচডি', '%e0%a6%8f%e0%a6%87%e0%a6%9a%e0%a6%a1%e0%a6%bf', 0),
(46, 'গেমস', '%e0%a6%97%e0%a7%87%e0%a6%ae%e0%a6%b8', 0),
(47, 'ক্যাটরিনা', '%e0%a6%95%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%9f%e0%a6%b0%e0%a6%bf%e0%a6%a8%e0%a6%be', 0),
(48, 'হাফ', '%e0%a6%b9%e0%a6%be%e0%a6%ab', 0),
(49, 'গার্লফ্রেন্ড', '%e0%a6%97%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%b2%e0%a6%ab%e0%a7%8d%e0%a6%b0%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_relationships`
--

CREATE TABLE IF NOT EXISTS `tbl_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `tbl_term_relationships`
--

INSERT INTO `tbl_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(12, 2, 0),
(13, 2, 0),
(14, 3, 0),
(15, 4, 0),
(16, 5, 0),
(17, 3, 0),
(18, 6, 0),
(19, 4, 0),
(20, 7, 0),
(21, 5, 0),
(22, 6, 0),
(23, 8, 0),
(24, 7, 0),
(25, 9, 0),
(26, 8, 0),
(27, 9, 0),
(28, 10, 0),
(29, 10, 0),
(30, 11, 0),
(31, 11, 0),
(32, 12, 0),
(33, 12, 0),
(34, 13, 0),
(35, 13, 0),
(36, 15, 0),
(37, 15, 0),
(38, 17, 0),
(39, 17, 0),
(40, 18, 0),
(41, 18, 0),
(42, 20, 0),
(43, 20, 0),
(44, 22, 0),
(45, 22, 0),
(47, 2, 0),
(73, 2, 0),
(75, 2, 0),
(77, 2, 0),
(81, 2, 0),
(97, 28, 0),
(97, 31, 0),
(97, 32, 0),
(114, 29, 0),
(114, 33, 0),
(114, 34, 0),
(114, 35, 0),
(114, 36, 0),
(114, 37, 0),
(114, 38, 0),
(114, 39, 0),
(117, 27, 0),
(117, 40, 0),
(117, 41, 0),
(117, 42, 0),
(117, 43, 0),
(119, 1, 0),
(120, 25, 0),
(120, 44, 0),
(120, 45, 0),
(120, 46, 0),
(130, 27, 0),
(130, 47, 0),
(130, 48, 0),
(130, 49, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `tbl_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tbl_term_taxonomy`
--

INSERT INTO `tbl_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 7),
(3, 3, 'bp-email-type', 'A member has replied to an activity update that the recipient posted.', 0, 2),
(4, 4, 'bp-email-type', 'A member has replied to a comment on an activity update that the recipient posted.', 0, 2),
(5, 5, 'bp-email-type', 'Recipient was mentioned in an activity update.', 0, 2),
(6, 6, 'bp-email-type', 'Recipient was mentioned in a group activity update.', 0, 2),
(7, 7, 'bp-email-type', 'Recipient has registered for an account.', 0, 2),
(8, 8, 'bp-email-type', 'Recipient has registered for an account and site.', 0, 2),
(9, 9, 'bp-email-type', 'A member has sent a friend request to the recipient.', 0, 2),
(10, 10, 'bp-email-type', 'Recipient has had a friend request accepted by a member.', 0, 2),
(11, 11, 'bp-email-type', 'A group''s details were updated.', 0, 2),
(12, 12, 'bp-email-type', 'A member has sent a group invitation to the recipient.', 0, 2),
(13, 13, 'bp-email-type', 'Recipient''s status within a group has changed.', 0, 2),
(15, 15, 'bp-email-type', 'A member has requested permission to join a group.', 0, 2),
(17, 17, 'bp-email-type', 'Recipient has received a private message.', 0, 2),
(18, 18, 'bp-email-type', 'Recipient has changed their email address.', 0, 2),
(20, 20, 'bp-email-type', 'Recipient had requested to join a group, which was accepted.', 0, 2),
(22, 22, 'bp-email-type', 'Recipient had requested to join a group, which was rejected.', 0, 2),
(23, 23, 'category', 'It is about my speech.', 0, 0),
(24, 24, 'category', 'All the posts are about science.', 0, 0),
(25, 25, 'category', 'All the news are about Information Technology.', 24, 1),
(26, 26, 'category', 'All the news are about entertainment, বিনোদন.', 0, 0),
(27, 27, 'category', 'All the news of bollywood are available here.', 26, 2),
(28, 28, 'category', 'All the posts are about astronomy', 24, 1),
(29, 29, 'category', 'All the news of hollywood are available here.', 26, 1),
(30, 30, 'category', 'All the photos are available here.', 0, 0),
(31, 31, 'post_tag', '', 0, 1),
(32, 32, 'post_tag', '', 0, 1),
(33, 33, 'post_tag', '', 0, 1),
(34, 34, 'post_tag', '', 0, 1),
(35, 35, 'post_tag', '', 0, 1),
(36, 36, 'post_tag', '', 0, 1),
(37, 37, 'post_tag', '', 0, 1),
(38, 38, 'post_tag', '', 0, 1),
(39, 39, 'post_tag', '', 0, 1),
(40, 40, 'post_tag', '', 0, 1),
(41, 41, 'post_tag', '', 0, 1),
(42, 42, 'post_tag', '', 0, 1),
(43, 43, 'post_tag', '', 0, 1),
(44, 44, 'post_tag', '', 0, 1),
(45, 45, 'post_tag', '', 0, 1),
(46, 46, 'post_tag', '', 0, 1),
(47, 47, 'post_tag', '', 0, 1),
(48, 48, 'post_tag', '', 0, 1),
(49, 49, 'post_tag', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_usermeta`
--

CREATE TABLE IF NOT EXISTS `tbl_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=163 ;

--
-- Dumping data for table `tbl_usermeta`
--

INSERT INTO `tbl_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'cse.mahmud'),
(2, 1, 'first_name', 'Mahmudul Hasan'),
(3, 1, 'last_name', 'Khan'),
(4, 1, 'description', 'I am a programmer and a web developer.'),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'true'),
(7, 1, 'admin_color', 'blue'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'tbl_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'tbl_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:5:{s:64:"1aa75a1d050627c01041c96f1e14c645e4313f19b7f6a36670a4058a135e677d";a:4:{s:10:"expiration";i:1480744328;s:2:"ip";s:3:"::1";s:2:"ua";s:108:"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.10 Safari/537.36";s:5:"login";i:1480571528;}s:64:"54121e3d83cfd52eb68b9c0f051e777dfaa29f0c7173182390271945d898a442";a:4:{s:10:"expiration";i:1480787722;s:2:"ip";s:3:"::1";s:2:"ua";s:108:"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.10 Safari/537.36";s:5:"login";i:1480614922;}s:64:"7c660da063272f5a0cb9c4c77dee585137b9c32fb113698d785e9e6a9dcda05b";a:4:{s:10:"expiration";i:1480795415;s:2:"ip";s:3:"::1";s:2:"ua";s:108:"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.10 Safari/537.36";s:5:"login";i:1480622615;}s:64:"40b3c73ab3f8a79d86fd968310a74ff5912488b4d681aad889ed88faf7f1ddd3";a:4:{s:10:"expiration";i:1480853212;s:2:"ip";s:3:"::1";s:2:"ua";s:108:"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.10 Safari/537.36";s:5:"login";i:1480680412;}s:64:"a9f2af5133528c431c265e72399faeb9c857301f5d97b856ad253db81b6e45be";a:4:{s:10:"expiration";i:1480876381;s:2:"ip";s:3:"::1";s:2:"ua";s:108:"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.10 Safari/537.36";s:5:"login";i:1480703581;}}'),
(15, 1, 'tbl_user-settings', 'libraryContent=browse&hidetb=1&widgets_access=on&mfold=o&align=center&urlbutton=custom&editor=tinymce'),
(16, 1, 'tbl_user-settings-time', '1480620903'),
(17, 1, 'tbl_dashboard_quick_press_last_post_id', '3'),
(18, 1, 'tbl_yoast_notifications', 'a:2:{i:0;a:2:{s:7:"message";s:145:"Since you are new to Yoast SEO you can configure the <a href="http://localhost:81/wp_mahmuds_pachal/wp-admin/?page=wpseo_configurator">plugin</a>";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:31:"wpseo-dismiss-onboarding-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:180:"Don''t miss your crawl errors: <a href="http://localhost:81/wp_mahmuds_pachal/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}'),
(19, 1, 'aioseop_seen_about_page', '2.3.11'),
(20, 1, 'aioseop_yst_detected_notice_dismissed', '1'),
(21, 1, 'last_activity', '2016-12-02 19:26:10'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(24, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:23:"add-buddypress-nav-menu";i:1;s:12:"add-post_tag";i:2;s:11:"add-ngg_tag";}'),
(25, 2, 'nickname', 'contributor'),
(26, 2, 'first_name', 'Contributor'),
(27, 2, 'last_name', ''),
(28, 2, 'description', ''),
(29, 2, 'rich_editing', 'true'),
(30, 2, 'comment_shortcuts', 'false'),
(31, 2, 'admin_color', 'fresh'),
(32, 2, 'use_ssl', '0'),
(33, 2, 'show_admin_bar_front', 'true'),
(34, 2, 'tbl_capabilities', 'a:1:{s:11:"contributor";b:1;}'),
(35, 2, 'tbl_user_level', '1'),
(36, 2, '_yoast_wpseo_profile_updated', '1480703850'),
(37, 2, 'dismissed_wp_pointers', ''),
(38, 3, 'nickname', 'author'),
(39, 3, 'first_name', 'Author'),
(40, 3, 'last_name', ''),
(41, 3, 'description', ''),
(42, 3, 'rich_editing', 'true'),
(43, 3, 'comment_shortcuts', 'false'),
(44, 3, 'admin_color', 'fresh'),
(45, 3, 'use_ssl', '0'),
(46, 3, 'show_admin_bar_front', 'true'),
(47, 3, 'tbl_capabilities', 'a:1:{s:6:"author";b:1;}'),
(48, 3, 'tbl_user_level', '2'),
(49, 3, '_yoast_wpseo_profile_updated', '1480703781'),
(50, 3, 'dismissed_wp_pointers', ''),
(51, 3, 'wpseo_title', ''),
(52, 3, 'wpseo_metadesc', ''),
(53, 3, 'wpseo_metakey', ''),
(54, 3, 'wpseo_excludeauthorsitemap', ''),
(55, 3, 'wpseo_content_analysis_disable', ''),
(56, 3, 'wpseo_keyword_analysis_disable', ''),
(57, 3, 'googleplus', ''),
(58, 3, 'twitter', ''),
(59, 3, 'facebook', ''),
(60, 4, 'nickname', 'editor'),
(61, 4, 'first_name', 'Editor'),
(62, 4, 'last_name', ''),
(63, 4, 'description', ''),
(64, 4, 'rich_editing', 'true'),
(65, 4, 'comment_shortcuts', 'false'),
(66, 4, 'admin_color', 'fresh'),
(67, 4, 'use_ssl', '0'),
(68, 4, 'show_admin_bar_front', 'true'),
(69, 4, 'tbl_capabilities', 'a:1:{s:6:"editor";b:1;}'),
(70, 4, 'tbl_user_level', '7'),
(71, 4, '_yoast_wpseo_profile_updated', '1480703977'),
(72, 4, 'dismissed_wp_pointers', ''),
(74, 2, 'tbl_user-settings', 'libraryContent=browse'),
(75, 2, 'tbl_user-settings-time', '1480605430'),
(76, 2, 'tbl_dashboard_quick_press_last_post_id', '83'),
(78, 3, 'tbl_user-settings', 'libraryContent=browse'),
(79, 3, 'tbl_user-settings-time', '1480605484'),
(80, 3, 'tbl_dashboard_quick_press_last_post_id', '84'),
(82, 4, 'tbl_user-settings', 'hidetb=1&editor=tinymce&libraryContent=browse'),
(83, 4, 'tbl_user-settings-time', '1480605524'),
(84, 4, 'tbl_dashboard_quick_press_last_post_id', '85'),
(86, 2, 'last_activity', '2016-12-02 19:43:46'),
(88, 3, 'last_activity', '2016-12-01 20:15:19'),
(90, 4, 'last_activity', '2016-12-02 06:40:37'),
(92, 5, 'nickname', 'Subscriber'),
(93, 5, 'first_name', 'Subscriber'),
(94, 5, 'last_name', ''),
(95, 5, 'description', ''),
(96, 5, 'rich_editing', 'true'),
(97, 5, 'comment_shortcuts', 'false'),
(98, 5, 'admin_color', 'fresh'),
(99, 5, 'use_ssl', '0'),
(100, 5, 'show_admin_bar_front', 'true'),
(103, 5, '_yoast_wpseo_profile_updated', '1480704012'),
(104, 5, 'bp_xprofile_visibility_levels', 'a:1:{i:1;s:6:"public";}'),
(106, 5, 'googleplus', ''),
(107, 6, 'nickname', 'Subscriber'),
(108, 6, 'first_name', 'Subscriber'),
(109, 6, 'last_name', ''),
(110, 6, 'description', ''),
(111, 6, 'rich_editing', 'true'),
(112, 6, 'comment_shortcuts', 'false'),
(113, 6, 'admin_color', 'fresh'),
(114, 6, 'use_ssl', '0'),
(115, 6, 'show_admin_bar_front', 'true'),
(118, 6, '_yoast_wpseo_profile_updated', '1480623918'),
(119, 6, 'bp_xprofile_visibility_levels', 'a:1:{i:1;s:6:"public";}'),
(120, 6, 'activation_key', 'tXnIS0dVuHWaRZsr4F64BHV1kLk1Eojl'),
(121, 6, 'googleplus', ''),
(122, 5, 'tbl_capabilities', 'a:1:{s:10:"subscriber";b:1;}'),
(123, 5, 'tbl_user_level', '0'),
(124, 5, 'twitter', ''),
(125, 5, 'facebook', ''),
(127, 5, 'last_activity', '2016-12-02 20:13:36'),
(129, 2, 'wpseo_title', ''),
(130, 2, 'wpseo_metadesc', ''),
(131, 2, 'wpseo_metakey', ''),
(132, 2, 'wpseo_excludeauthorsitemap', ''),
(133, 2, 'wpseo_content_analysis_disable', ''),
(134, 2, 'wpseo_keyword_analysis_disable', ''),
(135, 2, 'googleplus', ''),
(136, 2, 'twitter', ''),
(137, 2, 'facebook', ''),
(138, 1, '_yoast_wpseo_profile_updated', '1480703909'),
(139, 1, 'wpseo_title', ''),
(140, 1, 'wpseo_metadesc', ''),
(141, 1, 'wpseo_metakey', ''),
(142, 1, 'wpseo_excludeauthorsitemap', ''),
(143, 1, 'wpseo_content_analysis_disable', ''),
(144, 1, 'wpseo_keyword_analysis_disable', ''),
(145, 1, 'googleplus', ''),
(146, 1, 'twitter', ''),
(147, 1, 'facebook', ''),
(148, 4, 'wpseo_title', ''),
(149, 4, 'wpseo_metadesc', ''),
(150, 4, 'wpseo_metakey', ''),
(151, 4, 'wpseo_excludeauthorsitemap', ''),
(152, 4, 'wpseo_content_analysis_disable', ''),
(153, 4, 'wpseo_keyword_analysis_disable', ''),
(154, 4, 'googleplus', ''),
(155, 4, 'twitter', ''),
(156, 4, 'facebook', ''),
(157, 5, 'wpseo_title', ''),
(158, 5, 'wpseo_metadesc', ''),
(159, 5, 'wpseo_metakey', ''),
(160, 5, 'wpseo_excludeauthorsitemap', ''),
(161, 5, 'wpseo_content_analysis_disable', ''),
(162, 5, 'wpseo_keyword_analysis_disable', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'cse.mahmud', '$P$BEgEeoPSKp9.lmmCvawwz4GGRU74650', 'cse-mahmud', 'cse.mahmudul@gmail.com', '', '2016-12-01 05:51:40', '', 0, 'cse.mahmud'),
(2, 'contributor', '$P$BzAO.q7n6bhn3OLzH.FcXvVxjXIGs90', 'contributor', 'contributor@gmail.com', '', '2016-12-01 15:12:42', '1480605165:$P$B0MGRxYcNYRvmWRLGVhBuE70nvNKnY/', 0, 'Contributor'),
(3, 'author', '$P$BOTLS31FRWnAHO/1OAYGBaUn5xom.21', 'author', 'author@gmail.com', '', '2016-12-01 15:13:52', '1480605235:$P$BTbqiu/7ZTEH5C5.hCXQzm/g.5m/5h1', 0, 'Author'),
(4, 'editor', '$P$Bv.zqhEo0/536Odha/6GNQ1pXykf0S0', 'editor', 'editor@gmail.com', '', '2016-12-01 15:16:00', '1480605362:$P$BaZ5TMRAEZOT9XOSix5y/AuLF7QgMY.', 0, 'Editor'),
(5, 'subscriber1', '$P$B7UjDKI1DDVjrWEDpxcp5xjFvBeRGQ0', 'subscriber1', 'subscriber1@gmail.com', '', '2016-12-01 20:23:59', '', 0, 'Subscriber'),
(6, 'subscriber2', '$P$BgWy.R7nDwPAm/Fv./TFQqEW8FHwOd1', 'subscriber2', 'subscriber2@gmail.com', '', '2016-12-01 20:25:17', '', 2, 'Subscriber');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
